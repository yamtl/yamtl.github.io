
package extraction;

import javax.xml.parsers.ParserConfigurationException;

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.EcorePackage
import org.xml.sax.SAXException;

import prettyprinting.EMFPrettyPrinter;
import emf_syncer.EMFSyncer;
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped;
import untypedModel.UntypedModelPackage;

public class FromJsonToEcore {

    static void main(String... args) throws SAXException, ParserConfigurationException {
		
		String jsonModelPath = "src/main/groovy/extraction/class_diagram.json";
		String outputXmiPath = "src/main/groovy/extraction/class_diagram_generated.ecore";
		String outputSVGPath = "src/main/groovy/extraction/class_diagram_generated.svg";
		
		EPackage metamodel = EcorePackage.eINSTANCE;

		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))

		syncer.loadSourceModel(jsonModelPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputXmiPath)

		println("Model saved to ${outputXmiPath}")
		
		EMFPrettyPrinter.ecore_to_classDiagram_SVG(outputXmiPath, outputSVGPath)
		
		
	}
}
