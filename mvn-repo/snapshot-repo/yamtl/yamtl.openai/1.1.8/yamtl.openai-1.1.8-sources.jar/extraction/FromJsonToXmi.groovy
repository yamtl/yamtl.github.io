
package extraction;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import javax.xml.parsers.ParserConfigurationException;

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.resource.Resource
import org.xml.sax.SAXException;

import emf_syncer.EMFSyncer;
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped;
import groovy.json.JsonOutput
import untypedModel.UntypedModelPackage;
import yamtl.core.YAMTLModule

public class FromJsonToXmi {

    static void main(String... args) throws SAXException, ParserConfigurationException {
		
    	def metamodelFilePath = "output/iteration_02/generated_metamodel.ecore"
		def jsonModelPath = "output/iteration_02/extractedData.json"
		def outputXmiPath = "output/iteration_02/extractedData_debug.xmi"
		
		Resource metamodelRes = YAMTLModule.preloadMetamodel(metamodelFilePath)
		EPackage metamodel = (EPackage) metamodelRes.getContents().get(0)

		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))

		syncer.loadSourceModel(jsonModelPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputXmiPath)

		println("Model saved to ${outputXmiPath}")
		
		
	}
}
