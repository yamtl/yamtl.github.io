package strategy

import emf_syncer.roles.SynchronizationMetricsRecord

class SearchNode {
	static int nodeCounter = 0  // A static counter to assign unique IDs
	static int BRANCHING_FACTOR = 2
	
	
	int id	
    String strategyId
    String strategyName
    String strategyAim
	String guidelines
	SynchronizationMetricsRecord metrics 
	
	String outputDirPath
	
	int branchingFactor = 2
	SearchNode parentNode = null

	String outputMetamodelJsonPath = ""
	String outputEcorePath = ""
	String outputGuidelinesPromptPath  = ""
	String outputJsonPath = ""
	String outputXmiPath = ""
	String outputAnalysisPath = ""
	String outputFeatureMappingJsonPath = ""
	String gtJsonPath = ""
	String gtXmiPath = ""
		
    /**
     * Compute the successor nodes for this search node.
     */
    List<SearchNode> getSuccessors(String imageUrl, String mimetype, int branchingFactor, String outputDirPath, String reflectionIfBacktracking) {
        def decisionStrategy = new DecisionStrategyImpl_Default()
        def candidates = decisionStrategy.generateCandidates(imageUrl, mimetype, this, reflectionIfBacktracking, branchingFactor)
        return candidates.collect { candidate ->
            def node = new SearchNode()
		
			node.id = ++nodeCounter
			node.branchingFactor = branchingFactor
            node.strategyId = generateBranchId(node.id)
            node.strategyName = candidate.name
            node.strategyAim = candidate.aim
			node.outputDirPath = generateOutputDirPath(outputDirPath, nodeCounter)
			def iterationDir = new File(node.outputDirPath)
			if (!iterationDir.exists()) iterationDir.mkdirs()
		
			if (this.isRoot()) {
				node.parentNode = this
			}
			
			node.outputMetamodelJsonPath = "${node.outputDirPath}/generated_metamodel.json"
			node.outputEcorePath = "${node.outputDirPath}/generated_metamodel.ecore"
			node.outputGuidelinesPromptPath = "${node.outputDirPath}/guidelines.md"
			node.outputJsonPath = "${node.outputDirPath}/extractedData.json"
			node.outputXmiPath = "${node.outputDirPath}/extractedData.xmi"
			node.outputAnalysisPath = "${node.outputDirPath}/analysis.md"
			node.outputFeatureMappingJsonPath = "${node.outputDirPath}/generated_emfsyncer_mappings.json"
			node.gtJsonPath = "${node.outputDirPath}/gtModel.json"
			node.gtXmiPath = "${node.outputDirPath}/gtModel.xmi"
			
            return node
        }
    }
	
	
	def isRoot() {
		return (this.parentNode?.outputDirPath == null)
	}
	
	
	def generateBranchId(int counter) {
		def depth = counter.intdiv(BRANCHING_FACTOR)
		def branchIndex = counter % BRANCHING_FACTOR
		return "Depth_${String.format('%02d',depth)}_Branch_${String.format('%02d',branchIndex)}_Node_${String.format('%02d',counter)}"
	}

	def String generateOutputDirPath(outputDirPath, iteration) {
		return "${outputDirPath}/${generateBranchId(iteration)}".toString()
	}
	

}
