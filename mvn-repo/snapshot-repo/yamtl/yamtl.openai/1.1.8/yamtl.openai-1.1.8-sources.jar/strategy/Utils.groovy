package strategy

import apiClient_lambda.LLMUtil
import apiClient_lambda.ModelApiKeys
import groovy.json.JsonOutput

class Utils {

	
	/**
	 * Retrieves the API key for the selected LLM model.
	 */
	static String getApiKey(LLMUtil llmModel) {
	    return ModelApiKeys.getApiKey(llmModel)
	}

	
	/**
	 * Saves the given Ecore metamodel content into a .ecore file.
	 * If the file already exists, it is overwritten.
	 *
	 * @param ecoreContent The textual representation of the Ecore metamodel.
	 * @param outputFilePath The path where the .ecore file should be saved.
	 */
	static void saveJson(Map jsonContent, String outputFilePath) {
		File jsonFile = new File(outputFilePath)
	
		// Ensure any existing file is deleted before writing
		if (jsonFile.exists()) {
			jsonFile.delete()
		}
	
		// Save the content into the file
		jsonFile << JsonOutput.prettyPrint(JsonOutput.toJson(jsonContent))
	}
	
	
	static void waitForUserConfirmation() {
	    println "🔍 Do these mappings look correct? Press ENTER to confirm or type 'q'/'quit' to exit."
	
	    def input = System.in.newReader().readLine()?.trim()
	
	    if (input in ["q", "quit"]) {
	        println "❌ Script exited by user."
	        System.exit(1)
	    }
	}
}

