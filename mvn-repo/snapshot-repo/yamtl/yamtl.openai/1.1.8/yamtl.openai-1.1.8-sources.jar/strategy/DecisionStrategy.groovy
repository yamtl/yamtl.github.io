package strategy

interface DecisionStrategy {
    List<Map> generateCandidates(String imageUrl, String mimetype, SearchNode bestParentNode, String reflectionIfBacktracking, int branchingFactor)
}
