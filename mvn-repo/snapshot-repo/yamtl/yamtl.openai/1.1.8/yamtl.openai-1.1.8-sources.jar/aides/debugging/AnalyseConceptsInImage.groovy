package aides.debugging

import aides_v14.Utils
import apiClient_lambda.LLMClient
import apiClient_lambda.LLMUtil
import groovy.json.JsonOutput

class AnalyseConceptsInImage {
	/**
	 * Generates a textual metamodel and extraction guidelines for a given image using LLM.
	 * Stores the metamodel in structured textual format and generates extraction guidelines.
	 */
	static void generateMetamodelAndGuidelines(LLMUtil llm_model, String imageUrl, String expected_json, File outputDir) {
	    println "Generating description of image for: ${imageUrl}"
	
	    // Call LLM to infer a metamodel from the image
	    def client = new LLMClient()
	    
	    def metamodelPrompt = """
Given an image that contains structured data and a oracle json document 
with the extracted data from this image, generate a textual description 
of the domain model that helps capture the extracted data. 
The textual description should include:
- **Entities** (class names)
- **Intrinsic properties** (attributes with types)
- **Extrinsic properties** (relationships with multiplicities (lower bound, upper bound) and constraints - composition, uniqueness, ordering, etc.)

### Oracle JSON Document

${expected_json}
"""
	
	    def extractedMetamodel_puml = client.call_prompt(metamodelPrompt.toString(), llm_model.value, Utils.getApiKey(llm_model))
		println('------------------')
		println("Extracted metamodel: ${extractedMetamodel_puml.body.message}")
	
		
		def metamodel_json = client.extractMetamodel(extractedMetamodel_puml.body.message, llm_model.value, Utils.getApiKey(llm_model))
		println('------------------')
		println("Extracted metamodel Ecore: ${JsonOutput.prettyPrint(JsonOutput.toJson( metamodel_json.body.message ))}")
		Utils.saveJson(metamodel_json.body.message, "${outputDir.absolutePath}/generated_metamodel.json")
		
	}
	
	
	
		
	static void main(String... args) {
	    // Define test parameters
	    def llmModel = LLMUtil.GPT4oMini // LLM model to use
	    String imageUrl = "https://raw.githubusercontent.com/yamtl/llm-files/refs/heads/main/images/patient-3910-l.png"  // Replace with a real image URL
	    String expectedJsonPath = "src/main/resources/3910L.json"  // Path to example expected JSON
	    File outputDir = new File("output/")  // Directory to save outputs
	
	    // Ensure output directory exists
	    if (!outputDir.exists()) {
	        outputDir.mkdirs()
	    }
	
	    // Read expected JSON from file
	    File jsonFile = new File(expectedJsonPath)
	    if (!jsonFile.exists()) {
	        println "❌ Error: Expected JSON file not found at ${expectedJsonPath}"
	        return
	    }
	    
	    String expectedJson = jsonFile.text  // Read the file contents
	
	    // Call the function
	    println "🔹 Running generateMetamodelAndGuidelines with test data..."
	    generateMetamodelAndGuidelines(llmModel, imageUrl, expectedJson, outputDir)
	
	    // Verify results
	    File metamodelFile = new File(outputDir, "generated_metamodel.puml")
	    File ecoreFile = new File(outputDir, "generated_metamodel.ecore")
	    File guidelinesFile = new File(outputDir, "extraction_guidelines.txt")
	
	    if (metamodelFile.exists() && ecoreFile.exists() && guidelinesFile.exists()) {
	        println "✅ Test completed successfully! Outputs generated in: ${outputDir.absolutePath}"
	    } else {
	        println "❌ Test failed: Some output files were not generated."
	    }
	}

}
