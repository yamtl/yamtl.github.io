package aides.debugging

import prettyprinting.EMFPrettyPrinter

class ExtractModel {
	static void main(String...args) {
		File outputDir = new File("output/")
		
		def metamodel_ecore_filePath = "${outputDir.path}/generated_metamodel.ecore"
		
		
		println("${EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(metamodel_ecore_filePath)}")
	}
}