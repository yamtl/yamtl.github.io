package apiClient_deprecated;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.resource.Resource

import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped
import emf_syncer.EMFSyncer.ComparisonMode
import emf_syncer.dsl.FeatureMappingFactory
import emf_syncer.roles.SynchronizationMetricsRecord
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import prettyprinting.EMFPrettyPrinter
import untypedModel.UntypedModelPackage
import yamtl.core.YAMTLModule

class ExperimentDriver_VFM_Extraction {

    static void processDataset(List dataset, File outputDir) {
        dataset.each { entry ->
            def imageUrl = entry.url
            def jsonData = entry.json

			def uri = entry.url
			def outputDirForEntry = new File("${outputDir.absolutePath}/${uri.replaceAll(/[^a-zA-Z0-9]/, "")}")
			outputDirForEntry.mkdir()
			
            println "Processing image: ${imageUrl}"

            // Step 1: Extract structured data from image
            def extractedJson = extractDataFromImage(imageUrl, outputDirForEntry)

            // Step 2: Convert both JSON documents to EMF models
            def extractedModel = convertJsonToEMF(extractedJson, "extractedData", outputDirForEntry)
            def groundTruthModel = convertJsonToEMF(jsonData, "gtModel", outputDirForEntry)

            // Step 3: Compare models using EMFSyncer
            def metrics = compareModels("${outputDirForEntry}/extractedData.xmi", "${outputDirForEntry}/gtModel.xmi")

            // Store metrics
            storeMetrics(metrics, outputDir.absolutePath, uri)
        }

    }
	
	
	static void computeMetrics(File outputDir) {
		
        // Step 4: Compute statistics
		if (allMetrics.isEmpty()) {
			loadMetricsFromCSV(outputDir.absolutePath)
		}
		
        computeStatistics()
	}

    static def extractDataFromImage(String imageUrl, File outputDir) {
        def metamodelFilePath = 'model/visualFieldMap.ecore'
        def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(metamodelFilePath)


		def prompt = '''Extract the numerical sensitivity values from the matrix, ensuring that the structure and separators are preserved accurately.
Formatting Rules:
* When two values in the same row are separated by a vertical line, consider them in separate quadrants.
* When two values in the same column are separated by a horizontal line, consider them in separate quadrants.
* Maintain the exact spatial structure of the original table, including all separations.
  * All values before the vertical line and above the horizontal line are in the quadrant "TOP_LEFT".
  * All values after the vertical line and above the horizontal line are in the quadrant "TOP_RIGHT"
  * All values before the vertical line and below the horizontal line are in the quadrant "BOTTOM_LEFT"
  * All values after the vertical line and below the horizontal line are in the quadrant "BOTTOM_RIGHT"

Output the result in JSON using the schema below, where each JSON object must have a field 'type' with the name of the class it is instantiating:'''

		
        def client = new RestApiClient("http://localhost:5000")
        def response = client.extractData(metamodelPuml, prompt, imageUrl, "gpt-4o-mini")

        def jsonFile = new File("${outputDir.absolutePath}/extractedData.json")
        jsonFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(response))

		println("Extracted JSON response saved to tmp.json")
        return response
    }

    static def convertJsonToEMF(Map jsonData, String outputFileName, File outputDir) {
        def metamodelFilePath = 'model/visualFieldMap.ecore'
        Resource metamodelRes = LLM_test_OpenAI_api.preloadMetamodel(metamodelFilePath)
        EPackage metamodel = (EPackage) metamodelRes.getContents().get(0)

        def syncer = new EMFSyncer()
        syncer.enableEagerMode()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))

        def jsonFile = new File("${outputDir.absolutePath}/${outputFileName}.json")
        jsonFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(jsonData))

        syncer.loadSourceModel(jsonFile.absolutePath)
        syncer.forwardSync()
        syncer.saveTargetModel("${outputDir.absolutePath}/${outputFileName}.xmi")

        println("Model saved to ${outputFileName}")
    }

    static def compareModels(String extractedModelPath, String gtModelPath) {
        def metamodel = YAMTLModule.preloadMetamodel("model/visualFieldMap.ecore")
        def pk = metamodel.contents[0] as EPackage

        def syncer = new EMFSyncer()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF("e", [pk: pk]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("g", [pk: pk]))
        syncer.enableStateExtent()

        def mappings = [
//            FeatureMappingFactory.create("VisualFieldMap", "patientID", "VisualFieldMap", "patientID"),
//            FeatureMappingFactory.create("VisualFieldMap", "testType", "VisualFieldMap", "testType"),
//            FeatureMappingFactory.create("VisualFieldMap", "eyeTested", "VisualFieldMap", "eyeTested"),
            FeatureMappingFactory.create("Quadrant", "quadrantType", "Quadrant", "quadrantType"),
            FeatureMappingFactory.create("SensitivityPoint", "owningQuadrant", "SensitivityPoint", "owningQuadrant"),
            FeatureMappingFactory.create("SensitivityPoint", "row", "SensitivityPoint", "row"),
            FeatureMappingFactory.create("SensitivityPoint", "column", "SensitivityPoint", "column")
        ]

        syncer.setSimilarityRelation(true, mappings, ComparisonMode.EXACT)

		def sourceVfm = syncer.getModelContents(extractedModelPath).get(0) 
		def sourceQuadrantList = getQuadrants(pk, sourceVfm) as List<Object>
		syncer.setSourceModel(sourceQuadrantList)
        
		def targetVfm = syncer.getModelContents(gtModelPath).get(0)
		def targetQuadrantList = getQuadrants(pk, targetVfm) as List<Object>
		syncer.setTargetModel(targetQuadrantList)
		
		syncer.match()

        def metrics = syncer.getForwardMetrics()
        println("Comparison metrics: \n" + metrics)
        return metrics
    }

	
	static List<EObject> getQuadrants(EPackage pk, EObject vfm) {
		def quadrants = pk.getEClassifier("VisualFieldMap").getEStructuralFeature("quadrants")
		return vfm.eGet(quadrants)
	}
	
    static List<SynchronizationMetricsRecord> allMetrics = []

	static void storeMetrics(SynchronizationMetricsRecord metrics, String outDirPath, uri) {
	    def csvFile = new File(outDirPath, "metrics.csv")
	    boolean fileExists = csvFile.exists()
	
	    // Write header if the file does not exist
	    if (!fileExists) {
	        csvFile << "uri,ObjectTP,ObjectFP,ObjectFN,ObjectPrecision,ObjectRecall,FeatureTP,FeatureFP,FeatureFN,FeaturePrecision,FeatureRecall\n"
	    }
	
	    // Append metrics data
	    csvFile << "${uri},${metrics.objectTP},${metrics.objectFP},${metrics.objectFN},${metrics.objectPrecision},${metrics.objectRecall},${metrics.featureTP},${metrics.featureFP},${metrics.featureFN},${metrics.featurePrecision},${metrics.featureRecall}\n"
	}
	
	
	// Ensure allMetrics is populated by loading from CSV if empty
	static void loadMetricsFromCSV(String outDirPath) {
		def csvFile = new File(outDirPath, "metrics.csv")
		if (!csvFile.exists()) {
			println "No metrics CSV file found, skipping load."
			return
		}
	
		try  {
			BufferedReader reader = new BufferedReader(new FileReader(csvFile))
			// Read and ignore the header
			reader.readLine()
			reader.lines().each { line ->
				def parts = line.split(",")
				if (parts.length == 11) {
					def record = new SynchronizationMetricsRecord(
						parts[1].toInteger(), parts[2].toInteger(), parts[3].toInteger(),
						parts[4].toDouble(), parts[5].toDouble(),
						parts[6].toInteger(), parts[7].toInteger(), parts[8].toInteger(),
						parts[9].toDouble(), parts[10].toDouble()
					)
					allMetrics.add(record)
				}
			}
		} catch (Exception e) {
			println "Error loading metrics from CSV: ${e.message}"
		}
	}
	
	
	
    static void computeStatistics() {
        def statsObjectPrecision = new DescriptiveStatistics()
        def statsObjectRecall = new DescriptiveStatistics()
        def statsFeaturePrecision = new DescriptiveStatistics()
        def statsFeatureRecall = new DescriptiveStatistics()

        allMetrics.each { metrics ->
            statsObjectPrecision.addValue(metrics.objectPrecision)
            statsObjectRecall.addValue(metrics.objectRecall)
            statsFeaturePrecision.addValue(metrics.featurePrecision)
            statsFeatureRecall.addValue(metrics.featureRecall)
        }

        println "===== STATISTICS ====="
        println "Object-Level Precision: ${getStatistics(statsObjectPrecision)}"
        println "Object-Level Recall: ${getStatistics(statsObjectRecall)}"
        println "Feature-Level Precision: ${getStatistics(statsFeaturePrecision)}"
        println "Feature-Level Recall: ${getStatistics(statsFeatureRecall)}"
    }

    static def getStatistics(DescriptiveStatistics stats) {
        return [
            mean: stats.mean,
            stdDev: stats.standardDeviation,
            min: stats.min,
            Q1: stats.getPercentile(25),
            median: stats.getPercentile(50),
            Q3: stats.getPercentile(75),
            max: stats.max
        ]
    }

    static void main(String... args) {
		def path = '//wsl.localhost/Ubuntu-22.04/home/ab373/git-repos/git-yamtl/yamtl-openai/python/dataset/sample_10.json'
		def outputDirPath = '//wsl.localhost/Ubuntu-22.04/home/ab373/git-repos/git-yamtl/yamtl-openai/python/dataset-gen/'
		
		def outputDir = new File(outputDirPath)
		if (outputDir.isDirectory()) {
			outputDir.deleteDir()
			outputDir.mkdirs()
		} else {
			outputDir.mkdirs()
		}
		
		def datasetFile = new File(path)
        def dataset = new JsonSlurper().parseText(datasetFile.text)

        processDataset(dataset, outputDir)
    	computeMetrics(outputDir)
		
		
//		// TO process the save metrics.csv file only
//        def outputDirPath = '//wsl.localhost/Ubuntu-22.04/home/ab373/git-repos/git-yamtl/yamtl-openai/python/dataset-10/'
//		computeMetrics(new File(outputDirPath))
    }
}
