package apiClient_lambda;

enum LLMUtil {
    HAIKU("claude-3-5-haiku-20241022"),
    SONNET("claude-3-5-sonnet-20241022"),
    GPT4o("gpt-4o"),
    GPT4oMini("gpt-4o-mini"),
    LLAMA3_8B_INSTRUCT("meta/meta-llama-3-8b-instruct"),
    GEMINI_1_5_FLASH_8B("models/gemini-1.5-flash-8b"),
    GEMINI2_FLASH("models/gemini-2.0-flash-001"),
    GEMINI2_FLASH_LITE("models/gemini-2.0-flash-lite-preview-02-05")
    
    final String value
    
    LLMUtil(String value) {
        this.value = value
    }
    
    static LLMUtil fromValue(String value) {
        return values().find { it.value == value }
    }
}

class ModelApiKeys {
    static final Map<LLMUtil, String> API_KEYS = [
        (LLMUtil.HAIKU)             : "ANTHROPIC_API_KEY",
        (LLMUtil.SONNET)            : "ANTHROPIC_API_KEY",
        (LLMUtil.GPT4o)             : "OPENAI_API_KEY",
        (LLMUtil.GPT4oMini)         : "OPENAI_API_KEY",
        (LLMUtil.LLAMA3_8B_INSTRUCT): "REPLICATE_API_TOKEN",
        (LLMUtil.GEMINI_1_5_FLASH_8B): "GOOGLE_API_KEY",
        (LLMUtil.GEMINI2_FLASH)     : "GOOGLE_API_KEY",
        (LLMUtil.GEMINI2_FLASH_LITE): "GOOGLE_API_KEY"
    ]
    
    static String getApiKey(LLMUtil model) {
        def apiKey = System.getenv(API_KEYS[model])
		
		if (apiKey == null) {
			throw new RuntimeException("API Key for ${model.value} is not set. Please set the environment variable ${API_KEYS[model]}")
		}
		
		return apiKey
    }
}
