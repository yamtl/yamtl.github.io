package apiClient_lambda

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

class LLMClient {
    static String LAMBDA_API_BASE_URL = "https://ompe14d8i1.execute-api.us-east-2.amazonaws.com/Prod"
    static String LOCALHOST_BASE_URL = "http://localhost:8000"

	def API_BASE_URL = LOCALHOST_BASE_URL
	
	public LLMClient() {
	    API_BASE_URL = detectAvailableServer()
	}
	
	private static String detectAvailableServer() {
	    try {
	        URL url = new URL("${LOCALHOST_BASE_URL}/prompt")
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection()
	        connection.setRequestMethod("OPTIONS") // Use OPTIONS instead of GET
	        connection.setConnectTimeout(1000) // 1-second timeout to avoid long delays
	        connection.setReadTimeout(1000)
	        connection.connect()
	
	        int responseCode = connection.getResponseCode()
	        if (responseCode >= 200 && responseCode < 500) { // Accept all valid responses
	            // println "🖥️ Localhost server detected, using LOCALHOST_BASE_URL"
	            return LOCALHOST_BASE_URL
	        }
	    } catch (Exception e) {
	        // println "☁️ Localhost server not detected, falling back to AWS"
	    }
	    return LAMBDA_API_BASE_URL
	}

	
    def sendPostRequest(String endpoint, Map payload) {
        def url = new URL("${API_BASE_URL}${endpoint}")
        def connection
        def responseCode
        def responseText
        def attempts = 3

        while (attempts > 0) {
            try {
                connection = (HttpURLConnection) url.openConnection()
                connection.setRequestMethod("POST")
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setRequestProperty("Accept", "application/json")
                connection.setDoOutput(true)

                def jsonPayload = JsonOutput.toJson(payload)
                connection.outputStream.withWriter("UTF-8") { it.write(jsonPayload) }

                responseCode = connection.responseCode
                responseText = connection.inputStream.text

                if (responseCode == 200 || responseCode == 404) {
                    break
                } else {
                    println "Error: ${responseCode} - ${responseText}, retrying..."
                }
            } catch (Exception e) {
                println "Exception: ${e.message}, retrying..."
            } finally {
                attempts--
                if (attempts == 0 && responseCode != 200 && responseCode != 404) {
                    println "Final error: ${responseCode} - ${responseText}"
                    return null
                }
            }
        }

        return responseCode == 200 ? new JsonSlurper().parseText(responseText) : null
    }


	
	
	
	
	
	def call_prompt(String prompt, String llmModel, String apiKey, int maxTokens, float temp) {
		def payload = [
			prompt       : prompt,
			llm_model  : llmModel,
			max_tokens : maxTokens,
			temp      : temp,
			api_key    : apiKey
		]
		return sendPostRequest("/prompt", payload)
	}
	

	def call_prompt_with_image_bytes(String prompt, byte[] image, String mimetype, String llmModel, String apiKey, int maxTokens, float temp) {
		def payload = [
			prompt : prompt,
			llm_model  : llmModel,
			image  : image,
			mimetype  : mimetype,
			max_tokens : maxTokens,
			temp      : temp,
			api_key    : apiKey
		]
		return sendPostRequest("/prompt", payload)
	}

	def call_prompt_with_image_url(String prompt, String image_url, String mimetype, String llmModel, String apiKey, int maxTokens, float temp) {
		def payload = [
			prompt : prompt,
			llm_model  : llmModel,
			image_url  : image_url,
			mimetype  : mimetype,
			max_tokens : maxTokens,
			temp      : temp,
			api_key    : apiKey
		]
		return sendPostRequest("/prompt", payload)
	}
	
	def call_prompt_to_json(String prompt, String llmModel, String apiKey, int maxTokens, float temp) {
		def payload = [
			prompt       : prompt,
			llm_model  : llmModel,
			max_tokens : maxTokens,
			temp      : temp,
			api_key    : apiKey,
			mimetype  : 'application/json'
		]
		return sendPostRequest("/prompt", payload)
	}
	
	def call_prompt_with_image_bytes_to_json(String prompt, byte[] image, String mimetype, String llmModel, String apiKey, int maxTokens, float temp) {
		def payload = [
			prompt : prompt,
			llm_model  : llmModel,
			image  : image,
			mimetype  : mimetype,
			max_tokens : maxTokens,
			temp      : temp,
			api_key    : apiKey,
			mimetype  : 'application/json'
		]
		return sendPostRequest("/prompt", payload)
	}
	
	def call_prompt_with_image_url_to_json(String prompt, String image_url, String mimetype, String llmModel, String apiKey, int maxTokens, float temp) {
		def payload = [
			prompt : prompt,
			llm_model  : llmModel,
			image_url  : image_url,
			mimetype  : mimetype,
			max_tokens : maxTokens,
			temp      : temp,
			api_key    : apiKey,
			mimetype  : 'application/json'
		]
		return sendPostRequest("/prompt", payload)
	}
	
	
    def extractTypedJson(String task, String metamodel, String llmModel, String apiKey, int maxTokens, float temp) {
        def payload = [
            task       : task,
            metamodel  : metamodel,
            llm_model  : llmModel,
            max_tokens : maxTokens,
			temp      : temp,
            api_key    : apiKey
        ]
        return sendPostRequest("/extract_typed_json", payload)
    }
	
	def extractTypedJsonFromImageUrl(String task, String metamodel, String imageUrl, String mimetype, String llmModel, String apiKey, int maxTokens, float temp) {
		def payload = [
			task       : task,
			metamodel  : metamodel,
			image_url  : imageUrl,
			mimetype : mimetype,
			llm_model  : llmModel,
			max_tokens : maxTokens,
			temp      : temp,
			api_key    : apiKey
		]
		return sendPostRequest("/extract_typed_json", payload)
	}

    def extractMetamodel(String text, String llmModel, String apiKey, int maxTokens, float temp) {
        def payload = [
            text       : text,
            llm_model  : llmModel,
            max_tokens : maxTokens,
			temp      : temp,
            api_key    : apiKey
        ]
        return sendPostRequest("/extract_metamodel", payload)
    }

	
	
	
	

}
