

Our system extracts structured data from images based on a **metamodel** and predefined **extraction guidelines**. 
The **metamodel** defines entities, attributes, and relationships, 
while the **extraction guidelines** instruct how to extract and format data into a JSON structure. 

After processing, the extracted JSON is compared with an expected JSON reference. 
Evaluation metrics (precision, recall, and F1-score) indicate alignment between 
the extracted and expected data (ground truth). 


## Available Information

### 1. **Current Metamodel (PlantUML format)**
```
@startuml
class VisualFieldMap #1EBFA982 {
	String testID
	String patientID
	String testType
	String eyeTested
	Date date
}
class Quadrant #B6B4D61C {
	String quadrantType
}
class SensitivityPoint #57F0D651 {
	int row
	int column
	double sensitivityValue
	String type
}
VisualFieldMap *--> "quadrants *" Quadrant
Quadrant *--> "sensitivityPoints *" SensitivityPoint

@enduml
```

### 2. **Current Extraction Guidelines**
```
1. Begin by identifying the grid structure formed by horizontal and vertical lines in the image. This grid will help define the boundaries of table cells.

2. Locate the intersections of these lines, which will serve as the boundaries for each cell in the grid.

3. Extract the numerical values contained within each cell. Ensure that each value is correctly associated with its respective row and column based on its position relative to the grid lines.

4. Identify the overall structure of the data, which consists of a visual field test for a specific patient. Extract the following metadata:
   - `testID`: Extract from the title of the image.
   - `patientID`: Extract from the title of the image.
   - `testType`: This should be set to "visual_field".
   - `eyeTested`: Extract from the title of the image (e.g., "R eye" for right eye).
   - `date`: This may not be explicitly stated in the image; if available, extract it from the context or metadata.

5. Organize the extracted numerical values into quadrants. Each quadrant corresponds to a specific section of the grid:
   - Define four quadrants: "TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", and "BOTTOM_RIGHT".

6. For each quadrant, create a list of sensitivity points. Each sensitivity point should include:
   - `row`: The row number of the sensitivity point.
   - `column`: The column number of the sensitivity point.
   - `sensitivityValue`: The extracted numerical value from the cell.
   - `type`: Set this to "SensitivityPoint".

7. Structure the extracted data in JSON format according to the schema defined by the metamodel. Ensure that the quadrants and their respective sensitivity points are nested correctly within the `VisualFieldMap` object.

8. Validate the final JSON structure against the expected schema to ensure all required fields are present and correctly formatted. 

9. Avoid overfitting by ensuring that the extraction process is adaptable to variations in the layout and content of similar images. Focus on the grid structure and numerical values rather than specific visual elements that may change.
```

### 3. **Expected JSON Output (Ground Truth)**
```
{
    "testID": "test_4148_r",
    "patientID": "4148",
    "testType": "visual_field",
    "eyeTested": "RIGHT",
    "date": "07/02/2025",
    "quadrants": [
        {
            "quadrantType": "TOP_LEFT",
            "sensitivityPoints": [
                {
                    "row": 1,
                    "column": 1,
                    "sensitivityValue": 8.98,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 2,
                    "sensitivityValue": 17.34,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 1,
                    "sensitivityValue": 18.67,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 2,
                    "sensitivityValue": 24.62,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 3,
                    "sensitivityValue": 22.13,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 1,
                    "sensitivityValue": 18.27,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 2,
                    "sensitivityValue": 25.08,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 3,
                    "sensitivityValue": 29.22,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 4,
                    "sensitivityValue": 29.37,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 1,
                    "sensitivityValue": 17.17,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 2,
                    "sensitivityValue": 19.85,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 3,
                    "sensitivityValue": 27.19,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 4,
                    "sensitivityValue": 32.48,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 5,
                    "sensitivityValue": 31.35,
                    "type": "SensitivityPoint"
                }
            ],
            "type": "Quadrant"
        },
        {
            "quadrantType": "TOP_RIGHT",
            "sensitivityPoints": [
                {
                    "row": 1,
                    "column": 1,
                    "sensitivityValue": 13.9,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 2,
                    "sensitivityValue": 11.85,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 1,
                    "sensitivityValue": 19.72,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 2,
                    "sensitivityValue": 24.19,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 3,
                    "sensitivityValue": 15.73,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 1,
                    "sensitivityValue": 28.4,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 2,
                    "sensitivityValue": 26.85,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 3,
                    "sensitivityValue": 24.53,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 4,
                    "sensitivityValue": 20.31,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 1,
                    "sensitivityValue": 31.61,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 2,
                    "sensitivityValue": 29.98,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 3,
                    "sensitivityValue": 19.0,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 4,
                    "sensitivityValue": 23.17,
                    "type": "SensitivityPoint"
                }
            ],
            "type": "Quadrant"
        },
        {
            "quadrantType": "BOTTOM_LEFT",
            "sensitivityPoints": [
                {
                    "row": 1,
                    "column": 1,
                    "sensitivityValue": 20.71,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 2,
                    "sensitivityValue": 24.57,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 3,
                    "sensitivityValue": 28.99,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 4,
                    "sensitivityValue": 30.76,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 5,
                    "sensitivityValue": 30.59,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 1,
                    "sensitivityValue": 24.63,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 2,
                    "sensitivityValue": 29.12,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 3,
                    "sensitivityValue": 31.49,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 4,
                    "sensitivityValue": 31.19,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 1,
                    "sensitivityValue": 26.59,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 2,
                    "sensitivityValue": 28.92,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 3,
                    "sensitivityValue": 24.9,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 1,
                    "sensitivityValue": 28.81,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 2,
                    "sensitivityValue": 24.72,
                    "type": "SensitivityPoint"
                }
            ],
            "type": "Quadrant"
        },
        {
            "quadrantType": "BOTTOM_RIGHT",
            "sensitivityPoints": [
                {
                    "row": 1,
                    "column": 1,
                    "sensitivityValue": 28.71,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 2,
                    "sensitivityValue": 29.98,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 3,
                    "sensitivityValue": 0.0,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 1,
                    "column": 4,
                    "sensitivityValue": 30.63,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 1,
                    "sensitivityValue": 29.37,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 2,
                    "sensitivityValue": 30.89,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 3,
                    "sensitivityValue": 31.39,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 2,
                    "column": 4,
                    "sensitivityValue": 26.13,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 1,
                    "sensitivityValue": 26.57,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 2,
                    "sensitivityValue": 28.35,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 3,
                    "column": 3,
                    "sensitivityValue": 28.53,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 1,
                    "sensitivityValue": 26.35,
                    "type": "SensitivityPoint"
                },
                {
                    "row": 4,
                    "column": 2,
                    "sensitivityValue": 26.37,
                    "type": "SensitivityPoint"
                }
            ],
            "type": "Quadrant"
        }
    ],
    "type": "VisualFieldMap"
}
```

### 4. **Extracted JSON Output**
```
{
    "type": "VisualFieldMap",
    "testID": "4148",
    "patientID": "4148",
    "testType": "visual_field",
    "eyeTested": "R eye",
    "date": null,
    "quadrants": [
        {
            "type": "Quadrant",
            "quadrantType": "TOP_LEFT",
            "sensitivityPoints": [
                {
                    "type": "SensitivityPoint",
                    "row": 1,
                    "column": 1,
                    "sensitivityValue": 8.98
                },
                {
                    "type": "SensitivityPoint",
                    "row": 1,
                    "column": 2,
                    "sensitivityValue": 17.34
                },
                {
                    "type": "SensitivityPoint",
                    "row": 1,
                    "column": 3,
                    "sensitivityValue": 13.9
                },
                {
                    "type": "SensitivityPoint",
                    "row": 1,
                    "column": 4,
                    "sensitivityValue": 11.85
                },
                {
                    "type": "SensitivityPoint",
                    "row": 2,
                    "column": 1,
                    "sensitivityValue": 18.67
                },
                {
                    "type": "SensitivityPoint",
                    "row": 2,
                    "column": 2,
                    "sensitivityValue": 24.62
                },
                {
                    "type": "SensitivityPoint",
                    "row": 2,
                    "column": 3,
                    "sensitivityValue": 22.13
                },
                {
                    "type": "SensitivityPoint",
                    "row": 2,
                    "column": 4,
                    "sensitivityValue": 19.72
                },
                {
                    "type": "SensitivityPoint",
                    "row": 3,
                    "column": 1,
                    "sensitivityValue": 18.27
                },
                {
                    "type": "SensitivityPoint",
                    "row": 3,
                    "column": 2,
                    "sensitivityValue": 25.08
                },
                {
                    "type": "SensitivityPoint",
                    "row": 3,
                    "column": 3,
                    "sensitivityValue": 29.22
                },
                {
                    "type": "SensitivityPoint",
                    "row": 3,
                    "column": 4,
                    "sensitivityValue": 29.37
                },
                {
                    "type": "SensitivityPoint",
                    "row": 4,
                    "column": 1,
                    "sensitivityValue": 17.17
                },
                {
                    "type": "SensitivityPoint",
                    "row": 4,
                    "column": 2,
                    "sensitivityValue": 19.85
                },
                {
                    "type": "SensitivityPoint",
                    "row": 4,
                    "column": 3,
                    "sensitivityValue": 27.19
                },
                {
                    "type": "SensitivityPoint",
                    "row": 4,
                    "column": 4,
                    "sensitivityValue": 32.48
                }
            ]
        },
        {
            "type": "Quadrant",
            "quadrantType": "TOP_RIGHT",
            "sensitivityPoints": [
                {
                    "type": "SensitivityPoint",
                    "row": 1,
                    "column": 5,
                    "sensitivityValue": 24.19
                },
                {
                    "type": "SensitivityPoint",
                    "row": 1,
                    "column": 6,
                    "sensitivityValue": 15.73
                },
                {
                    "type": "SensitivityPoint",
                    "row": 2,
                    "column": 5,
                    "sensitivityValue": 28.4
                },
                {
                    "type": "SensitivityPoint",
                    "row": 2,
                    "column": 6,
                    "sensitivityValue": 26.85
                },
                {
                    "type": "SensitivityPoint",
                    "row": 3,
                    "column": 5,
                    "sensitivityValue": 24.53
                },
                {
                    "type": "SensitivityPoint",
                    "row": 3,
                    "column": 6,
                    "sensitivityValue": 20.31
                },
                {
                    "type": "SensitivityPoint",
                    "row": 4,
                    "column": 5,
                    "sensitivityValue": 31.61
                },
                {
                    "type": "SensitivityPoint",
                    "row": 4,
                    "column": 6,
                    "sensitivityValue": 29.98
                }
            ]
        },
        {
            "type": "Quadrant",
            "quadrantType": "BOTTOM_LEFT",
            "sensitivityPoints": [
                {
                    "type": "SensitivityPoint",
                    "row": 5,
                    "column": 1,
                    "sensitivityValue": 20.71
                },
                {
                    "type": "SensitivityPoint",
                    "row": 5,
                    "column": 2,
                    "sensitivityValue": 24.57
                },
                {
                    "type": "SensitivityPoint",
                    "row": 5,
                    "column": 3,
                    "sensitivityValue": 28.99
                },
                {
                    "type": "SensitivityPoint",
                    "row": 5,
                    "column": 4,
                    "sensitivityValue": 30.76
                },
                {
                    "type": "SensitivityPoint",
                    "row": 6,
                    "column": 1,
                    "sensitivityValue": 24.63
                },
                {
                    "type": "SensitivityPoint",
                    "row": 6,
                    "column": 2,
                    "sensitivityValue": 29.12
                },
                {
                    "type": "SensitivityPoint",
                    "row": 6,
                    "column": 3,
                    "sensitivityValue": 31.49
                },
                {
                    "type": "SensitivityPoint",
                    "row": 6,
                    "column": 4,
                    "sensitivityValue": 31.19
                },
                {
                    "type": "SensitivityPoint",
                    "row": 7,
                    "column": 1,
                    "sensitivityValue": 26.59
                },
                {
                    "type": "SensitivityPoint",
                    "row": 7,
                    "column": 2,
                    "sensitivityValue": 28.92
                },
                {
                    "type": "SensitivityPoint",
                    "row": 7,
                    "column": 3,
                    "sensitivityValue": 24.9
                },
                {
                    "type": "SensitivityPoint",
                    "row": 8,
                    "column": 1,
                    "sensitivityValue": 28.81
                },
                {
                    "type": "SensitivityPoint",
                    "row": 8,
                    "column": 2,
                    "sensitivityValue": 24.72
                },
                {
                    "type": "SensitivityPoint",
                    "row": 8,
                    "column": 3,
                    "sensitivityValue": 26.35
                },
                {
                    "type": "SensitivityPoint",
                    "row": 8,
                    "column": 4,
                    "sensitivityValue": 26.37
                }
            ]
        },
        {
            "type": "Quadrant",
            "quadrantType": "BOTTOM_RIGHT",
            "sensitivityPoints": [
                {
                    "type": "SensitivityPoint",
                    "row": 5,
                    "column": 5,
                    "sensitivityValue": 30.59
                },
                {
                    "type": "SensitivityPoint",
                    "row": 5,
                    "column": 6,
                    "sensitivityValue": 28.71
                },
                {
                    "type": "SensitivityPoint",
                    "row": 6,
                    "column": 5,
                    "sensitivityValue": 29.98
                },
                {
                    "type": "SensitivityPoint",
                    "row": 6,
                    "column": 6,
                    "sensitivityValue": 0.0
                },
                {
                    "type": "SensitivityPoint",
                    "row": 7,
                    "column": 5,
                    "sensitivityValue": 29.37
                },
                {
                    "type": "SensitivityPoint",
                    "row": 7,
                    "column": 6,
                    "sensitivityValue": 30.89
                },
                {
                    "type": "SensitivityPoint",
                    "row": 8,
                    "column": 5,
                    "sensitivityValue": 31.39
                },
                {
                    "type": "SensitivityPoint",
                    "row": 8,
                    "column": 6,
                    "sensitivityValue": 26.13
                }
            ]
        }
    ]
}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**.

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **Precision:** 0.34615384615384615 resulting in an improvement of null from the previous iteration.
- **Recall:** 0.3050847457627119  resulting in an improvement of null from the previous iteration.
- **F1-score:** 0.32432432432432434 resulting in an improvement of null from the previous iteration.

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **Precision:** 0.325
- **Recall:** 0.2850877192982456
- **F1-score:** 0.3037383177570093

## **Historical Analysis of Errors**
Review these previous analyses and highlight long-standing sources of errors that have not been solved yet when evaluating the current extraction results:
```

### Good iterations

#### Iteration 1 with F1 score 0.890625

##### Extraction Guidelines

1. Identify the visual field test image and ensure it contains a grid structure with numerical values. 

2. Detect horizontal and vertical lines to establish the boundaries of the quadrants. 

3. Extract the testID, patientID, testType, eyeTested, and date from the image title and any relevant labels. The title format is "Visual Field Test - Patient {patientID} ({eyeTested})". 

4. Define the quadrants based on the grid structure:
   - TOP_LEFT
   - TOP_RIGHT
   - BOTTOM_LEFT
   - BOTTOM_RIGHT

5. For each quadrant, extract the sensitivity values from the grid cells. Use the labels at the top and left of the grid to determine the corresponding row and column for each sensitivity value.

6. Ensure that each sensitivity value is associated with its respective row and column, and format it as follows:
   - row: integer (1-indexed)
   - column: integer (1-indexed)
   - sensitivityValue: double (numerical value extracted from the grid)
   - type: "SensitivityPoint"

7. Structure the extracted data in JSON format according to the metamodel, ensuring that:
   - The main object is of type "VisualFieldMap".
   - Include an array of quadrants, each containing its quadrantType and an array of sensitivityPoints.

8. Validate the extracted data against the expected JSON structure to ensure compliance with the metamodel. 

9. Avoid overfitting by ensuring the guidelines are general enough to apply to various similar images, focusing on the grid structure and extraction principles rather than specific values or formats.
    
##### Reflection (Recommended Actions)





#### Iteration 1 with F1 score 0.7708333333333333

##### Extraction Guidelines

1. Begin by segmenting the image into four quadrants using the central horizontal and vertical lines. Label the quadrants as TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, and BOTTOM_RIGHT.

2. For each quadrant, identify the numerical values present. Ensure that you extract values based on their proximity to the quadrant labels, confirming their spatial positioning within the respective quadrants.

3. Apply containment rules to verify that each extracted value belongs to the correct quadrant. This involves checking the relative position of each value against the quadrant boundaries.

4. For each quadrant, create a list of sensitivity points. Each sensitivity point should include the following attributes:
   - `row`: The row number of the sensitivity point, starting from 1 at the top of the quadrant.
   - `column`: The column number of the sensitivity point, starting from 1 on the left side of the quadrant.
   - `sensitivityValue`: The extracted numerical value corresponding to the sensitivity point.
   - `type`: Set this to "SensitivityPoint".

5. Construct the JSON structure according to the metamodel. Begin with the main object representing the VisualFieldMap, including the following attributes:
   - `testID`: Extract from the image title or context.
   - `patientID`: Extract from the image title or context.
   - `testType`: Set this to "visual_field".
   - `eyeTested`: Extract from the image title or context (e.g., "L" for left eye).
   - `date`: Extract from the image title or context.

6. For each quadrant, create an object with the `quadrantType` attribute set to the corresponding quadrant label and a `sensitivityPoints` array containing the sensitivity points extracted in step 4.

7. Ensure that the final JSON structure aligns with the provided schema, encapsulating all extracted data accurately.

8. Validate the extracted JSON against the expected format to ensure compliance with the metamodel and extraction guidelines.
    
##### Reflection (Recommended Actions)

- **Enhance Date Extraction**: Update the extraction guidelines to specify a more robust method for identifying the date from the image title, ensuring it captures the correct format consistently. This will address the recurring issue of null values for the date field.

- **Refine Quadrant Detection**: Modify the extraction guidelines to include specific criteria for identifying quadrant boundaries, such as the use of color contrast or line thickness in the grid. This will help improve the accuracy of quadrant classification and reduce errors in sensitivity point extraction.

- **Standardize Sensitivity Value Extraction**: Implement a more structured approach in the guidelines for extracting sensitivity values, emphasizing the need to align values with their respective row and column labels accurately. This will mitigate discrepancies in sensitivity data across iterations.



#### Iteration 1 with F1 score 0.890625

##### Extraction Guidelines

1. Begin by identifying key text labels in the image, specifically "Visual Field Test," "Patient ID," and "L eye." Use these labels as anchors for data extraction.

2. Extract the patient ID by locating the text immediately following "Patient" in the label "Patient 3621." This value should be mapped to the `patientID` attribute in the JSON structure.

3. For the test type, use the label "Visual Field Test" to assign the value "visual_field" to the `testType` attribute.

4. Extract the eye tested from the label "L eye" and map this value to the `eyeTested` attribute.

5. Identify the date of the test, which may be included in the image or assumed to be the current date if not explicitly stated. Map this value to the `date` attribute.

6. Divide the visual field data into quadrants based on the layout of the numerical values in the image. The quadrants are typically defined as "TOP_LEFT," "TOP_RIGHT," "BOTTOM_LEFT," and "BOTTOM_RIGHT."

7. For each quadrant, extract the numerical values and their corresponding row and column positions. The first row and column should be indexed as 1.

8. Create a `Quadrant` object for each quadrant, mapping the extracted quadrant type to the `quadrantType` attribute.

9. For each numerical value extracted, create a `SensitivityPoint` object, mapping the row, column, and sensitivity value to their respective attributes. Assign the type "SensitivityPoint" to each of these objects.

10. Ensure that the extracted data maintains the hierarchical relationship defined in the metamodel, with `VisualFieldMap` containing an array of `Quadrant` objects, each containing an array of `SensitivityPoint` objects.

11. Structure the final extracted data in JSON format according to the schema defined by the metamodel, ensuring that all attributes are correctly populated and aligned. 

12. Validate the extracted JSON against the expected structure to ensure accuracy and completeness.
    
##### Reflection (Recommended Actions)

- **Enhance Sensitivity Value Alignment**: Update the extraction guidelines to specify that sensitivity values must be extracted based on their exact alignment with row and column labels, ensuring that each value is confirmed to be within the defined grid cells. This will address the recurring misalignment issues noted in previous iterations.

- **Implement Visual Cues for Quadrant Detection**: Introduce a method in the extraction guidelines to utilize visual cues such as grid lines and color contrast to more accurately identify quadrant boundaries. This will help in reducing errors related to quadrant classification, which have been persistent across iterations.

- **Standardize Data Formatting**: Revise the metamodel to enforce strict data type checks for sensitivity values, ensuring they are consistently formatted as doubles. This will help prevent discrepancies in the data structure and improve overall extraction accuracy.



#### Iteration 1 with F1 score 0.32432432432432434

##### Extraction Guidelines

1. Begin by identifying the grid structure formed by horizontal and vertical lines in the image. This grid will help define the boundaries of table cells.

2. Locate the intersections of these lines, which will serve as the boundaries for each cell in the grid.

3. Extract the numerical values contained within each cell. Ensure that each value is correctly associated with its respective row and column based on its position relative to the grid lines.

4. Identify the overall structure of the data, which consists of a visual field test for a specific patient. Extract the following metadata:
   - `testID`: Extract from the title of the image.
   - `patientID`: Extract from the title of the image.
   - `testType`: This should be set to "visual_field".
   - `eyeTested`: Extract from the title of the image (e.g., "R eye" for right eye).
   - `date`: This may not be explicitly stated in the image; if available, extract it from the context or metadata.

5. Organize the extracted numerical values into quadrants. Each quadrant corresponds to a specific section of the grid:
   - Define four quadrants: "TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", and "BOTTOM_RIGHT".

6. For each quadrant, create a list of sensitivity points. Each sensitivity point should include:
   - `row`: The row number of the sensitivity point.
   - `column`: The column number of the sensitivity point.
   - `sensitivityValue`: The extracted numerical value from the cell.
   - `type`: Set this to "SensitivityPoint".

7. Structure the extracted data in JSON format according to the schema defined by the metamodel. Ensure that the quadrants and their respective sensitivity points are nested correctly within the `VisualFieldMap` object.

8. Validate the final JSON structure against the expected schema to ensure all required fields are present and correctly formatted. 

9. Avoid overfitting by ensuring that the extraction process is adaptable to variations in the layout and content of similar images. Focus on the grid structure and numerical values rather than specific visual elements that may change.
    
##### Reflection (Recommended Actions)




### Backtracked iterations


```

## Analysis Task

Your task is to analyze discrepancies between the **extracted JSON** and the **expected JSON** with respect to the attached image, 
using the provided **evaluation metrics** and **historical analysis of errors**. Consider the following priorities (by order of importance):
1. Identify persistent errors that have appeared in **multiple iterations**, focus on addressing them either in the metamodel or in the extraction guidelines.
2. Give priority to those issues affecting to a larger part of the model.
3. Ensure that previous issues do not reappear after refinements. In particular, try to avoid those action that led to a worse result in the past.
4. If the improvement is small, make sure the recommendation emphatically asks for a more innovative approach.

For recommendations, give insights into how to extract data from the image more accurately, by identifying graphical elements such as lines, labels, shapes, 
or color boundaries that serve as delimiters for structured data and describing how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

## Your response

Respond with a simple bullet list list with the top 3 actionable recommendations to improve the extraction process, 
clearly indicating whether they have to be applied to the metamodel or the guidelines, and avoiding repeating previous suggestions.

Be as concise and directive as possible. The reflections will be used by a LLM to improve the extraction process using prompt engineering only.
