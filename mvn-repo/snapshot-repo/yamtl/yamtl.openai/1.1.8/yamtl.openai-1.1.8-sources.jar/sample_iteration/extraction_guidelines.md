1. Begin by segmenting the image into four quadrants using the central horizontal and vertical lines. Label each quadrant as TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, and BOTTOM_RIGHT.

2. For each quadrant, identify and extract numerical values that are spatially located within the boundaries of the quadrant. Ensure that these values are positioned near their respective quadrant labels.

3. For each extracted numerical value, determine its row and column position based on its location within the quadrant grid. Assign the appropriate row and column indices, starting from 1.

4. Each extracted numerical value should be classified as a sensitivity point. Ensure that each sensitivity point is structured with the following attributes: row, column, sensitivityValue (the extracted numerical value), and type (set to "SensitivityPoint").

5. Collect all sensitivity points for each quadrant and structure them under the corresponding quadrant type in the JSON format.

6. Extract the following metadata from the image: testID, patientID, testType, eyeTested, and date. Ensure these values are accurately captured and formatted as strings or dates as specified in the metamodel.

7. Construct the final JSON object according to the schema defined by the metamodel, ensuring that all extracted data elements are properly nested within their respective structures.

8. Validate the JSON structure against the expected format to ensure compliance with the metamodel and extraction guidelines.