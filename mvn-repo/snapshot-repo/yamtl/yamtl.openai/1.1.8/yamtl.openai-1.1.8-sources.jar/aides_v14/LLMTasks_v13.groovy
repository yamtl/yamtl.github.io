package aides_v14

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.EcorePackage
import org.eclipse.emf.ecore.resource.Resource

import apiClient_lambda.LLMClient
import apiClient_lambda.LLMUtil
import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped
import emf_syncer.EMFSyncer.ComparisonMode
import emf_syncer.dsl.FeatureMappingFactory
import emf_syncer.roles.SynchronizationMetricsRecord
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import prettyprinting.EMFPrettyPrinter
import untypedModel.UntypedModelPackage
import yamtl.core.YAMTLModule

class LLMTasks_v13 {
	
	
	static float TEMP_REFINEMENT = 0.4f
	static float TEMP_REFLECTION = 0.4f
	static float TEMP_META_SYSTEM = 0.2f
	static float TEMP_OBJECT_SYSTEM = 0.01f

	static LLM_MODEL_NAME_REFINEMENT = LLMUtil.GPT4oMini
	static LLM_MODEL_NAME_REFLECTION = LLMUtil.GPT4oMini
	static LLM_MODEL_NAME_META_SYSTEM = LLMUtil.GPT4oMini
	static LLM_MODEL_NAME_OBJECT_SYSTEM = LLMUtil.GPT4oMini
	
	static MAX_TOKENS = 512  // Maximum tokens for LLM
	
	
	
	static String SYSTEM_CONTEXT = """
Our system extracts structured data from images based on a **metamodel** and predefined **extraction guidelines**. 
The **metamodel** defines entities, attributes, and relationships, 
while the **extraction guidelines** instruct how to extract and format data into a JSON structure. 

After processing, the extracted JSON is compared with an expected JSON reference. 
Evaluation metrics (precision, recall, and F1-score) indicate alignment between 
the extracted and expected data (ground truth). 
"""
	
	static void generateOrRefineMetamodel(String imageUrl, String mimetype, String strategyText, String expectedJsonPath,
													   String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath,
													   String strategyId, int iteration, String parentStrategyId) {
		if (parentStrategyId == "") {
			generateMetamodel( imageUrl, mimetype, strategyText, new File(expectedJsonPath).text,
										   outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
		} else {
			def outputDirPath =  new File(new File(outputMetamodelJsonPath).parent).parent
			
			// get the best iteration until now
			def logFile = new File("output/iterations.json")
			def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
			
			
			// TODO: need to find the parent strategy of the current strategy: it's failing because collect{it.strategyId == strategyId.toString()} returns empty
			def parentEntry = pastIterations.find{it.strategy_id == parentStrategyId.toString()}
			def prev_dirPath = SpecificationSearchEngine.generateOutputDirPath(outputDirPath, parentEntry.iteration)
			
			// get the previous guidelines from its corresponding folder
			if (!new File(prev_dirPath).exists()) {
				prev_dirPath = "${prev_dirPath}_BACKTRACKED"
			}
			
			def prevOutputJsonText = iteration > 0 ? "${prev_dirPath}/extractedData.json" : null
			def prevMetamodelJsonPath = iteration > 0 ? "${prev_dirPath}/generated_metamodel.json" : null
			def prevMetamodelEcorePath = iteration > 0 ? "${prev_dirPath}/generated_metamodel.ecore" : null
			def prevGuidelinesPath = iteration > 0 ? "${prev_dirPath}/extraction_guidelines.md" : null
			def analysisPath = iteration > 0 ? "${prev_dirPath}/analysis.md" : null
			
			new File(outputMetamodelJsonPath).text = new File(prevMetamodelJsonPath).text
			new File(outputEcorePath).text = new File(prevMetamodelEcorePath).text
			
			
//			refineMetamodel( imageUrl, mimetype, strategyText, prevOutputJsonText, expectedJsonPath,
//										 prevMetamodelJsonPath, prevGuidelinesPath, analysisPath,
//										 outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
		}
	}

	
	
	/**
	 * Generates a textual metamodel and extraction guidelines for a given image using LLM.
	 * Stores the metamodel in structured textual format and generates extraction guidelines.
	 */
	static void generateMetamodel(
	   String imageUrl, String mimetype,
	   String strategyText,
	   String expectedJson,
	   String outputMetamodelJsonPath, String outputEcorePath,
	   String outputGuidelinesPromptPath) 
	{
		println "⚙️ Generating metamodel for: ${imageUrl}"
		// Call LLM to infer a metamodel from the image
		def client = new LLMClient()
		
		def metamodelPrompt = """
${SYSTEM_CONTEXT}

Given the attached image that contains unstructured data and a oracle json document 
with the extracted data from this image, generate a textual description 
of the domain model that helps capture the extracted data. 
The textual description should include:
- **Entities** (class names)
- **Intrinsic properties** (attributes with types)
- **Extrinsic properties** (relationships with multiplicities (lower bound, upper bound) and constraints - composition, uniqueness, ordering, etc.)

Only include relevant concepts without making additional assumptions that are not 
clearly aligned with the provided data.

### Expected output of our system

${expectedJson}
"""
	
		def refinedMetamodel_text = client.call_prompt_with_image_url(metamodelPrompt.toString(), imageUrl, mimetype, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
//		println('------------------')
//		println("Extracted metamodel: ${refinedMetamodel_text.body.message}")
		
		def metamodel_json = client.extractMetamodel(refinedMetamodel_text.body.message, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
//		println('------------------')
//		println("Extracted metamodel Ecore: ${JsonOutput.prettyPrint(JsonOutput.toJson( metamodel_json.body.message ))}")
		Utils.saveJson(metamodel_json.body.message, outputMetamodelJsonPath)
		
		// Save extracted metamodel
		EPackage metamodel = EcorePackage.eINSTANCE;

		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))

		syncer.loadSourceModel(outputMetamodelJsonPath)
		
		// FIX: map current
		syncer.forwardSync()
		
		syncer.saveTargetModel(outputEcorePath)

	}

	
	
	
	
	
	
	
	
	
	
	static void refineMetamodel(
			 String imageUrl, String mimetype,
			 String strategyText,
			 String prevOutputJsonPath, String expectedJsonPath,
			 String prevMetamodelJsonPath, String prevGuidelinesPath,
			 String analysisPath,
			 String outputMetamodelJsonPath, String outputEcorePath,
			 String outputGuidelinesPromptPath
	) {
		println "⚙️ Refining metamodel for: ${imageUrl}"

		
		String dirPath = new File(outputMetamodelJsonPath).parent
		
		String prevMetamodelText = new File(prevMetamodelJsonPath).text
		String prevGuidelinesText = new File(prevGuidelinesPath).text
		String prevOutputJsonText = new File(prevOutputJsonPath).text
		String expectedJsonText = new File(expectedJsonPath).text
		String analysisText = new File(analysisPath).text

	
		def client = new LLMClient()
	
		
		
		
		// **Step 1: Refinement Prompt for Metamodel**
		def metamodelRefinementPrompt = """
${SYSTEM_CONTEXT}

A previous iteration of the extraction process produced **evaluation results** (precision, recall, F1-score) 
both at object and feature levels, comparing the extracted JSON with the expected JSON (ground truth).
Errors in the extraction process have been analyzed, and **specific refinements** have been suggested.

### **Your Task:**
Refine the **metamodel** below based on the given analysis. Make targeted changes without discarding correct elements.

### **Previous Metamodel (Ecore model in JSON Format)**
```
${prevMetamodelText}
```

### **Previous Extraction Guidelines**
```
${prevGuidelinesText}
```

### **Analysis of Extraction Errors**
```
${analysisText}
```

### **Instructions:**
- Improve the metamodel by adding, removing, or modifying entities, attributes, and relationships.
- Preserve correct structures unless the analysis suggests specific changes.
- Do not discard the entire metamodel. Modify only what is necessary.
- Return the refined metamodel in a structured textual format, highlighting:
  - Entities (class names)
  - Intrinsic properties (attributes with types)
  - Extrinsic properties (relationships with multiplicities, constraints - composition, uniqueness, ordering, etc.)
"""
	
//		def refinedMetamodel_text = client.call_prompt(metamodelRefinementPrompt.toString(), llmModel.value, Utils.getApiKey(llmModel), MAX_TOKENS, temp)
//		println('------------------')
//		println("Refined Metamodel: ${refinedMetamodel_text.body.message}")
	
		// Convert refined metamodel to JSON (Ecore format)
		def refinedMetamodel_json = client.extractMetamodel(metamodelRefinementPrompt.toString(), LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
		def newMetamodelText = JsonOutput.prettyPrint(JsonOutput.toJson(refinedMetamodel_json.body.message))
		Utils.saveJson(refinedMetamodel_json.body.message, outputMetamodelJsonPath)
	
		// Save refined metamodel as Ecore model
		EPackage metamodel = EcorePackage.eINSTANCE
	
		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
	
		syncer.loadSourceModel(outputMetamodelJsonPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputEcorePath)
	
	}
	
	
	
	
	static String generateOrRefineGuidelines(String imageUrl, String mimetype, String strategyText, String expectedJsonPath, String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath,
													   String strategyId, int iteration, String parentStrategyId) {
		if (parentStrategyId == "") {
			generateGuidelines( imageUrl, mimetype, strategyText, new File(expectedJsonPath).text, outputEcorePath, outputGuidelinesPromptPath)
		} else {
			def outputDirPath =  new File(new File(outputMetamodelJsonPath).parent).parent
			
			// get the best iteration until now
			def logFile = new File("output/iterations.json")
			def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
			
			
			// TODO: need to find the parent strategy of the current strategy: it's failing because collect{it.strategyId == strategyId.toString()} returns empty
			def parentEntry = pastIterations.find{it.strategy_id == parentStrategyId.toString()}
			def prev_dirPath = SpecificationSearchEngine.generateOutputDirPath(outputDirPath, parentEntry.iteration)
			
			// get the previous guidelines from its corresponding folder
			if (!new File(prev_dirPath).exists()) {
				prev_dirPath = "${prev_dirPath}_BACKTRACKED"
			}
			
			def prevOutputJsonText = iteration > 0 ? "${prev_dirPath}/extractedData.json" : null
			def prevMetamodelJsonPath = iteration > 0 ? "${prev_dirPath}/generated_metamodel.json" : null
			def prevGuidelinesPath = iteration > 0 ? "${prev_dirPath}/extraction_guidelines.md" : null
			def analysisPath = iteration > 0 ? "${prev_dirPath}/analysis.md" : null
			
			refineGuidelines( imageUrl, mimetype, strategyText, prevOutputJsonText, expectedJsonPath,
										 outputEcorePath, prevGuidelinesPath, analysisPath,
										 outputGuidelinesPromptPath)
		}
	}


	
	static String generateGuidelines(
		String imageUrl, String mimetype,
		String strategyText,
		String expectedJson,
		String outputEcorePath,
		String outputGuidelinesPromptPath) {
		println "⚙️ Generating extraction guidelines for: ${imageUrl}"
		// Call LLM to infer a metamodel from the image
		def client = new LLMClient()
			
		
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		
		
		// Identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.
		
		// Generate extraction guidelines using LLM
		def guidelinePrompt = """
${SYSTEM_CONTEXT}

Based on the Ecore metamodel below, generate precise extraction guidelines for another LLM to process similar images and accurately extract relevant data:
1. Extract data elements from images similar to the one attached, avoiding overfitting. 
2. Use this strategy to extract data from the image: ${strategyText}.
3. Structure the extracted data in JSON format according to the schema defined by the metamodel below.

### Metamodel

${metamodel_puml}

### Oracle JSON Document

${expectedJson}

### Your Task

Write a self-contained guidelines to extract all relevant data (according to the metamodel) from the given image according to the following principles:
- Ensure alignment with the refined metamodel.
- Be as concise and targeted as possible.
- Write the guidelines using markdown but do not use headers or subheaders (with `#`, `##` etc).
- Your guidelines will be instructions for another LLM to process similar images and accurately extract relevant data.
- The guidelines should be applicable to other examples, it is important to avoid overfitting.
"""
		
		def extractionGuidelines = client.call_prompt_with_image_url(guidelinePrompt.toString(), imageUrl, mimetype, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
		//		println('------------------')
		//		println('Extraction guidelines: ' + extractionGuidelines.body.message)
		
		return extractionGuidelines.body.message
	}



	
	
	
	static String refineGuidelines(
		 String imageUrl, String mimetype,
		 String strategyText,
		 String prevOutputJsonPath, String expectedJsonPath,
		 String outputEcorePath, String prevGuidelinesPath,
		 String analysisPath,
		 String outputGuidelinesPromptPath
    ) {
		println "⚙️ Refining extraction guidelines for: ${imageUrl}"

		
		String dirPath = new File(prevOutputJsonPath).parent
		
		
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		
	
		String prevGuidelinesText = new File(prevGuidelinesPath).text
		String prevOutputJsonText = new File(prevOutputJsonPath).text
		String expectedJsonText = new File(expectedJsonPath).text
		String analysisText = new File(analysisPath).text

	
		def client = new LLMClient()
	
		
	
		// **Step 2: Refinement Prompt for Extraction Guidelines**
		def guidelineRefinementPrompt = """
${SYSTEM_CONTEXT}

The metamodel and extraction guidelines must be **refined** based on evaluation metrics and analysis of extraction errors.


### Metamodel (Ecore model in PlantUML Format)
```
${metamodel_puml}
```

### **Previous Extraction Guidelines**
```
${prevGuidelinesText}
```

### **Recommended updates**
```
${analysisText}
```

### Your task

Remember the aim of the data extraction guidelines for another LLM to process similar images and accurately extract relevant data:
1. Extract data elements from images similar to the one attached, avoiding overfitting. 
2. Use this strategy to extract data from the image: ${strategyText}.
3. Structure the extracted data in JSON format according to the schema defined by the metamodel below.

Write a self-contained update of the **previous extraction guidelines** (without saying it is a refinement) to address the recommended updates above according to the following principles:
- Ensure alignment with the refined metamodel.
- Be as concise and targeted as possible.
- Write the guidelines using markdown but do not use headers or subheaders (with `#`, `##` etc).
- Your guidelines will be instructions for another LLM to process similar images and accurately extract relevant data.
"""
		
// Identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

		
	
		def refinedGuidelines = client.call_prompt_with_image_url(guidelineRefinementPrompt.toString(), imageUrl, mimetype, LLM_MODEL_NAME_REFINEMENT.value, Utils.getApiKey(LLM_MODEL_NAME_REFINEMENT), MAX_TOKENS, TEMP_REFINEMENT)
		return refinedGuidelines.body.message

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	static def extractDataFromImage(String imageUrl, String mimetype, String outputEcorePath, String ouputGuidelinesPromptPath, String outputJsonPath) {
		
		def guidelines = new File(ouputGuidelinesPromptPath).text
//		println("""⚙️ Applying extraction guidelines (${ouputGuidelinesPromptPath}) to image...
//
//${guidelines}
//""")
		
		def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)

		def client = new LLMClient()
		def response = client.extractTypedJsonFromImageUrl(guidelines, metamodelPuml, imageUrl, mimetype, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)

		def jsonFile = new File(outputJsonPath)
		jsonFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(response.body.message))

		println("\t✔️ Extracted JSON response saved to tmp.json")
		return response
	}

	
	static void ensureFeatureMappings(String outputEcorePath, String outputFeatureMappingJsonPath) {

		if (SpecificationSearchEngine.SKIP_FEATURE_MAPPINGS_GEN)
			return
		
		if (!new File(outputFeatureMappingJsonPath).exists()) {
			println "⚠ Feature mappings file not found: ${outputFeatureMappingJsonPath}"
			println "⚙️ Generating a new feature mappings file..."
			
			// Generate the feature mappings
			generateFeatureMappings( outputEcorePath, outputFeatureMappingJsonPath)
		} else {
			println "\t✔️ Feature mappings file found: ${outputFeatureMappingJsonPath}"
			
			// Read the existing feature mappings
			def fileContents = new File(outputFeatureMappingJsonPath).text
			
			
			def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)

			println("""
------------------
Metamodel (PlantUML): 
${metamodel_puml}

Feature mappigns (JSON):
${JsonOutput.prettyPrint(fileContents)}
------------------
""")
	
		}
		
		Utils.waitForUserConfirmation()
				
		println "\t✔️ Feature mappings confirmed. Proceeding with comparison."
	}

	
	
	
	
	
	static String generateOrRefineStrategies(String imageUrl, String mimetype, int branching_factor, Map bestStrategy, String reflectionIfBacktracking) {

		if (bestStrategy) {
			refineStrategy(imageUrl, mimetype, branching_factor, bestStrategy, reflectionIfBacktracking)
		} else {
			generateStrategies(imageUrl, mimetype, branching_factor)
		}
	}
	
	
	static String generateStrategies(String imageUrl, String mimetype, int branching_factor) {
		def prompt = """

${SYSTEM_CONTEXT}

### **Your Task**
Analyze the given image and propose **${branching_factor}  distinct extraction strategies** that the **object-system** LLM 
can apply to extract structured data. Each strategy must:
- **Be clearly different from one another.**
- **Be tailored to the specific visual structure of the image.**
- **Leverage different types of visual and geometric cues.**
- **Include concrete and explicit rules for spatial positioning and feature alignment.**


### **Guidelines for Strategy Generation**
Each strategy should follow a different approach and **must incorporate at least two** of the following spatial and structural cues:

1. **Graphical Delimiters & Boundary Detection**
   - Identify **lines, boxes, labels, shapes, or color boundaries** that act as **delimiters** for structured data.
   - Specify **how these elements define layout positioning**, such as **table cells, chart axes, or quadrant divisions**.

2. **Spatial Relationships & Relative Positioning**
   - Specify if elements are **above, below, to the left, or right** of key reference points (e.g., labels, axes, column headers).
   - Identify **containment relationships**, ensuring values **belong to the correct section**.

3. **Hierarchical Data Organization**
   - Define how **nested elements (e.g., quadrant sensitivity values)** relate to **higher-level labels (e.g., test ID, quadrant name)**.
   - Describe **rules for assigning extracted values** to the correct entity in the JSON structure.

4. **Pattern-Based Identification**
   - Specify how patterns in **alignment, spacing, color intensity, or text formatting** help distinguish structured data.
   - Use **heuristics to differentiate text labels from extracted values**.

5. **Textual Anchors & Alignment with Metamodel**
   - Define rules for mapping **text labels to expected attributes** in the JSON schema.
   - Ensure **consistent alignment between extracted data and the expected model structure**.

### Response Format

Return a JSON list of exactly ${branching_factor} strategies, each following this schema:

```plantuml
class Strategy {
  id: int
  name: String
  guidelines: String
}
```


Example **JSON output format**:
```json
[
  {
    "id": 1,
    "name": "Grid-Based Sensitivity Extraction Using Label Alignment",
    "guidelines": "Detect structured grid by identifying intersections of vertical and horizontal lines. Use text labels positioned above and to the left of sensitivity values as anchors for assigning quadrant types and row/column indices. Ensure extracted values are positioned within the correct quadrant boundary by verifying containment within detected grid regions."
  },
  ...
]
```


### Important Considerations

- Strategies **must be distinct and leverage different methods** for extracting structured data.
- Each strategy **must explicitly describe how spatial relationships, text positioning, and graphical boundaries** define structured data.
- The **LLM must generate concrete and structured extraction guidelines**, avoiding vague descriptions.
- Ensure strategies **align with the metamodel and JSON schema** while being feasible for LLM-based extraction.

**Your task is to generate a structured, well-defined list of ${branching_factor} distinct extraction strategies that will be tested systematically.**
"""
		def client = new LLMClient()
		def response = client.call_prompt_with_image_url_to_json(prompt, imageUrl, mimetype, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
		return response.body
	}
	
	

	
	
	
	
	static String refineStrategy(String imageUrl, String mimetype, int branching_factor, Map strategy, String reflectionIfBacktracking) {
		def prompt = """

${SYSTEM_CONTEXT}


## Analysis of previously failed refinements

${reflectionIfBacktracking}

## Strategy to be refined

The following strategy must be preserved and refined to improve the extraction process:
* Strategy name: ${strategy.name}
* Strategy guidelines: ${strategy.guidelines}

### Response Format

Return a JSON list of exactly ${branching_factor} strategies, each following this schema:

```plantuml
class Strategy {
  id: int
  name: String
  guidelines: String
}
```


Example **JSON output format**:
```json
[
  {
    "id": 1,
    "name": "Grid-Based Sensitivity Extraction Using Label Alignment",
    "guidelines": "Detect structured grid by identifying intersections of vertical and horizontal lines. Use text labels positioned above and to the left of sensitivity values as anchors for assigning quadrant types and row/column indices. Ensure extracted values are positioned within the correct quadrant boundary by verifying containment within detected grid regions."
  },
  ...
]
```

## **Your Task**
Analyze the given image and propose **${branching_factor}  distinct extraction strategies** that the **object-system** LLM 
can apply to extract structured data. Each strategy must refine the given strategy below and must:
- **Be clearly different from one another.**
- **Be tailored to the specific visual structure of the image.**
- **Leverage different types of visual and geometric cues.**
- **Include concrete and explicit rules for spatial positioning and feature alignment.**

### Important Considerations

- The new strategies must be consistent with the given strategy but propose meaningful refinements to add detail and improve the extraction process.
- Strategies **must be distinct and leverage different methods** for extracting structured data.
- Each strategy **must explicitly describe how spatial relationships, text positioning, and graphical boundaries** define structured data.
- The **LLM must generate concrete and structured extraction guidelines**, avoiding vague descriptions.
- Ensure strategies **align with the metamodel and JSON schema** while being feasible for LLM-based extraction.

**Your task is to generate a structured, well-defined list of ${branching_factor} distinct extraction strategies that will be tested systematically.**
"""
		def client = new LLMClient()
		def response = client.call_prompt_with_image_url_to_json(prompt, imageUrl, mimetype, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
		return response.body
	}

	
	
	
	
	
	
	static void generateFeatureMappings(String outputEcorePath, String outputFeatureMappingJsonPath) {

		println "⚙️ Generating feature mappings for metamodel: ${outputEcorePath}"
	
		// Convert Ecore to EMFatic format
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		if (!metamodel_puml || metamodel_puml.trim().isEmpty()) {
			throw new RuntimeException("Failed to convert Ecore metamodel to EMFatic format. Ensure the metamodel is valid.")
		}
	
		// Construct LLM Prompt
		def prompt = """
Given this Ecore metamodel in EMFatic format:

```
${metamodel_puml}
```

We want to configure EMFSyncer to compare models of this metamodel. **EMFSyncer** synchronizes models by 
**matching objects via a similarity relation** rather than exact equality. 
Objects are aligned using **fingerprints** and **distinguishing attributes** (e.g., `id`, `name`).

**Feature selection guidance for LLM:**
1. **Prioritize distinguishing attributes** (e.g., unique IDs, names) for matching objects.
2. **Exclude mutable attributes** that may vary despite objects being the same.
3. **Use FeatureMapping** to define which attributes are synchronized.
4. **Enable renaming or transformation** where feature names differ between models.

Apply the following heuristics:
* Each class should have at least one feature selected.
* Use attributes that look like identifiers first.
* If no attributes look like identifiers, use references that look like identifiers.
* Use containment references only if strictly necessary (i.e., to check structural consistency when there is no eOpposite reference of the containment reference).

Create a JSON configuration file specifying the selected features using this format:

json
[
  {
    "className": "..",
    "featureName": ".."
  }
]


The **LLM should select features** that uniquely **identify objects** but avoid including **all properties**, ensuring **schema alignment** while preserving flexibility in model comparison.

Produce **JSON only** and nothing else.
"""
	
		// Send the prompt to LLM
		def client = new LLMClient()
		def response = client.call_prompt_to_json(prompt, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
	
		// Extract response body
		def featureMappingsJson = response?.body
		if (!featureMappingsJson || featureMappingsJson.trim().isEmpty()) {
			throw new RuntimeException("LLM response is empty or invalid. Check API response for errors.")
		}
	
		// Save feature mappings to JSON file
		def outputFile = new File(outputFeatureMappingJsonPath)
		outputFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(new JsonSlurper().parseText(featureMappingsJson)))
	
		println "\t✔️ Feature mappings saved: ${outputFeatureMappingJsonPath}"
	}

	
	
	
	
	
	
	
		
		
		static String analyseExtractedData(
			String imageUrl, String mimetype,
			String outputJsonPath, String gtJsonPath,
			String outputEcorePath, String ouputGuidelinesPromptPath,
			String outputAnalysisPath,
			Map iterationEntry) {
		
			def dirPath =  new File(ouputGuidelinesPromptPath).parent
			
			
			// Retrieve past analyses from log file
			def logFile = new File("output/iterations.json")
			def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
			
			
			def goodDecisions = pastIterations.findAll { !it.containsKey('backtracked_to_iteration') }.collect {
				"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}

##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
			}.join("\n\n")
			
			def backtrackedDecisions = pastIterations.findAll { it.containsKey('backtracked_to_iteration') }.collect {
				"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}
 
##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
			}.join("\n\n")
			
			def pastAnalyses = """
### Good iterations
${goodDecisions}

### Backtracked iterations
${backtrackedDecisions}
"""
			
		
			def prompt = """
${SYSTEM_CONTEXT}

## Available Information

### 1. **Current Metamodel (PlantUML format)**
```
${EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)}
```

### 2. **Current Extraction Guidelines**
```
${new File(ouputGuidelinesPromptPath).text}
```

### 3. **Expected JSON Output (Ground Truth)**
```
${new File(gtJsonPath).text}
```

### 4. **Extracted JSON Output**
```
${new File(outputJsonPath).text}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**.

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **Precision:** ${iterationEntry.metrics.objectPrecision} resulting in an improvement of ${iterationEntry.precision_increment} from the previous iteration.
- **Recall:** ${iterationEntry.metrics.objectRecall}  resulting in an improvement of ${iterationEntry.recall_increment} from the previous iteration.
- **F1-score:** ${iterationEntry.metrics.objectF1} resulting in an improvement of ${iterationEntry.f1_score_increment} from the previous iteration.

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **Precision:** ${iterationEntry.metrics.featurePrecision}
- **Recall:** ${iterationEntry.metrics.featureRecall}
- **F1-score:** ${iterationEntry.metrics.featureF1}

## **Historical Analysis of Errors**
Review these previous analyses and highlight long-standing sources of errors that have not been solved yet when evaluating the current extraction results:
```
${pastAnalyses}
```

## Analysis Task

Your task is to analyze discrepancies between the **extracted JSON** and the **expected JSON** with respect to the attached image, 
using the provided **evaluation metrics** and **historical analysis of errors**. Consider the following priorities (by order of importance):
1. Identify persistent errors that have appeared in **multiple iterations**, focus on addressing them either in the metamodel or in the extraction guidelines.
2. Give priority to those issues affecting to a larger part of the model.
3. Ensure that previous issues do not reappear after refinements. In particular, try to avoid those action that led to a worse result in the past.
4. If the improvement is small, make sure the recommendation emphatically asks for a more innovative approach.

For recommendations, give insights into how to extract data from the image more accurately, by identifying graphical elements such as lines, labels, shapes, 
or color boundaries that serve as delimiters for structured data and describing how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

## Your response

Respond with a simple bullet list list with the top 3 actionable recommendations to improve the extraction process, 
clearly indicating whether they have to be applied to the metamodel or the guidelines, and avoiding repeating previous suggestions.

Be as concise and directive as possible. The reflections will be used by a LLM to improve the extraction process using prompt engineering only.
"""
		
			new File("${dirPath}/prompt_reflection.md").text = prompt
	
	
			// Send refinement prompt to LLM
			def client = new LLMClient()
			def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
		
			def analysisData = response?.body?.message
			if (!analysisData || analysisData.trim().isEmpty()) {
				throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
			}
		
			// Save analysis to file
			new File(outputAnalysisPath).text = analysisData
			println "\t✔️ Analysis saved: ${outputAnalysisPath}"
		
			return analysisData
		}
		
		
		
		
		
		
		static String analyseExtractedDataForBacktracking(
			String imageUrl, String mimetype,
			String outputJsonPath, String gtJsonPath,
			String outputEcorePath, 
			String ouputGuidelinesPromptPath,
			String outputAnalysisPath,
			Map iterationEntry) {
		
			
			def dirPath =  new File(ouputGuidelinesPromptPath).parent
		
			// Retrieve past analyses from log file
			def logFile = new File("output/iterations.json")
			def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
	
			
			
			def goodDecisions = pastIterations.findAll { !it.containsKey('backtracked_to_iteration') }.collect {
				"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}

##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
			}.join("\n\n")
			
			def backtrackedDecisions = pastIterations.findAll { it.containsKey('backtracked_to_iteration') }.collect {
				"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}
 
##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
			}.join("\n\n")
			
			def pastAnalyses = """
### Good iterations
${goodDecisions}

### Backtracked iterations
${backtrackedDecisions}
"""
			
			
			
			
		
			def prompt = """
${SYSTEM_CONTEXT}

## Available Information

### 1. **Current Metamodel (PlantUML format)**
```
${EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)}
```

### 2. **Current Extraction Guidelines**
```
${new File(ouputGuidelinesPromptPath).text}
```

### 3. **Expected JSON Output (Ground Truth)**
```
${new File(gtJsonPath).text}
```

### 4. **Extracted JSON Output**
```
${new File(outputJsonPath).text}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**.

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **Precision:** ${iterationEntry.metrics.objectPrecision} resulting in a deterioration of ${iterationEntry.precision_increment} from the previous iteration.
- **Recall:** ${iterationEntry.metrics.objectRecall}  resulting in a deterioration of ${iterationEntry.recall_increment} from the previous iteration.
- **F1-score:** ${iterationEntry.metrics.objectF1} resulting in a deterioration of ${iterationEntry.f1_score_increment} from the previous iteration.

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **Precision:** ${iterationEntry.metrics.featurePrecision}
- **Recall:** ${iterationEntry.metrics.featureRecall}
- **F1-score:** ${iterationEntry.metrics.featureF1}

## **Historical Analysis of Errors**
Review these previous analyses and highlight long-standing sources of errors that have not been solved yet when evaluating the current extraction results:

```
${pastAnalyses}
```

## Analysis Task

The current iteration has shown a decrease in the F1-score compared to the best iteration as shown above. If the deterioration is substantial, sugest a drastic change in the extraction guidelines or metamodel from what was proposed for this iteration.

Your task is to identify the top 3 reasons for this decrease and suggest targeted refinements to address them.

Aim to fix those issues that affect a larger part of the model and have appeared in multiple iterations and not yet solved.

In particular, identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

Respond with a brief list bullet points, clearly indicating whether they have to be applied to the metamodel or the guidelines.

Remember that the recommendations are for an LLM to improve the extraction process using prompt engineering only.
"""
		
	
			new File("${dirPath}/prompt_reflection.md").text = prompt
	
		
			// Send refinement prompt to LLM
			def client = new LLMClient()
			def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
		
			def analysisData = response?.body?.message
			if (!analysisData || analysisData.trim().isEmpty()) {
				throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
			}
		
			// Save analysis to file
			new File(outputAnalysisPath).text = analysisData
			println "\t✔️ Analysis saved: ${outputAnalysisPath}"
		
			return analysisData
		}
		
		
		
		
		
		
		
		
		
		
		static String reflectionForBacktracking(
			String imageUrl, String mimetype,
			Map parentNode,
			List nodeList) {
		
			
			def backtrackedDecisions = nodeList.collect {
				"""
#### Attempt ${it.strategy_id} with F1 score ${it.metrics.objectF1}
 
##### Strategy Name

${it.strategy_name}

##### Strategy Aim

${it.strategy_aim}

##### Extraction Guidelines

${it.extraction_guidelines}
"""
			}.join("\n\n")
			
			
			
			
		
			def prompt = """
${SYSTEM_CONTEXT}

## Available Information

### Best strategy so far

##### Strategy Name

${parentNode.strategy_name}

##### Strategy Aim

${parentNode.strategy_aim}

##### Extraction Guidelines

${parentNode.extraction_guidelines}


### Failed attempts

The following attempts led to poorer performance and were backtracked:

${backtrackedDecisions}


## Analysis Task

The current iteration has shown a decrease in the F1-score compared to the best iteration as shown above. If the deterioration is substantial, sugest a drastic change in the extraction guidelines or metamodel from what was proposed for this iteration.

Your task is to identify the top 3 reasons for this decrease and suggest targeted refinements to address them.

Aim to fix those issues that affect a larger part of the model and have appeared in multiple iterations and not yet solved.

In particular, identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

Respond with a brief list bullet points, clearly indicating whether they have to be applied to the metamodel or the guidelines.

Remember that the recommendations are for an LLM to improve the extraction process using prompt engineering only.
"""
		
	
		
			// Send refinement prompt to LLM
			def client = new LLMClient()
			def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
		
			def analysisData = response?.body?.message
			if (!analysisData || analysisData.trim().isEmpty()) {
				throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
			}
		
			return analysisData
		}
		
		
		
		
		
		
		
		static def convertJsonToEMF(String outputJsonPath, String outputEcorePath, String outputXmiPath) {
			
			
	//		def jsonSlurper = new JsonSlurper()
	//		def jsonListOrMap = jsonSlurper.parseText(new File(outputJsonPath).text)
	//		def isValid = checkForTypeField(jsonListOrMap)
	//
	//		if (isValid) {
			
				Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
				EPackage metamodel = (EPackage) metamodelRes.getContents().get(0)
		
				def syncer = new EMFSyncer()
				syncer.enableEagerMode()
				syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
				syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
				
				syncer.loadSourceModel(outputJsonPath)
				syncer.forwardSync()
				syncer.saveTargetModel(outputXmiPath)
	
				println("\t✔️ Model saved to ${outputXmiPath}")
	//		}
		}
		
		static def validateExtractedModelAgainstExpected(String gtJsonPath, String outputEcorePath, String outputXmiPath) {
	
			println "🔍 Validating extracted model against expected JSON..."
		
			// Load metamodel
			Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
			EPackage metamodel = metamodelRes.contents[0] as EPackage
		
			// Setup EMFSyncer
			def syncer = new EMFSyncer()
			syncer.enableEagerMode()
			syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
			syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
		
			// Convert expected JSON into EMF model
			syncer.loadSourceModel(gtJsonPath)
			syncer.forwardSync()
			syncer.saveTargetModel(outputXmiPath)
		
			
			def metrics = syncer.getForwardMetrics()
			return metrics
		}
		
		
		
		
		
		/**
		 * Configure the EMFSyncer with feature mappings and compare two models.
		 *
		 * Flexible but relies on manual input.
		 *
		 * @param metamodelFilePath
		 * @param extractedModelPath
		 * @param gtModelPath
		 * @param featureMappingFile
		 * @return
		 */
		static def compareModels(String outputEcorePath, String outputFeatureMappingJsonPath, String outputXmiPath, String gtXmiPath)  {
			def metamodel = YAMTLModule.preloadMetamodel(outputEcorePath)
			def pk = metamodel.contents[0] as EPackage
		
			def syncer = new EMFSyncer()
			syncer.setSourceModelHandler(new EMFSyncerParameter_EMF("e", [pk: pk]))
			syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("g", [pk: pk]))
			syncer.enableStateExtent()
		
			// Validate and Load Feature Mappings
			def mappingFile = new File(outputFeatureMappingJsonPath)
			if (!mappingFile.exists()) {
				throw new RuntimeException("Feature mapping file not found: ${outputFeatureMappingJsonPath}")
			}
		
			def mappingsJson
			try {
				mappingsJson = new JsonSlurper().parseText(mappingFile.text)
			} catch (Exception e) {
				throw new RuntimeException("Error parsing feature mapping file: ${e.message}")
			}
		
			// Ensure mappings have correct format
			def mappings = []
			mappingsJson.each { entry ->
				if (!(entry instanceof Map) || !entry.containsKey("className") || !entry.containsKey("featureName")) {
					throw new RuntimeException("Invalid feature mapping format in ${featureMappingFile}. Expected keys: 'className' and 'featureName'")
				}
				mappings << FeatureMappingFactory.create(entry.className, entry.featureName, entry.className, entry.featureName)
			}
		
			syncer.setSimilarityRelation(true, mappings, ComparisonMode.EXACT)
		
			// Load Models and Get Root Objects
			def sourceModelRootObjects = []
			try {
				sourceModelRootObjects = syncer.getModelContents(outputXmiPath)
			} catch (Exception e) {
				println("⚠️ Error loading source model: ${e.message}")
				return new SynchronizationMetricsRecord()
			}
			def targetModelRootObjects = syncer.getModelContents(gtXmiPath)
		
			if (sourceModelRootObjects.isEmpty() || targetModelRootObjects.isEmpty()) {
				throw new RuntimeException("Error: One or both models have no root objects. Ensure the extracted and ground truth models are correctly formatted.")
			}
		
			syncer.setSourceModel(sourceModelRootObjects)
			syncer.setTargetModel(targetModelRootObjects)
		
			// Perform Model Comparison
			syncer.match()
		
			def metrics = syncer.getForwardMetrics()
			return metrics
		}
		
		
		
		
	
}
