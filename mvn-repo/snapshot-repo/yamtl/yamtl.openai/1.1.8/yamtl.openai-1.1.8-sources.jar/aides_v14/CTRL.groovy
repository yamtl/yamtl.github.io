package aides_v14

class CTRL {
	static void main(String...args) {
	    println "📝 Do these mappings look correct? Press ENTER to confirm or type 'q'/'quit' to exit."
	
	    def input = System.in.newReader().readLine()?.trim()
	
	    if (input in ["q", "quit"]) {
	        println "❌ Script exited by user."
	        System.exit(1)
	    }
	}
}
