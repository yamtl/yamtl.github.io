package aides_v14

import emf_syncer.roles.SynchronizationMetricsRecord

class SearchNode {
	static int nodeCounter = 0  // A static counter to assign unique IDs
	static int BRANCHING_FACTOR = 2
	
	
	int id	
    String strategyId
    String strategyName
    String strategyAim
	String guidelines
	SynchronizationMetricsRecord metrics 
	
	String outputDirPath
	
	int branchingFactor = 2
	SearchNode parentNode = null

		
		
    /**
     * Compute the successor nodes for this search node.
     */
    List<SearchNode> getSuccessors(String imageUrl, String mimetype, int branchingFactor, String outputDirPath, SearchNode bestParentNode, String reflectionIfBacktracking) {
        def decisionStrategy = new DecisionStrategyImpl_Default()
        def candidates = decisionStrategy.generateCandidates(imageUrl, mimetype, bestParentNode, reflectionIfBacktracking, branchingFactor)
        return candidates.collect { candidate ->
            def node = new SearchNode()
			node.id = ++nodeCounter
            node.strategyId = generateBranchId(node.id)
            node.strategyName = candidate.name
            node.strategyAim = candidate.aim
			node.outputDirPath = generateOutputDirPath(outputDirPath, nodeCounter)
			def iterationDir = new File(node.outputDirPath)
			if (!iterationDir.exists()) iterationDir.mkdirs()
				
            return node
        }
    }
	
	
	
	def generateBranchId(int counter) {
		def depth = counter.intdiv(BRANCHING_FACTOR)
		def branchIndex = counter % BRANCHING_FACTOR
		return "Depth_${String.format('%02d',depth)}_Branch_${String.format('%02d',branchIndex)}_Node_${String.format('%02d',counter)}"
	}

	def String generateOutputDirPath(outputDirPath, iteration) {
		return "${outputDirPath}/${generateBranchId(iteration)}".toString()
	}
	

}
