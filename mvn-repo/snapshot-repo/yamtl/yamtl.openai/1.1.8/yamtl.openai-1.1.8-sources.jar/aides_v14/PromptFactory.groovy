package aides_v14

import emf_syncer.roles.SynchronizationMetricsRecord

class PromptFactory {

    static final String SYSTEM_CONTEXT = """
Our system extracts structured data from images based on a **metamodel** and predefined **extraction guidelines**. 
The **metamodel** defines entities, attributes, and relationships, 
while the **extraction guidelines** instruct how to extract and format data into a JSON structure. 

After processing, the extracted JSON is compared with an expected JSON reference. 
Evaluation metrics (precision, recall, and F1-score) indicate alignment between 
the extracted and expected data (ground truth). 
"""

    static String createMetamodelPrompt(String expectedJson) {
        return """
${SYSTEM_CONTEXT}

Given the attached image that contains unstructured data and a oracle json document 
with the extracted data from this image, generate a textual description 
of the domain model that helps capture the extracted data. 
The textual description should include:
- **Entities** (class names)
- **Intrinsic properties** (attributes with types)
- **Extrinsic properties** (relationships with multiplicities (lower bound, upper bound) and constraints - composition, uniqueness, ordering, etc.)

Only include relevant concepts without making additional assumptions that are not 
clearly aligned with the provided data.

### Expected output of our system

${expectedJson}
"""
    }

    static String createMetamodelRefinementPrompt(String prevMetamodelText, String prevGuidelinesText, String analysisText) {
        return """
${SYSTEM_CONTEXT}

A previous iteration of the extraction process produced **evaluation results** (precision, recall, F1-score) 
both at object and feature levels, comparing the extracted JSON with the expected JSON (ground truth).
Errors in the extraction process have been analyzed, and **specific refinements** have been suggested.

### Your Task:
Refine the **metamodel** below based on the given analysis. Make targeted changes without discarding correct elements.

### Previous Metamodel (Ecore model in JSON Format)
```
${prevMetamodelText}
```

### Previous Extraction Guidelines
```
${prevGuidelinesText}
```

### Analysis of Extraction Errors
```
${analysisText}
```

### Instructions:
- Improve the metamodel by adding, removing, or modifying entities, attributes, and relationships.
- Preserve correct structures unless the analysis suggests specific changes.
- Do not discard the entire metamodel. Modify only what is necessary.
- Return the refined metamodel in a structured textual format, highlighting:
  - Entities (class names)
  - Intrinsic properties (attributes with types)
  - Extrinsic properties (relationships with multiplicities, constraints - composition, uniqueness, ordering, etc.)
"""
    }

    static String createGuidelinesPrompt(String strategyText, String metamodelPuml, String expectedJson) {
        return """
${SYSTEM_CONTEXT}

Based on the Ecore metamodel below, generate precise extraction guidelines for another LLM to process similar images and accurately extract relevant data:
1. Extract data elements from images similar to the one attached, avoiding overfitting. 
2. Use this strategy to extract data from the image: ${strategyText}.
3. Structure the extracted data in JSON format according to the schema defined by the metamodel below.

### Metamodel
${metamodelPuml}

### Oracle JSON Document
${expectedJson}

### Your Task
Write a self-contained guidelines to extract all relevant data (according to the metamodel) from the given image according to the following principles:
- Ensure alignment with the refined metamodel.
- Be as concise and targeted as possible.
- Write the guidelines using markdown but do not use headers or subheaders (with `#`, `##` etc).
- Your guidelines will be instructions for another LLM to process similar images and accurately extract relevant data.
- The guidelines should be applicable to other examples, it is important to avoid overfitting.
"""
    }

    static String createGuidelinesRefinementPrompt(String metamodelPuml, String prevGuidelinesText, String analysisText, String strategyText) {
        return """
${SYSTEM_CONTEXT}

The metamodel and extraction guidelines must be **refined** based on evaluation metrics and analysis of extraction errors.

### Metamodel (Ecore model in PlantUML Format)
```
${metamodelPuml}
```

### Previous Extraction Guidelines
```
${prevGuidelinesText}
```

### Recommended updates
```
${analysisText}
```

### Your task
Remember the aim of the data extraction guidelines for another LLM to process similar images and accurately extract relevant data:
1. Extract data elements from images similar to the one attached, avoiding overfitting. 
2. Use this strategy to extract data from the image: ${strategyText}.
3. Structure the extracted data in JSON format according to the schema defined by the metamodel below.

Write a self-contained update of the **previous extraction guidelines** (without saying it is a refinement) to address the recommended updates above according to the following principles:
- Ensure alignment with the refined metamodel.
- Be as concise and targeted as possible.
- Write the guidelines using markdown but do not use headers or subheaders (with `#`, `##` etc).
- Your guidelines will be instructions for another LLM to process similar images and accurately extract relevant data.
"""
    }

    static String createStrategyPrompt(int branchingFactor) {
        return """
${SYSTEM_CONTEXT}

### **Your Task**
Analyze the given image and propose **${branchingFactor} distinct extraction strategies** that the **object-system** LLM 
can apply to extract structured data. Each strategy must:
- **Be clearly different from one another.**
- **Be tailored to the specific visual structure of the image.**
- **Leverage different types of visual and geometric cues.**
- **Include concrete and explicit rules for spatial positioning and feature alignment.**

### **Guidelines for Strategy Generation**
Each strategy should follow a different approach and **must incorporate at least two** of the following spatial and structural cues:

1. **Graphical Delimiters & Boundary Detection**
   - Identify **lines, boxes, labels, shapes, or color boundaries** that act as **delimiters** for structured data.
   - Specify **how these elements define layout positioning**, such as **table cells, chart axes, or quadrant divisions**.

2. **Spatial Relationships & Relative Positioning**
   - Specify if elements are **above, below, to the left, or right** of key reference points (e.g., labels, axes, column headers).
   - Identify **containment relationships**, ensuring values **belong to the correct section**.

3. **Hierarchical Data Organization**
   - Define how **nested elements (e.g., quadrant sensitivity values)** relate to **higher-level labels (e.g., test ID, quadrant name)**.
   - Describe **rules for assigning extracted values** to the correct entity in the JSON structure.

4. **Pattern-Based Identification**
   - Specify how patterns in **alignment, spacing, color intensity, or text formatting** help distinguish structured data.
   - Use **heuristics to differentiate text labels from extracted values**.

5. **Textual Anchors & Alignment with Metamodel**
   - Define rules for mapping **text labels to expected attributes** in the JSON schema.
   - Ensure **consistent alignment between extracted data and the expected model structure**.

### Response Format

Return a JSON list of exactly ${branchingFactor} strategies, each following this schema:

```plantuml
class Strategy {
  id: int
  name: String
  aim: String
}
```

Example **JSON output format**:
```json
[
  {
    "id": 1,
    "name": "Grid-Based Sensitivity Extraction Using Label Alignment",
    "aim": "Detect structured grid by identifying intersections of vertical and horizontal lines. Use text labels positioned above and to the left of sensitivity values as anchors for assigning quadrant types and row/column indices. Ensure extracted values are positioned within the correct quadrant boundary by verifying containment within detected grid regions."
  },
  ...
]
```

### Important Considerations
- Strategies **must be distinct and leverage different methods** for extracting structured data.
- Each strategy **must explicitly describe how spatial relationships, text positioning, and graphical boundaries** define structured data.
- The **LLM must generate concrete and structured extraction guidelines**, avoiding vague descriptions.
- Ensure strategies **align with the metamodel and JSON schema** while being feasible for LLM-based extraction.

**Your task is to generate a structured, well-defined list of ${branchingFactor} distinct extraction strategies that will be tested systematically.**
"""
    }

    static String createStrategyRefinementPrompt(int branchingFactor, SearchNode node, String reflectionIfBacktracking) {
        return """
${SYSTEM_CONTEXT}

## Analysis of previously failed refinements

${reflectionIfBacktracking}

## Strategy to be refined

The following strategy must be preserved and refined to improve the extraction process:
* Strategy name: ${node.strategyName}
* Strategy aim: ${node.strategyAim}

### Response Format

Return a JSON list of exactly ${branchingFactor} strategies, each following this schema:

```plantuml
class Strategy {
  id: int
  name: String
  aim: String
}
```

Example **JSON output format**:
```json
[
  {
    "id": 1,
    "name": "Grid-Based Sensitivity Extraction Using Label Alignment",
    "aim": "Detect structured grid by identifying intersections of vertical and horizontal lines. Use text labels positioned above and to the left of sensitivity values as anchors for assigning quadrant types and row/column indices. Ensure extracted values are positioned within the correct quadrant boundary by verifying containment within detected grid regions."
  },
  ...
]
```

## **Your Task**
Analyze the given image and propose **${branchingFactor} distinct extraction strategies** that the **object-system** LLM 
can apply to extract structured data. Each strategy must refine the given strategy below and must:
- **Be clearly different from one another.**
- **Be tailored to the specific visual structure of the image.**
- **Leverage different types of visual and geometric cues.**
- **Include concrete and explicit rules for spatial positioning and feature alignment.**

### Important Considerations
- The new strategies must be consistent with the given strategy but propose meaningful refinements to add detail and improve the extraction process.
- Strategies **must be distinct and leverage different methods** for extracting structured data.
- Each strategy **must explicitly describe how spatial relationships, text positioning, and graphical boundaries** define structured data.
- The **LLM must generate concrete and structured extraction guidelines**, avoiding vague descriptions.
- Ensure strategies **align with the metamodel and JSON schema** while being feasible for LLM-based extraction.

**Your task is to generate a structured, well-defined list of ${branchingFactor} distinct extraction strategies that will be tested systematically.**
"""
    }

    static String createFeatureMappingsPrompt(String metamodelPuml) {
        return """
Given this Ecore metamodel in EMFatic format:

```
${metamodelPuml}
```

We want to configure EMFSyncer to compare models of this metamodel. **EMFSyncer** synchronizes models by 
**matching objects via a similarity relation** rather than exact equality. 
Objects are aligned using **fingerprints** and **distinguishing attributes** (e.g., `id`, `name`).

**Feature selection guidance for LLM:**
1. **Prioritize distinguishing attributes** (e.g., unique IDs, names) for matching objects.
2. **Exclude mutable attributes** that may vary despite objects being the same.
3. **Use FeatureMapping** to define which attributes are synchronized.
4. **Enable renaming or transformation** where feature names differ between models.

Apply the following heuristics:
* Each class should have at least one feature selected.
* Use attributes that look like identifiers first.
* If no attributes look like identifiers, use references that look like identifiers.
* Use containment references only if strictly necessary (i.e., to check structural consistency when there is no eOpposite reference of the containment reference).

Create a JSON configuration file specifying the selected features using this format:

json
[
  {
    "className": "..",
    "featureName": ".."
  }
]

The **LLM should select features** that uniquely **identify objects** but avoid including **all properties**, ensuring **schema alignment** while preserving flexibility in model comparison.

Produce **JSON only** and nothing else.
"""
    }

	
	
	
    static String createAnalysisPrompt(
		String metamodelPuml, 
		String guidelinesText, 
		String expectedJsonText, 
		String extractedJsonText, 
		SearchNode node
	) {
				
		
        return """
${SYSTEM_CONTEXT}

## Available Information

### 1. **Current Metamodel (PlantUML format)**
```
${metamodelPuml}
```

### 2. **Current Extraction Guidelines**
```
${guidelinesText}
```

### 3. **Expected JSON Output (Ground Truth)**
```
${expectedJsonText}
```

### 4. **Extracted JSON Output**
```
${extractedJsonText}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**.

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **Precision:** ${node.metrics.objectPrecision} ${node.parentNode ? "resulting in an improvement of ${node.metrics.objectPrecision - node.parentNode.metrics.objectPrecision} from the previous iteration" : ''}.
- **Recall:** ${node.metrics.objectRecall} ${node.parentNode ? "resulting in an improvement of ${node.metrics.objectRecall - node.parentNode.metrics.objectRecall} from the previous iteration" : ""}.
- **F1-score:** ${node.metrics.objectF1} ${node.parentNode ? "resulting in an improvement of ${node.metrics.objectF1 - node.parentNode.metrics.objectF1} from the previous iteration" : ""}.

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **Precision:** ${node.metrics.featurePrecision}
- **Recall:** ${node.metrics.featureRecall}
- **F1-score:** ${node.metrics.featureF1}

## Analysis Task

Your task is to analyze discrepancies between the **extracted JSON** and the **expected JSON** with respect to the attached image, 
using the provided **evaluation metrics** and **historical analysis of errors**. Consider the following priorities (by order of importance):
1. Identify persistent errors that have appeared in **multiple iterations**, focus on addressing them either in the metamodel or in the extraction guidelines.
2. Give priority to those issues affecting a larger part of the model.
3. Ensure that previous issues do not reappear after refinements. In particular, try to avoid those action that led to a worse result in the past.
4. If the improvement is small, make sure the recommendation emphatically asks for a more innovative approach.

For recommendations, give insights into how to extract data from the image more accurately, by identifying graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describing how these elements define the layout and positioning of data, specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

## Your response

Respond with a simple bullet list with the top 3 actionable recommendations to improve the extraction process, 
clearly indicating whether they have to be applied to the metamodel or the guidelines, and avoiding repeating previous suggestions.

Be as concise and directive as possible. The reflections will be used by a LLM to improve the extraction process using prompt engineering only.
"""
    }

	
	
    static String createAnalysisBacktrackingPrompt(
		String metamodelPuml, 
		String guidelinesText, 
		String expectedJsonText, 
		String extractedJsonText, 
		SearchNode node
	) {
        return """
${SYSTEM_CONTEXT}

## Available Information

### 1. **Current Metamodel (PlantUML format)**
```
${metamodelPuml}
```

### 2. **Current Extraction Guidelines**
```
${guidelinesText}
```

### 3. **Expected JSON Output (Ground Truth)**
```
${expectedJsonText}
```

### 4. **Extracted JSON Output**
```
${extractedJsonText}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**.

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **Precision:** ${node.metrics.objectPrecision} resulting in a deterioration of ${node.metrics.objectPrecision - node.parentNode.metrics.objectPrecision} from the previous iteration.
- **Recall:** ${node.metrics.objectRecall} resulting in a deterioration of ${node.metrics.objectRecall - node.parentNode.metrics.objectRecall} from the previous iteration.
- **F1-score:** ${node.metrics.objectF1} resulting in a deterioration of ${node.metrics.objectF1 - node.parentNode.metrics.objectF1} from the previous iteration.

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **Precision:** ${node.metrics.featurePrecision}
- **Recall:** ${node.metrics.featureRecall}
- **F1-score:** ${node.metrics.featureF1}

## Analysis Task

The current iteration has shown a decrease in the F1-score compared to the best iteration as shown above. If the deterioration is substantial, suggest a drastic change in the extraction guidelines or metamodel from what was proposed for this iteration.

Your task is to identify the top 3 reasons for this decrease and suggest targeted refinements to address them.

Aim to fix those issues that affect a larger part of the model and have appeared in multiple iterations and not yet solved.

In particular, identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

Respond with a brief list bullet points, clearly indicating whether they have to be applied to the metamodel or the guidelines.
"""
    }
	
	
	

    static String createReflectionForBacktrackingPrompt(String bestStrategyName, String bestStrategyAim, String bestStrategyGuidelines, String backtrackedDecisions) {
        return """
${SYSTEM_CONTEXT}

## Available Information

### Best strategy so far

##### Strategy Name
${bestStrategyName}

##### Strategy Aim
${bestStrategyAim}

##### Extraction Guidelines
${bestStrategyGuidelines}

### Failed attempts
The following attempts led to poorer performance and were backtracked:
${backtrackedDecisions}

## Analysis Task
The current iteration has shown a decrease in the F1-score compared to the best iteration as shown above. If the deterioration is substantial, suggest a drastic change in the extraction guidelines or metamodel from what was proposed for this iteration.

Your task is to identify the top 3 reasons for this decrease and suggest targeted refinements to address them.

Aim to fix those issues that affect a larger part of the model and have appeared in multiple iterations and not yet solved.

In particular, identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

Respond with a brief list bullet points, clearly indicating whether they have to be applied to the metamodel or the guidelines.

Remember that the recommendations are for an LLM to improve the extraction process using prompt engineering only.
"""
    }
}