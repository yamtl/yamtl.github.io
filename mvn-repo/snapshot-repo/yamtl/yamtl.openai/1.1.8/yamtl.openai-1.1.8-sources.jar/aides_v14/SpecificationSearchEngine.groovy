package aides_v14

//import static aides.LLMTasksStub.*
import static aides_v14.LLMTasks.*

import java.text.SimpleDateFormat

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.resource.Resource

import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped
import emf_syncer.EMFSyncer.ComparisonMode
import emf_syncer.dsl.FeatureMappingFactory
import emf_syncer.roles.SynchronizationMetricsRecord
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import untypedModel.UntypedModelPackage
import yamtl.core.YAMTLModule

class SpecificationSearchEngine {
	

	static boolean SKIP_FEATURE_MAPPINGS_GEN = false

	static OUTPUT_DIRPATH = "output/"
	
	static STRATEGY_COUNTER = "strategy_counter.txt"

	static BRANCHING_FACTOR = 2
	static MAX_BRANCH_DEPTH = 2
	static MAX_ITERATIONS = 1
	static MAX_EXAMPLES = 1
	
	
	static F1_THRESHOLD = 0.87f  // F1-score threshold to stop refinement

//	static int global_iteration_counter = 0
	
	
	
	static void main(String... args) {
										
//		String imageUrl = "https://raw.githubusercontent.com/yamtl/llm-files/refs/heads/main/images/patient-3910-l.png"  // Replace with a real image URL
//		String gtJsonPath = "src/main/resources/3910L.json"  // Path to example expected JSON
		
		
		String mimetype = "image/png"
		
		String featureMappingsFilePath = "src/main/resources/generated_emfsyncer_mappings.json"
		if (featureMappingsFilePath)
			SKIP_FEATURE_MAPPINGS_GEN = true
		
		
		def datasetPath = "src/main/resources/sample_10.json"
		def jsonSlurper = new JsonSlurper()
		def jsonData = new File(datasetPath).text
		def entries = jsonSlurper.parseText(jsonData)
			
		
		// initialise files
		def logFilePath = "${OUTPUT_DIRPATH}/iterations.json".toString()
		File outputDir = new File(OUTPUT_DIRPATH)
		if (outputDir.exists()) {
			new File(logFilePath).delete()
			outputDir.deleteDir()
		}
		
		
		int exampleCount = 1
		entries.each { entry ->
			if (exampleCount > MAX_EXAMPLES) {
				return // Stop processing if max examples or max iterations are reached
			}
			
			
			def imageUrl = entry.url
			def gtJson = entry.json
			
			
			runRefinementLoop(imageUrl, mimetype, gtJson, OUTPUT_DIRPATH, featureMappingsFilePath, BRANCHING_FACTOR, F1_THRESHOLD)
			
			exampleCount++
		}
		
		println(generateReport(logFilePath))
		
		System.exit(0)
		
	}
	
	
	
	
	static void runRefinementLoop(String imageUrl, String mimetype, Map gtJson, String outputDirPath, String featureMappingsFilePath, int BRANCHING_FACTOR, float F1_THRESHOLD) {
	    def logFilePath = "${outputDirPath}/iterations.json"
	    File outputDir = new File(outputDirPath)
		
		SearchNode bestParentNode = new SearchNode()
		String reflectionIfBacktracking = ""
		
		
		def childNodeList = new ArrayList<>()
		
		for (depthCounter in 1..MAX_BRANCH_DEPTH) {
				
			
			def candidateNodeList = bestParentNode.getSuccessors(imageUrl, mimetype, BRANCHING_FACTOR, outputDirPath, bestParentNode, reflectionIfBacktracking)

			for (node in candidateNodeList) {
				
				String outputMetamodelJsonPath = "${node.outputDirPath}/generated_metamodel.json"
				String outputEcorePath = "${node.outputDirPath}/generated_metamodel.ecore"
				String outputGuidelinesPromptPath = "${node.outputDirPath}/guidelines.md"
				String outputJsonPath = "${node.outputDirPath}/extractedData.json"
				String outputXmiPath = "${node.outputDirPath}/extractedData.xmi"
				String outputAnalysisPath = "${node.outputDirPath}/analysis.md"
				String outputFeatureMappingJsonPath = featureMappingsFilePath ?: "${node.outputDirPath}/generated_emfsyncer_mappings.json"
				String expectedJsonPath = "${node.outputDirPath}/gtModel.json"
				String gtXmiPath = "${node.outputDirPath}/gtModel.xmi"

	            // Run extraction pipeline with the current strategy
				def metrics = runSingleIteration(imageUrl, mimetype, gtJson, 
					outputDirPath,
					node, 
	                 outputMetamodelJsonPath, outputEcorePath, 
	                 outputGuidelinesPromptPath, outputJsonPath, 
	                 outputXmiPath, outputAnalysisPath, 
	                 outputFeatureMappingJsonPath, expectedJsonPath, 
	                 gtXmiPath)
				node.metrics = metrics
					
	            // Log metrics for each strategy
	            println("""
-----------------------------------------------
Results for Strategy: ${node.strategyId}
Object F1-Score: ${metrics?.objectF1 ?: 'N/A'}
-----------------------------------------------""")
				
				// Store decision node in log
				storeDecisionNode(
					node, 
					outputEcorePath, outputGuidelinesPromptPath, outputJsonPath, expectedJsonPath, outputAnalysisPath , logFilePath)
				
				
			
				def analysis = (bestParentNode && metrics.objectF1 < bestParentNode.metrics.objectF1) ?
					analyseExtractedDataForBacktracking(imageUrl, mimetype, outputJsonPath, expectedJsonPath, outputEcorePath, outputGuidelinesPromptPath, outputAnalysisPath, node) :
					analyseExtractedData(imageUrl, mimetype, outputJsonPath, expectedJsonPath, outputEcorePath, outputGuidelinesPromptPath, outputAnalysisPath, node)
				
					
				childNodeList.add(node)
				
	        }
	

			
			
			def bestCandidate = childNodeList.max{it.metrics.objectF1}	
			if (bestParentNode == null) {
				bestParentNode = bestCandidate
			} else {
				bestParentNode = [bestParentNode, bestCandidate].max{it.metrics.objectF1}
			}
			
			if (bestParentNode != bestCandidate) {
				reflectionIfBacktracking = reflectionForBacktracking(imageUrl, mimetype, bestParentNode, childNodeList)
				println("""
-----------------------------------------------
REFLECTION FOR BACKTRACKING
${reflectionIfBacktracking}
-----------------------------------------------
""")
			} else {
				reflectionIfBacktracking = ""
			}
			childNodeList.clear()
		}
	}

	
	
	
	
	
	/**
	 * Runs a single iteration of the refinement pipeline and returns the computed metrics.
	 */
	static SynchronizationMetricsRecord runSingleIteration(String imageUrl, String mimetype, Map gtJson, 
		String outputDirPath,
		SearchNode node,
        String outputMetamodelJsonPath, String outputEcorePath, 
        String outputGuidelinesPromptPath, String outputJsonPath, 
        String outputXmiPath, String outputAnalysisPath, 
        String outputFeatureMappingJsonPath, String expectedJsonPath, 
        String gtXmiPath) 
    {
		if (node.parentNode)
			copyFeatureMappingsAndReflection(node)

	
		// Save expected JSON for comparison
		Utils.saveJson(gtJson, expectedJsonPath)
	
		// Step 1: Generate or refine the metamodel and guidelines
		generateOrRefineMetamodel(imageUrl, mimetype, node, expectedJsonPath, outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
		def guidelines = generateOrRefineGuidelines(imageUrl, mimetype, node, expectedJsonPath, outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
		node.guidelines = guidelines
		new File(outputGuidelinesPromptPath).text = guidelines
		
		// Step 2: Extract Data
		extractDataFromImage(imageUrl, mimetype, outputEcorePath, outputGuidelinesPromptPath, outputJsonPath)
	
		// Step 3: Convert Extracted JSON to EMF Model
		convertJsonToEMF(outputJsonPath, outputEcorePath, outputXmiPath)
	
		// Step 4: Ensure Feature Mappings
		ensureFeatureMappings(outputEcorePath, outputFeatureMappingJsonPath)
	
		// Step 5: Convert Ground Truth JSON to EMF Model
		convertJsonToEMF(expectedJsonPath, outputEcorePath, gtXmiPath)
	
		// Step 6: Compare Extracted Model with Ground Truth
		SynchronizationMetricsRecord  metrics = compareModels(outputEcorePath, outputFeatureMappingJsonPath, outputXmiPath, gtXmiPath)
	
		return metrics
	}
	
	

	/**
	 * Stores a newly evaluated decision node in the decision tree log.
	 *
	 * @param strategyId        Globally unique identifier for this strategy.
	 * @param parentStrategyId  Identifier of the parent strategy (null for root nodes).
	 * @param depth             Depth level in the search tree.
	 * @param decisionPath      List of strategy IDs leading to this decision.
	 * @param iteration         Current iteration number.
	 * @param metrics           Performance metrics from runSingleIteration.
	 * @param outputEcorePath   Path to the generated Ecore model.
	 * @param outputGuidelinesPath Path to the applied extraction guidelines.
	 * @param outputJsonPath    Path to the extracted JSON output.
	 * @param gtJsonPath        Path to the expected JSON output (ground truth).
	 * @param outputAnalysisPath Path to the generated analysis report.
	 * @param logFilePath       Path to the decision tree log file.
	 */
	static Map storeDecisionNode(SearchNode node, String outputEcorePath,
								  String outputGuidelinesPath, String outputJsonPath, String gtJsonPath,
								  String outputAnalysisPath, String logFilePath) {
	
		def logFile = new File(logFilePath)
		def decisionTree = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
		
		
		def nodeEntry = [
			"parentStrategyId": node.parentNode? node.parentNode.strategyId : "",
			"strategyId": node.strategyId,
			"strategyName": node.strategyName,
			"strategyAim": node.guidelines,
			"guidelines": new File(outputGuidelinesPath).text,
			"iteration": node.id,
			"timestamp": new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date()),
			"metamodel": outputEcorePath,
			"extracted_output": outputJsonPath,
			"expected_output": gtJsonPath,
			"metrics": node.metrics.toMap(),
			"previous_analysis": new File(outputAnalysisPath).exists() ? new File(outputAnalysisPath).text : ""
		]
	
		// Append to decision tree and persist
		decisionTree << nodeEntry
		logFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(decisionTree))
	
		return nodeEntry
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// HELPERS
	
	
	static void copyFeatureMappingsAndReflection(SearchNode node) {
		
		if (node.id > 1) {
			if (node.parentNode == null) {
				new RuntimeException("Cannot copy feature mappings and reflection for root node.")
			}
			
			def prevIterationDirPath = node.parentNode.outputDirPath
			def iterationDirPath = node.outputDirPath
			
			File prevMappingFile = new File("${prevIterationDirPath}/generated_emfsyncer_mappings.json")
			File newMappingFile = new File("${iterationDirPath}/generated_emfsyncer_mappings.json")
	
			if (prevMappingFile.exists() && !newMappingFile.exists()) {
				newMappingFile.text = prevMappingFile.text
			}
			
			File prevReflectionFile = new File("${prevIterationDirPath}/analysis.md")
			File newReflectionFile = new File("${iterationDirPath}/previous_analysis.md")
	
			if (prevReflectionFile.exists() && !newReflectionFile.exists()) {
				newReflectionFile.text = prevReflectionFile.text
			}
		}
	}

	
	def getHighestObjectF1Iteration(String jsonFilePath) {
		Map json = new JsonSlurper().parse(new File(jsonFilePath))
		def highest = json.max { it.metrics.objectF1 }
		return highest.iteration
	}

	

	
	def static checkForTypeField(value) {
		if (value instanceof Map) {
			// If it's a Map, check if it has the 'type' field
			if (!value.containsKey('type')) {
				println "Missing 'type' field in map: $value"
				return false
			}
			// Recursively check the values inside the map
			value.each { key, val ->
				if (!checkForTypeField(val)) {
					return false
				}
			}
		} else if (value instanceof List) {
			// If it's a List, check all the items in the list
			value.each { item ->
				if (!checkForTypeField(item)) {
					return false
				}
			}
		}
		return true
	}


	
	static String generateReport(String filePath) {
		def jsonSlurper = new groovy.json.JsonSlurper()
		def jsonFile = new File(filePath)
		def data = jsonSlurper.parse(jsonFile)
		String text = ""
	
		data.each { entry ->
			def strategyId = entry.strategyId
			def parentStrategyId = entry.parentStrategyId
			def objectF1 = entry.metrics.objectF1
			def strategyName = entry.strategyName
			def aim = entry.strategyAim
			def guidelines = entry.guidelines.replaceAll("\n", "  \n") // formatting newline for markdown
	
			text +=  """
## Node ID: $strategyId

* Strategy Name: ${strategyName}
* Object F1 Score: ${objectF1}
* Parent Strategy ID: ${parentStrategyId}

### Aim 

${aim}

### Guidelines:"

$guidelines
"""
		}
		
		return text
	}
}
