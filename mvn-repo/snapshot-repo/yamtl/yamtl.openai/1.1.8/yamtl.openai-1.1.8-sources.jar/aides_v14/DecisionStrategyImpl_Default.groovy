package aides_v14

import groovy.json.JsonSlurper

class DecisionStrategyImpl_Default implements DecisionStrategy {
    @Override
    List<Map> generateCandidates(String imageUrl, String mimetype, SearchNode bestParentNode, String reflectionIfBacktracking, int branchingFactor) {
        // Reuse your existing logic here
        def strategiesJsonText = aides_v14.LLMTasks.generateOrRefineStrategies(imageUrl, mimetype, branchingFactor, bestParentNode, reflectionIfBacktracking)
        def slurper = new JsonSlurper()
        return slurper.parseText(strategiesJsonText)
    }
}
