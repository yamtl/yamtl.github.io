package aides_v14

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.EcorePackage
import org.eclipse.emf.ecore.resource.Resource
import apiClient_lambda.LLMClient
import apiClient_lambda.LLMUtil
import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped
import emf_syncer.EMFSyncer.ComparisonMode
import emf_syncer.dsl.FeatureMappingFactory
import emf_syncer.roles.SynchronizationMetricsRecord
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import prettyprinting.EMFPrettyPrinter
import untypedModel.UntypedModelPackage
import yamtl.core.YAMTLModule

class LLMTasks {

    static float TEMP_REFINEMENT = 0.4f
    static float TEMP_REFLECTION = 0.4f
    static float TEMP_META_SYSTEM = 0.2f
    static float TEMP_OBJECT_SYSTEM = 0.01f

    static LLM_MODEL_NAME_REFINEMENT = LLMUtil.GPT4oMini
    static LLM_MODEL_NAME_REFLECTION = LLMUtil.GPT4oMini
    static LLM_MODEL_NAME_META_SYSTEM = LLMUtil.GPT4oMini
    static LLM_MODEL_NAME_OBJECT_SYSTEM = LLMUtil.GPT4oMini

    static MAX_TOKENS = 512  // Maximum tokens for LLM

    static String SYSTEM_CONTEXT = PromptFactory.SYSTEM_CONTEXT

	
	static def extractDataFromImage(String imageUrl, String mimetype, String outputEcorePath, String ouputGuidelinesPromptPath, String outputJsonPath) {
		// Read extraction guidelines from the provided file
		def guidelines = new File(ouputGuidelinesPromptPath).text
		// Generate the metamodel in PlantUML format from the Ecore file
		def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		
		def client = new LLMClient()
		// Use the LLMClient to extract typed JSON from the image using the guidelines and metamodel
		def response = client.extractTypedJsonFromImageUrl(guidelines, metamodelPuml, imageUrl, mimetype,
			LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
		
		// Save the extracted JSON response in a pretty printed format
		def jsonFile = new File(outputJsonPath)
		jsonFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(response.body.message))
		
		println "\t✔️ Extracted JSON response saved to ${outputJsonPath}"
		return response
	}
	
	static void ensureFeatureMappings(String outputEcorePath, String outputFeatureMappingJsonPath) {
		if (SpecificationSearchEngine.SKIP_FEATURE_MAPPINGS_GEN)
			return
	
		def mappingFile = new File(outputFeatureMappingJsonPath)
		
		if (!mappingFile.exists()) {
			println "⚠ Feature mappings file not found: ${outputFeatureMappingJsonPath}"
			println "⚙️ Generating a new feature mappings file..."
			// Generate the feature mappings using the existing generateFeatureMappings method
			generateFeatureMappings(outputEcorePath, outputFeatureMappingJsonPath)
		} else {
			println "\t✔️ Feature mappings file found: ${outputFeatureMappingJsonPath}"
			def fileContents = mappingFile.text
			def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
			println("""
------------------
Metamodel (PlantUML): 
${metamodelPuml}

Feature mappings (JSON):
${JsonOutput.prettyPrint(fileContents)}
------------------
""")
		}
		
		// Wait for user confirmation before proceeding
		Utils.waitForUserConfirmation()
		println "\t✔️ Feature mappings confirmed. Proceeding with comparison."
	}
	
	
    static void generateOrRefineMetamodel(String imageUrl, String mimetype, SearchNode node, String expectedJsonPath,
                                          String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath) {
        if (node.parentNode == null) {
            generateMetamodel(imageUrl, mimetype, node.strategyAim, new File(expectedJsonPath).text,
                              outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
        } else {
            def outputDirPath = new File(new File(outputMetamodelJsonPath).parent).parent
            def logFile = new File("output/iterations.json")
            def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
            def parentEntry = pastIterations.find { it.strategyId == node.parentNode.strategyId.toString() }
            def prev_dirPath = node.parentNode.outputDirPath
            if (!new File(prev_dirPath).exists()) {
                prev_dirPath = "${prev_dirPath}_BACKTRACKED"
            }
            // For now, simply copy previous metamodel and guidelines.
            new File(outputMetamodelJsonPath).text = new File("${prev_dirPath}/generated_metamodel.json").text
            new File(outputEcorePath).text = new File("${prev_dirPath}/generated_metamodel.ecore").text
        }
    }

    static void generateMetamodel(String imageUrl, String mimetype,
                                  String strategyAim,
                                  String expectedJson,
                                  String outputMetamodelJsonPath, String outputEcorePath,
                                  String outputGuidelinesPromptPath) {
        println "⚙️ Generating metamodel for: ${imageUrl}"
        def client = new LLMClient()
        def metamodelPrompt = PromptFactory.createMetamodelPrompt(expectedJson)
        def refinedMetamodel_text = client.call_prompt_with_image_url(metamodelPrompt, imageUrl, mimetype, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
        def metamodel_json = client.extractMetamodel(refinedMetamodel_text.body.message, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
        Utils.saveJson(metamodel_json.body.message, outputMetamodelJsonPath)

        EPackage metamodel = EcorePackage.eINSTANCE
        def syncer = new EMFSyncer()
        syncer.enableEagerMode()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
        syncer.loadSourceModel(outputMetamodelJsonPath)
        syncer.forwardSync()
        syncer.saveTargetModel(outputEcorePath)
    }

    static void refineMetamodel(String imageUrl, String mimetype,
                                  String strategyAim,
                                  String prevOutputJsonPath, String expectedJsonPath,
                                  String prevMetamodelJsonPath, String prevGuidelinesPath,
                                  String analysisPath,
                                  String outputMetamodelJsonPath, String outputEcorePath,
                                  String outputGuidelinesPromptPath) {
        println "⚙️ Refining metamodel for: ${imageUrl}"
        String prevMetamodelText = new File(prevMetamodelJsonPath).text
        String prevGuidelinesText = new File(prevGuidelinesPath).text
        String analysisText = new File(analysisPath).text

        def client = new LLMClient()
        def metamodelRefinementPrompt = PromptFactory.createMetamodelRefinementPrompt(prevMetamodelText, prevGuidelinesText, analysisText)
        def refinedMetamodel_json = client.extractMetamodel(metamodelRefinementPrompt, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
        Utils.saveJson(refinedMetamodel_json.body.message, outputMetamodelJsonPath)

        EPackage metamodel = EcorePackage.eINSTANCE
        def syncer = new EMFSyncer()
        syncer.enableEagerMode()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
        syncer.loadSourceModel(outputMetamodelJsonPath)
        syncer.forwardSync()
        syncer.saveTargetModel(outputEcorePath)
    }

    static String generateOrRefineGuidelines(String imageUrl, String mimetype, SearchNode node, String expectedJsonPath, String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath) {
        if (node.parentNode == null) {
            return generateGuidelines(imageUrl, mimetype, node.strategyAim, new File(expectedJsonPath).text, outputEcorePath, outputGuidelinesPromptPath)
        } else {
            def outputDirPath = new File(new File(outputMetamodelJsonPath).parent).parent
            def logFile = new File("output/iterations.json")
            def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
            def parentEntry = pastIterations.find { it.strategyId == node.parentNode.strategyId }
            def prev_dirPath = node.parentNode.outputDirPath
            if (!new File(prev_dirPath).exists()) {
                prev_dirPath = "${prev_dirPath}_BACKTRACKED"
            }
            return refineGuidelines(imageUrl, mimetype, node.strategyAim,
                                     "${prev_dirPath}/extractedData.json", expectedJsonPath,
                                     outputEcorePath, "${prev_dirPath}/guidelines.md", "${prev_dirPath}/analysis.md",
                                     outputGuidelinesPromptPath)
        }
    }

    static String generateGuidelines(String imageUrl, String mimetype,
                                     String strategyAim,
                                     String expectedJson,
                                     String outputEcorePath,
                                     String outputGuidelinesPromptPath) {
        println "⚙️ Generating extraction guidelines for: ${imageUrl}"
        def client = new LLMClient()
        def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
        def guidelinePrompt = PromptFactory.createGuidelinesPrompt(strategyAim, metamodel_puml, expectedJson)
        def extractionGuidelines = client.call_prompt_with_image_url(guidelinePrompt, imageUrl, mimetype, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
        return extractionGuidelines.body.message
    }

    static String refineGuidelines(String imageUrl, String mimetype,
                                     String strategyAim,
                                     String prevOutputJsonPath, String expectedJsonPath,
                                     String outputEcorePath, String prevGuidelinesPath,
                                     String analysisPath,
                                     String outputGuidelinesPromptPath) {
        println "⚙️ Refining extraction guidelines for: ${imageUrl}"
        String metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
        String prevGuidelinesText = new File(prevGuidelinesPath).text
        String expectedJsonText = new File(expectedJsonPath).text
        String analysisText = new File(analysisPath).text

        def client = new LLMClient()
        def guidelineRefinementPrompt = PromptFactory.createGuidelinesRefinementPrompt(metamodel_puml, prevGuidelinesText, analysisText, strategyAim)
        def refinedGuidelines = client.call_prompt_with_image_url(guidelineRefinementPrompt, imageUrl, mimetype, LLM_MODEL_NAME_REFINEMENT.value, Utils.getApiKey(LLM_MODEL_NAME_REFINEMENT), MAX_TOKENS, TEMP_REFINEMENT)
        return refinedGuidelines.body.message
    }

    static String generateOrRefineStrategies(String imageUrl, String mimetype, int branching_factor, SearchNode bestStrategy, String reflectionIfBacktracking) {
        if (bestStrategy) {
            return refineStrategy(imageUrl, mimetype, branching_factor, bestStrategy, reflectionIfBacktracking)
        } else {
            return generateStrategies(imageUrl, mimetype, branching_factor)
        }
    }

    static String generateStrategies(String imageUrl, String mimetype, int branching_factor) {
        def client = new LLMClient()
        def prompt = PromptFactory.createStrategyPrompt(branching_factor)
        def response = client.call_prompt_with_image_url_to_json(prompt, imageUrl, mimetype, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
        return response.body
    }

    static String refineStrategy(String imageUrl, String mimetype, int branching_factor, SearchNode strategy, String reflectionIfBacktracking) {
        def client = new LLMClient()
        def prompt = PromptFactory.createStrategyRefinementPrompt(branching_factor, strategy, reflectionIfBacktracking)
        def response = client.call_prompt_with_image_url_to_json(prompt, imageUrl, mimetype, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
        return response.body
    }

    static void generateFeatureMappings(String outputEcorePath, String outputFeatureMappingJsonPath) {
        println "⚙️ Generating feature mappings for metamodel: ${outputEcorePath}"
        def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
        if (!metamodel_puml || metamodel_puml.trim().isEmpty()) {
            throw new RuntimeException("Failed to convert Ecore metamodel to EMFatic format. Ensure the metamodel is valid.")
        }
        def prompt = PromptFactory.createFeatureMappingsPrompt(metamodel_puml)
        def client = new LLMClient()
        def response = client.call_prompt_to_json(prompt, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
        def featureMappingsJson = response?.body
        if (!featureMappingsJson || featureMappingsJson.trim().isEmpty()) {
            throw new RuntimeException("LLM response is empty or invalid. Check API response for errors.")
        }
        def outputFile = new File(outputFeatureMappingJsonPath)
        outputFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(new JsonSlurper().parseText(featureMappingsJson)))
        println "\t✔️ Feature mappings saved: ${outputFeatureMappingJsonPath}"
    }

    static String analyseExtractedData(String imageUrl, String mimetype,
                                         String outputJsonPath, String gtJsonPath,
                                         String outputEcorePath, String ouputGuidelinesPromptPath,
                                         String outputAnalysisPath,
                                         SearchNode node) {

        def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
        def guidelinesText = new File(ouputGuidelinesPromptPath).text
        def expectedJsonText = new File(gtJsonPath).text
        def extractedJsonText = new File(outputJsonPath).text
        def prompt = PromptFactory.createAnalysisPrompt(metamodelPuml, guidelinesText, expectedJsonText, extractedJsonText, node)
        new File("${node.outputDirPath}/prompt_reflection.md").text = prompt

        def client = new LLMClient()
        def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
        def analysisData = response?.body?.message
        if (!analysisData || analysisData.trim().isEmpty()) {
            throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
        }
        new File(outputAnalysisPath).text = analysisData
        println "\t✔️ Analysis saved: ${outputAnalysisPath}"
        return analysisData
    }
	
	
	
	
	

    static String analyseExtractedDataForBacktracking(String imageUrl, String mimetype,
                                                        String outputJsonPath, String gtJsonPath,
                                                        String outputEcorePath,
                                                        String ouputGuidelinesPromptPath,
                                                        String outputAnalysisPath,
                                                        SearchNode node) {
        def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
        def guidelinesText = new File(ouputGuidelinesPromptPath).text
        def expectedJsonText = new File(gtJsonPath).text
        def extractedJsonText = new File(outputJsonPath).text
        def prompt = PromptFactory.createAnalysisBacktrackingPrompt(metamodelPuml, guidelinesText, expectedJsonText, extractedJsonText, node)
        new File("${node.outputDirPath}/prompt_reflection.md").text = prompt

        def client = new LLMClient()
        def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
        def analysisData = response?.body?.message
        if (!analysisData || analysisData.trim().isEmpty()) {
            throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
        }
        new File(outputAnalysisPath).text = analysisData
        println "\t✔️ Analysis saved: ${outputAnalysisPath}"
        return analysisData
    }
	
	
	
	
	
	
	

    static String reflectionForBacktracking(String imageUrl, String mimetype,
                                             SearchNode parentNode,
                                             List<SearchNode> nodeList) {
        def backtrackedDecisions = nodeList.collect {
            """
#### Attempt ${it.strategyId} with F1 score ${it.metrics.objectF1}
 
##### Strategy Name
${it.strategyName}

##### Strategy Aim
${it.strategyAim}

##### Extraction Guidelines
${it.guidelines}
"""
        }.join("\n\n")
        def prompt = PromptFactory.createReflectionForBacktrackingPrompt(parentNode.strategyName, parentNode.strategyAim, parentNode.guidelines, backtrackedDecisions)
        def client = new LLMClient()
        def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
        def analysisData = response?.body?.message
        if (!analysisData || analysisData.trim().isEmpty()) {
            throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
        }
        return analysisData
    }

    static def convertJsonToEMF(String outputJsonPath, String outputEcorePath, String outputXmiPath) {
        Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
        EPackage metamodel = (EPackage) metamodelRes.getContents().get(0)
        def syncer = new EMFSyncer()
        syncer.enableEagerMode()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
        syncer.loadSourceModel(outputJsonPath)
        syncer.forwardSync()
        syncer.saveTargetModel(outputXmiPath)
        println "\t✔️ Model saved to ${outputXmiPath}"
    }

    static def validateExtractedModelAgainstExpected(String gtJsonPath, String outputEcorePath, String outputXmiPath) {
        println "🔍 Validating extracted model against expected JSON..."
        Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
        EPackage metamodel = metamodelRes.contents[0] as EPackage
        def syncer = new EMFSyncer()
        syncer.enableEagerMode()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
        syncer.loadSourceModel(gtJsonPath)
        syncer.forwardSync()
        syncer.saveTargetModel(outputXmiPath)
        def metrics = syncer.getForwardMetrics()
        return metrics
    }

    static SynchronizationMetricsRecord  compareModels(String outputEcorePath, String outputFeatureMappingJsonPath, String outputXmiPath, String gtXmiPath) {
        def metamodel = YAMTLModule.preloadMetamodel(outputEcorePath)
        def pk = metamodel.contents[0] as EPackage
        def syncer = new EMFSyncer()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF("e", [pk: pk]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("g", [pk: pk]))
        syncer.enableStateExtent()
        def mappingFile = new File(outputFeatureMappingJsonPath)
        if (!mappingFile.exists()) {
            throw new RuntimeException("Feature mapping file not found: ${outputFeatureMappingJsonPath}")
        }
        def mappingsJson
        try {
            mappingsJson = new JsonSlurper().parseText(mappingFile.text)
        } catch (Exception e) {
            throw new RuntimeException("Error parsing feature mapping file: ${e.message}")
        }
        def mappings = []
        mappingsJson.each { entry ->
            if (!(entry instanceof Map) || !entry.containsKey("className") || !entry.containsKey("featureName")) {
                throw new RuntimeException("Invalid feature mapping format. Expected keys: 'className' and 'featureName'")
            }
            mappings << FeatureMappingFactory.create(entry.className, entry.featureName, entry.className, entry.featureName)
        }
        syncer.setSimilarityRelation(true, mappings, ComparisonMode.EXACT)
        def sourceModelRootObjects = []
        try {
            sourceModelRootObjects = syncer.getModelContents(outputXmiPath)
        } catch (Exception e) {
            println("⚠️ Error loading source model: ${e.message}")
            return new SynchronizationMetricsRecord()
        }
        def targetModelRootObjects = syncer.getModelContents(gtXmiPath)
        if (sourceModelRootObjects.isEmpty() || targetModelRootObjects.isEmpty()) {
            throw new RuntimeException("Error: One or both models have no root objects. Ensure the extracted and ground truth models are correctly formatted.")
        }
        syncer.setSourceModel(sourceModelRootObjects)
        syncer.setTargetModel(targetModelRootObjects)
        syncer.match()
        def metrics = syncer.getForwardMetrics()
        return metrics
    }
}