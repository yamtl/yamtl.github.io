package aides_v14

import java.text.SimpleDateFormat

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.EcorePackage
import org.eclipse.emf.ecore.resource.Resource

import apiClient_lambda.LLMClient
import apiClient_lambda.LLMUtil
import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped
import emf_syncer.EMFSyncer.ComparisonMode
import emf_syncer.dsl.FeatureMappingFactory
import emf_syncer.roles.SynchronizationMetricsRecord
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import prettyprinting.EMFPrettyPrinter
import untypedModel.UntypedModelPackage
import yamtl.core.YAMTLModule

class SpecificationInferenceEngine_no_backtracking {
	
	
	static String SYSTEM_CONTEXT = """
Our system extracts structured data from images based on a **metamodel** and predefined **extraction guidelines**. 
The **metamodel** defines entities, attributes, and relationships, 
while the **extraction guidelines** instruct how to extract and format data into a JSON structure. 

After processing, the extracted JSON is compared with an expected JSON reference. 
Evaluation metrics (precision, recall, and F1-score) indicate alignment between 
the extracted and expected data (ground truth). 
"""
	








	static void generateOrRefineMetamodelAndGuidelines(LLMUtil llmModel, int max_tokens, float temp,
	                                                   String imageUrl, String expectedJsonPath,
	                                                   String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath,
	                                                   int iteration) {
	    if (iteration == 1) {
	        generateMetamodelAndGuidelines(llmModel, max_tokens, temp, imageUrl, new File(expectedJsonPath).text,
	                                       outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
	    } else {
			def outputDirPath =  new File(new File(outputMetamodelJsonPath).parent).parent
			def prevOutputJsonText = iteration > 1 ? "${outputDirPath}/iteration_${String.format('%02d', iteration - 1)}/extractedData.json" : null
			def prevMetamodelJsonPath = iteration > 1 ? "${outputDirPath}/iteration_${String.format('%02d', iteration - 1)}/generated_metamodel.json" : null
			def prevGuidelinesPath = iteration > 1 ? "${outputDirPath}/iteration_${String.format('%02d', iteration - 1)}/extraction_guidelines.md" : null
			def analysisPath = iteration > 1 ? "${outputDirPath}/iteration_${String.format('%02d', iteration - 1)}/analysis.md" : null
			
	        refineMetamodelAndGuidelines(llmModel, max_tokens, temp, imageUrl, prevOutputJsonText, expectedJsonPath,
	                                     prevMetamodelJsonPath, prevGuidelinesPath, analysisPath,
	                                     outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
	    }
	}



	
	/**
	 * Generates a textual metamodel and extraction guidelines for a given image using LLM.
	 * Stores the metamodel in structured textual format and generates extraction guidelines.
	 */
	static void generateMetamodelAndGuidelines(LLMUtil llmModel, int max_tokens, float temp, 
                                           String imageUrl, String expectedJson, 
                                           String outputMetamodelJsonPath, String outputEcorePath, 
                                           String outputGuidelinesPromptPath) {
	    println "Generating metamodel and extraction guidelines for: ${imageUrl}"
	
	    // Call LLM to infer a metamodel from the image
	    def client = new LLMClient()
	    
		def metamodelPrompt = """
Given an image that contains structured data and a oracle json document 
with the extracted data from this image, generate a textual description 
of the domain model that helps capture the extracted data. 
The textual description should include:
- **Entities** (class names)
- **Intrinsic properties** (attributes with types)
- **Extrinsic properties** (relationships with multiplicities (lower bound, upper bound) and constraints - composition, uniqueness, ordering, etc.)

Only include relevant concepts without making additional assumptions that are not 
clearly aligned with the provided data.

### Expected output of our system

${expectedJson}
"""
	
	    def refinedMetamodel_text = client.call_prompt(metamodelPrompt.toString(), llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
		println('------------------')
		println("Extracted metamodel: ${refinedMetamodel_text.body.message}")
		
		def metamodel_json = client.extractMetamodel(refinedMetamodel_text.body.message, llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
		println('------------------')
		println("Extracted metamodel Ecore: ${JsonOutput.prettyPrint(JsonOutput.toJson( metamodel_json.body.message ))}")
		Utils.saveJson(metamodel_json.body.message, outputMetamodelJsonPath)
		
		// Save extracted metamodel
		EPackage metamodel = EcorePackage.eINSTANCE;

		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))

		syncer.loadSourceModel(outputMetamodelJsonPath)
		
		// FIX: map current 
		syncer.forwardSync()
		
		syncer.saveTargetModel(outputEcorePath)

		
		
		
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		println('------------------')
		println("Extracted metamodel PlantUML: ${metamodel_puml}")
		
			    
	    // Generate extraction guidelines using LLM
	    def guidelinePrompt = """
Based on the Ecore metamodel below, generate precise extraction guidelines to:
1. Extract data elements from the given image.
2. Structure the extracted data in JSON format, as in the oracle JSON document.
Ensure the guidelines align with the metamodel structure.

### Metamodel

${metamodel_puml}

### Oracle JSON Document

${expectedJson}
"""
	
	    def extractionGuidelines = client.call_prompt(guidelinePrompt.toString(), llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
		println('------------------')	
		println('Extraction guidelines: ' + extractionGuidelines.body.message)

	    // Save extraction guidelines
	    def guidelinesFile = new File(outputGuidelinesPromptPath)
	    guidelinesFile.text = extractionGuidelines.body.message
	    println "Extraction guidelines saved: ${guidelinesFile.path}"
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	static void refineMetamodelAndGuidelines(LLMUtil llmModel, int max_tokens, float temp,
											 String imageUrl, String prevOutputJsonPath, String expectedJsonPath,
											 String prevMetamodelJsonPath, String prevGuidelinesPath,
											 String analysisPath,
											 String outputMetamodelJsonPath, String outputEcorePath,
											 String outputGuidelinesPromptPath) {
		println "🔄 Refining metamodel and extraction guidelines for: ${imageUrl}"
	
		String prevMetamodelText = new File(prevMetamodelJsonPath).text
		String prevGuidelinesText = new File(prevGuidelinesPath).text
		String prevOutputJsonText = new File(prevOutputJsonPath).text
		String expectedJsonText = new File(expectedJsonPath).text
		String analysisText = new File(analysisPath).text
	
		def client = new LLMClient()
	
		// **Step 1: Refinement Prompt for Metamodel**
		def metamodelRefinementPrompt = """
${SYSTEM_CONTEXT}

A previous iteration of the extraction process produced **evaluation results** (precision, recall, F1-score) 
both at object and feature levels, comparing the extracted JSON with the expected JSON (ground truth).
Errors in the extraction process have been analyzed, and **specific refinements** have been suggested.

### **Your Task:**
Refine the **metamodel** below based on the given analysis. Make targeted changes without discarding correct elements.

### **Previous Metamodel (Ecore model in JSON Format)**
```
${prevMetamodelText}
```

### **Previous Extraction Guidelines**
```
${prevGuidelinesText}
```

### Extracted output of our system

${prevOutputJsonText}

### Expected output of our system

${expectedJsonText}

### **Analysis of Extraction Errors**
```
${analysisText}
```

### **Instructions:**
- Improve the metamodel by adding, removing, or modifying entities, attributes, and relationships.
- Preserve correct structures unless the analysis suggests specific changes.
- Do not discard the entire metamodel. Modify only what is necessary.
- Return the refined metamodel in a structured textual format, highlighting:
  - Entities (class names)
  - Intrinsic properties (attributes with types)
  - Extrinsic properties (relationships with multiplicities, constraints - composition, uniqueness, ordering, etc.)
"""
	
//		def refinedMetamodel_text = client.call_prompt(metamodelRefinementPrompt.toString(), llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
//		println('------------------')
//		println("Refined Metamodel: ${refinedMetamodel_text.body.message}")
	
		// Convert refined metamodel to JSON (Ecore format)
		def refinedMetamodel_json = client.extractMetamodel(metamodelRefinementPrompt.toString(), llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
		println('------------------')
		def newMetamodelText = JsonOutput.prettyPrint(JsonOutput.toJson(refinedMetamodel_json.body.message))
		println("Refined Metamodel Ecore: ${newMetamodelText}")
		Utils.saveJson(refinedMetamodel_json.body.message, outputMetamodelJsonPath)
	
		// Save refined metamodel as Ecore model
		EPackage metamodel = EcorePackage.eINSTANCE
	
		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
	
		syncer.loadSourceModel(outputMetamodelJsonPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputEcorePath)
	
		def refinedMetamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		println('------------------')
		println("Refined Metamodel PlantUML: ${refinedMetamodel_puml}")
	
		// **Step 2: Refinement Prompt for Extraction Guidelines**
		def guidelineRefinementPrompt = """
${SYSTEM_CONTEXT}

The metamodel and extraction guidelines must be **refined** based on evaluation metrics and analysis of extraction errors.


### **Previous Metamodel (Ecore model in JSON Format)**
```
${prevMetamodelText}
```

### **New Metamodel (Ecore model in JSON Format)**
```
${newMetamodelText}
```

### **Previous Extraction Guidelines**
```
${prevGuidelinesText}
```

### Extracted output of our system

${prevOutputJsonText}

### Expected output of our system

${expectedJsonText}

### **Analysis of Extraction Errors**
```
${analysisText}
```

### Your task

Write a self-contained update of **extraction guidelines** based on the given analysis and the updated metamodel.
The system using it does not need to know they are a refinement. 
Ensure the guidelines are aligned with the new metamodel and the expected output:

- Modify only what is necessary in the extraction guidelines.
- Ensure alignment with the refined metamodel.
- Improve precision & recall based on analysis.
- Do not discard the entire guideline. Adjust only the parts relevant to the identified issues.

Respond **only** with the updated extraction guidelines.
"""
	
		def refinedGuidelines = client.call_prompt(guidelineRefinementPrompt.toString(), llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
		println('------------------')
		println('Refined Extraction Guidelines: ' + refinedGuidelines.body.message)
	
		// Save refined extraction guidelines
		def guidelinesFile = new File(outputGuidelinesPromptPath)
		guidelinesFile.text = refinedGuidelines.body.message
		println "✅ Refined Extraction Guidelines saved: ${guidelinesFile.path}"
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	static def extractDataFromImage(LLMUtil llmModel, int max_tokens, float temp, String imageUrl, String outputEcorePath, String ouputGuidelinesPromptPath, String outputJsonPath) {

		def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)

		def client = new LLMClient()
		def response = client.extractTypedJsonFromImageUrl(ouputGuidelinesPromptPath, metamodelPuml, imageUrl, llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)

		def jsonFile = new File(outputJsonPath)
		jsonFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(response.body.message))

		println("Extracted JSON response saved to tmp.json")
		return response
	}

	
	
	
	static def convertJsonToEMF(String outputJsonPath, String outputEcorePath, String outputXmiPath) {

		Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
		EPackage metamodel = (EPackage) metamodelRes.getContents().get(0)

		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))

		syncer.loadSourceModel(outputJsonPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputXmiPath)

		println("Model saved to ${outputXmiPath}")
	}
	
	static def validateExtractedModelAgainstExpected(String gtJsonPath, String outputEcorePath, String outputXmiPath) {

		println "🔍 Validating extracted model against expected JSON..."
	
		// Load metamodel
		Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
		EPackage metamodel = metamodelRes.contents[0] as EPackage
	
		// Setup EMFSyncer
		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
	
		// Convert expected JSON into EMF model
		syncer.loadSourceModel(gtJsonPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputXmiPath)
	
		
		def metrics = syncer.getForwardMetrics()
		return metrics
	}
	
	
	
	
	
	
	static void generateFeatureMappings(LLMUtil llmModel, int max_tokens, float temp, String outputEcorePath, String outputFeatureMappingJsonPath) {

		println "🔹 Generating feature mappings for metamodel: ${outputEcorePath}"
	
		// Convert Ecore to EMFatic format
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		if (!metamodel_puml || metamodel_puml.trim().isEmpty()) {
			throw new RuntimeException("Failed to convert Ecore metamodel to EMFatic format. Ensure the metamodel is valid.")
		}
	
		// Construct LLM Prompt
		def prompt = """
Given this Ecore metamodel in EMFatic format:

```
${metamodel_puml}
```

We want to configure EMFSyncer to compare models of this metamodel. **EMFSyncer** synchronizes models by 
**matching objects via a similarity relation** rather than exact equality. 
Objects are aligned using **fingerprints** and **distinguishing attributes** (e.g., `id`, `name`).

**Feature selection guidance for LLM:**
1. **Prioritize distinguishing attributes** (e.g., unique IDs, names) for matching objects.
2. **Exclude mutable attributes** that may vary despite objects being the same.
3. **Use FeatureMapping** to define which attributes are synchronized.
4. **Enable renaming or transformation** where feature names differ between models.

Apply the following heuristics:
* Each class should have at least one feature selected.
* Use attributes that look like identifiers first.
* If no attributes look like identifiers, use references that look like identifiers.
* Use containment references only if strictly necessary (i.e., to check structural consistency when there is no eOpposite reference of the containment reference).

Create a JSON configuration file specifying the selected features using this format:

json
[
  {
    "className": "..",
    "featureName": ".."
  }
]


The **LLM should select features** that uniquely **identify objects** but avoid including **all properties**, ensuring **schema alignment** while preserving flexibility in model comparison.

Produce **JSON only** and nothing else.
"""
	
		// Send the prompt to LLM
		def client = new LLMClient()
		def response = client.call_prompt_to_json(prompt, llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
	
		// Extract response body
		def featureMappingsJson = response?.body
		if (!featureMappingsJson || featureMappingsJson.trim().isEmpty()) {
			throw new RuntimeException("LLM response is empty or invalid. Check API response for errors.")
		}
	
		// Save feature mappings to JSON file
		def outputFile = new File(outputFeatureMappingJsonPath)
		outputFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(new JsonSlurper().parseText(featureMappingsJson)))
	
		println "✅ Feature mappings saved: ${outputFeatureMappingJsonPath}"
	}
	
	
	static void ensureFeatureMappings(LLMUtil llmModel, int max_tokens, float temp, String outputEcorePath, String outputFeatureMappingJsonPath) {

		if (!new File(outputFeatureMappingJsonPath).exists()) {
			println "⚠ Feature mappings file not found: ${outputFeatureMappingJsonPath}"
			println "🔹 Generating a new feature mappings file..."
			
			// Generate the feature mappings
			generateFeatureMappings(llmModel, max_tokens, temp, outputEcorePath, outputFeatureMappingJsonPath)
		} else {
			println "✅ Feature mappings file found: ${outputFeatureMappingJsonPath}"
			println "🔍 Reviewing file contents..."
			
			// Read the existing feature mappings
			
			def fileContents = new File(outputFeatureMappingJsonPath).text
			println "\n--- Feature Mappings JSON ---"
			println JsonOutput.prettyPrint(fileContents)
			println "--- End of File ---\n"
		}
		
		Utils.waitForUserConfirmation()
				
		println "✅ Feature mappings confirmed. Proceeding with comparison."
	}
	
	
	
	
	/**
	 * Configure the EMFSyncer with feature mappings and compare two models.
	 * 
	 * Flexible but relies on manual input.
	 * 
	 * @param metamodelFilePath
	 * @param extractedModelPath
	 * @param gtModelPath
	 * @param featureMappingFile
	 * @return
	 */
	static def compareModels(String outputEcorePath, String outputFeatureMappingJsonPath, String outputXmiPath, String gtXmiPath)  {
		def metamodel = YAMTLModule.preloadMetamodel(outputEcorePath)
		def pk = metamodel.contents[0] as EPackage
	
		def syncer = new EMFSyncer()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF("e", [pk: pk]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("g", [pk: pk]))
		syncer.enableStateExtent()
	
		// Validate and Load Feature Mappings
		def mappingFile = new File(outputFeatureMappingJsonPath)
		if (!mappingFile.exists()) {
			throw new RuntimeException("Feature mapping file not found: ${outputFeatureMappingJsonPath}")
		}
	
		def mappingsJson
		try {
			mappingsJson = new JsonSlurper().parseText(mappingFile.text)
		} catch (Exception e) {
			throw new RuntimeException("Error parsing feature mapping file: ${e.message}")
		}
	
		// Ensure mappings have correct format
		def mappings = []
		mappingsJson.each { entry ->
			if (!(entry instanceof Map) || !entry.containsKey("className") || !entry.containsKey("featureName")) {
				throw new RuntimeException("Invalid feature mapping format in ${featureMappingFile}. Expected keys: 'className' and 'featureName'")
			}
			mappings << FeatureMappingFactory.create(entry.className, entry.featureName, entry.className, entry.featureName)
		}
	
		syncer.setSimilarityRelation(true, mappings, ComparisonMode.EXACT)
	
		// Load Models and Get Root Objects
		def sourceModelRootObjects = syncer.getModelContents(outputXmiPath)
		def targetModelRootObjects = syncer.getModelContents(gtXmiPath)
	
		if (sourceModelRootObjects.isEmpty() || targetModelRootObjects.isEmpty()) {
			throw new RuntimeException("Error: One or both models have no root objects. Ensure the extracted and ground truth models are correctly formatted.")
		}
	
		syncer.setSourceModel(sourceModelRootObjects)
		syncer.setTargetModel(targetModelRootObjects)
	
		// Perform Model Comparison
		syncer.match()
	
		def metrics = syncer.getForwardMetrics()
		return metrics
	}
	
	
	
		
	static String analyseExtractedData(LLMUtil llmModel, int max_tokens, float temp,
		String outputJsonPath, String gtJsonPath,
		String outputEcorePath, String ouputGuidelinesPromptPath,
		String outputAnalysisPath,
		SynchronizationMetricsRecord metrics)
 {
		
		
				
		def prompt = """
${SYSTEM_CONTEXT}

## Available Information

### 1. **Current Metamodel (Ecore format)**
```
${new File(outputEcorePath).text}
```

### 2. **Current Extraction Guidelines**
```
${new File(ouputGuidelinesPromptPath).text}
```

### 3. **Expected JSON Output (Ground Truth)**
```
${new File(gtJsonPath).text}
```

### 4. **Extracted JSON Output**
```
${new File(outputJsonPath).text}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**. 

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **True Positives (TP):** Correctly matched objects.
- **False Positives (FP):** Extra objects introduced that shouldn't exist.
- **False Negatives (FN):** Missing objects that should have been extracted.
- **Precision:** ${metrics.objectPrecision} (Proportion of extracted objects that are correct).
- **Recall:** ${metrics.objectRecall} (Proportion of expected objects that were extracted).
- **F1-score:** ${metrics.objectF1} (Harmonic mean of precision and recall for objects).

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **True Positives (TP):** Correctly extracted attributes.
- **False Positives (FP):** Attributes incorrectly introduced in extracted objects.
- **False Negatives (FN):** Expected attributes that were missing in extraction.
- **Precision:** ${metrics.featurePrecision} (Proportion of extracted attributes that are correct).
- **Recall:** ${metrics.featureRecall} (Proportion of expected attributes that were extracted).
- **F1-score:** ${metrics.featureF1} (Harmonic mean of precision and recall for features).

A low **recall** suggests missing objects or attributes, indicating **incomplete extractions**. 
A low **precision** suggests extra elements were extracted, indicating **overgeneralization**. 
The goal is to refine the extraction guidelines to improve **both precision and recall** while maintaining balanced F1-scores.

## Analysis Task

Your task is to analyze the discrepancies between the **extracted JSON** and the **expected JSON**, 
using the provided **evaluation metrics**, **extraction guidelines**, and **metamodel**. 
The goal is to identify patterns in errors and generate insights that will inform future refinements.  

Consider the following aspects in your analysis:
a) If recall is low, **identify which expected elements were not extracted** and 
whether they are missing due to inadequate extraction rules or structural gaps in the metamodel.
b) If precision is low, **identify which extracted elements should not have been included**, 
and assess whether they are due to overgeneralized extraction rules.
c) If recurring mismatches are observed in specific attributes or relationships, 
**highlight possible metamodel misalignments** that could require structural changes in the metamodel. 
Be concrete as to what concepts, attributes, or relationships need adjustments 
(including their multiplicity constraints - lower and upper bounds, unique, ordered, - composition and bidirectionality).
Highlight whether there are concepts in the metamodel that are irrelevant form the point of view of the extraction process.

Your analysis should build on the previous extraction guidelines, and highlight concise and 
actionable increments to improve the extraction process in the previous three aspects.

Do not include any other section. Do not include a wrap-up sentence.
"""
		
		// Send refinement prompt to LLM
		def client = new LLMClient()
		def response = client.call_prompt(prompt, llmModel.value, Utils.getApiKey(llmModel), max_tokens, temp)
		
		def analysisData = response?.body?.message
		if (!analysisData || analysisData.trim().isEmpty()) {
			throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
		}
		
		// Save analysis to file
		new File(outputAnalysisPath).text = analysisData
		
		println "Analysis ${analysisData}"
		
		return analysisData
	}

	
	static boolean checkAndLogIteration(LLMUtil llmModel, int max_tokens, float temp,
		String outputJsonPath, String gtJsonPath,
		String outputEcorePath, String ouputGuidelinesPromptPath,
		String outputAnalysisPath,
		SynchronizationMetricsRecord metrics, String logFilePath,
		int currentIteration, int MAX_ITERATIONS) {


		def logFile = new File(logFilePath)
		def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
		def f1_score = metrics.objectF1 as float
		
		def iterationEntry = [
			"iteration": currentIteration,
			"timestamp": new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date()),
			"metamodel": outputEcorePath,
			"extraction_guidelines": ouputGuidelinesPromptPath,
			"extracted_output": outputJsonPath,
			"expected_output": gtJsonPath,
			"metrics": metrics
		]
		
		if (f1_score >= 0.99) {
			println "✅ F1-score (${f1_score}) meets the threshold. No refinement needed."
			iterationEntry["analysis"] = "Final iteration - No further refinements needed."
			pastIterations << iterationEntry
			logFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(pastIterations))
			return false
		}
		
		println "⚠ F1-score (${f1_score}) is below 0.99. Refinement required."
		iterationEntry["analysis"] = analyseExtractedData(llmModel, max_tokens, temp,
			outputJsonPath, gtJsonPath,
			outputEcorePath, ouputGuidelinesPromptPath,
			outputAnalysisPath,
			metrics)
		
		pastIterations << iterationEntry
		logFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(pastIterations))
		println "📜 Logged iteration ${currentIteration} in ${logFilePath}"
		
		return currentIteration < MAX_ITERATIONS
	}
	
	
	
	
	
	
	static void runRefinementLoop(LLMUtil llmModel, int max_tokens, float temp,
		String imageUrl, String gtJsonPath, String outputDirPath, int MAX_ITERATIONS, float F1_THRESHOLD) {
		
		def currentIteration = 5
	
		def client = new LLMClient()
		def logFilePath = "${outputDirPath}/iterations.json"
		File outputDir = new File(outputDirPath)
		if (outputDir.exists() && currentIteration==1) outputDir.deleteDir()
				
			
		while (currentIteration <= MAX_ITERATIONS) {
			File iterationDir = new File("${outputDir.path}/iteration_${String.format('%02d', currentIteration)}")
			if (!iterationDir.exists()) iterationDir.mkdirs()
			copyPreviousFeatureMapping(currentIteration, outputDir.path)
			
			String outputMetamodelJsonPath = "${iterationDir.path}/generated_metamodel.json"
			String outputEcorePath = "${iterationDir.path}/generated_metamodel.ecore"
			String outputGuidelinesPromptPath = "${iterationDir.path}/extraction_guidelines.md"
			String outputJsonPath = "${iterationDir.path}/extractedData.json"
			String outputXmiPath = "${iterationDir.path}/extractedData.xmi"
			String outputAnalysisPath = "${iterationDir.path}/analysis.md"
			String outputFeatureMappingJsonPath = "${iterationDir.path}/generated_emfsyncer_mappings.json"
			String gtXmiPath = "${iterationDir.path}/gtModel.xmi"
	
			// Step 1: Generate Metamodel & Guidelines
			generateOrRefineMetamodelAndGuidelines(llmModel, max_tokens, temp, 
			                                       imageUrl, gtJsonPath, 
			                                       outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath, 
			                                       currentIteration)

			// Step 2: Extract Data
			extractDataFromImage(llmModel, max_tokens, temp, imageUrl, outputEcorePath, outputGuidelinesPromptPath, outputJsonPath)
	
			// Step 3: Convert Extracted JSON to EMF Model
			convertJsonToEMF(outputJsonPath, outputEcorePath, outputXmiPath)
	
			// Step 4: Ensure Feature Mappings
			ensureFeatureMappings(llmModel, max_tokens, temp, outputEcorePath, outputFeatureMappingJsonPath)
	
			// Step 5: Convert Ground Truth JSON to EMF Model
			convertJsonToEMF(gtJsonPath, outputEcorePath, gtXmiPath)
	
			// Step 6: Compare Extracted Model with Ground Truth
			def metrics = compareModels(outputEcorePath, outputFeatureMappingJsonPath, outputXmiPath, gtXmiPath)
	
			// Step 7: Log Results & Check Termination
			boolean continueRefinement = checkAndLogIteration(llmModel, max_tokens, temp,
				outputJsonPath, gtJsonPath, outputEcorePath, outputGuidelinesPromptPath,
				outputAnalysisPath, metrics, logFilePath, currentIteration, MAX_ITERATIONS)
	
			if (!continueRefinement || metrics.objectF1 >= F1_THRESHOLD) break
			currentIteration++
		}
	}
	
	
	static void main(String... args) {
						
	    def llmModel = LLMUtil.GPT4oMini // LLM model to use
		def max_tokens = 512  // Maximum tokens for LLM
		def temp = 0.02f  // Temperature for LLM
		
		
		def F1_THRESHOLD = 0.99f  // F1-score threshold to stop refinement
		def MAX_ITERATIONS = 5

		def outputDirPath = "output/"
		
	    String imageUrl = "https://raw.githubusercontent.com/yamtl/llm-files/refs/heads/main/images/patient-3910-l.png"  // Replace with a real image URL
	    String gtJsonPath = "src/main/resources/3910L.json"  // Path to example expected JSON

	
		
		runRefinementLoop(llmModel, max_tokens, temp, imageUrl, gtJsonPath, outputDirPath, MAX_ITERATIONS, F1_THRESHOLD)
		
		
		println "✅ Script execution complete. Exiting..."
		System.exit(0)
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// HELPERS
	
	
	static void copyPreviousFeatureMapping(int currentIteration, String outputDirPath) {
		if (currentIteration > 1) {
			File prevMappingFile = new File("${outputDirPath}/iteration_${String.format('%02d', currentIteration - 1)}/generated_emfsyncer_mappings.json")
			File newMappingFile = new File("${outputDirPath}/iteration_${String.format('%02d', currentIteration)}/generated_emfsyncer_mappings.json")
	
			if (prevMappingFile.exists() && !newMappingFile.exists()) {
				newMappingFile.text = prevMappingFile.text
				println "🔄 Copied feature mappings from previous iteration."
			}
		}
	}

}
