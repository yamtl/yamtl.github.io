package aides_v14

import java.text.SimpleDateFormat

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.EcorePackage
import org.eclipse.emf.ecore.resource.Resource

import apiClient_lambda.LLMClient
import apiClient_lambda.LLMUtil
import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped
import emf_syncer.EMFSyncer.ComparisonMode
import emf_syncer.dsl.FeatureMappingFactory
import emf_syncer.roles.SynchronizationMetricsRecord
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import prettyprinting.EMFPrettyPrinter
import untypedModel.UntypedModelPackage
import yamtl.core.YAMTLModule

class SpecificationInferenceEngine {
	
	
	static String SYSTEM_CONTEXT = """
Our system extracts structured data from images based on a **metamodel** and predefined **extraction guidelines**. 
The **metamodel** defines entities, attributes, and relationships, 
while the **extraction guidelines** instruct how to extract and format data into a JSON structure. 

After processing, the extracted JSON is compared with an expected JSON reference. 
Evaluation metrics (precision, recall, and F1-score) indicate alignment between 
the extracted and expected data (ground truth). 
"""
	

	static boolean SKIP_FEATURE_MAPPINGS_GEN = false

	static float TEMP_REFINEMENT = 0.4f
	static float TEMP_REFLECTION = 0.4f
	static float TEMP_META_SYSTEM = 0.2f
	static float TEMP_OBJECT_SYSTEM = 0.01f

	static LLM_MODEL_NAME_REFINEMENT = LLMUtil.GPT4oMini
	static LLM_MODEL_NAME_REFLECTION = LLMUtil.GPT4oMini
	static LLM_MODEL_NAME_META_SYSTEM = LLMUtil.GPT4oMini
	static LLM_MODEL_NAME_OBJECT_SYSTEM = LLMUtil.GPT4oMini 
	
	static MAX_TOKENS = 512  // Maximum tokens for LLM
	
	
	static F1_THRESHOLD = 0.87f  // F1-score threshold to stop refinement

	static MAX_ITERATIONS = 20
	static MAX_EXAMPLES = 5
	
	
	static OUTPUT_DIRPATH = "output/"
	
	

	
	static void main(String... args) {
								
//		String imageUrl = "https://raw.githubusercontent.com/yamtl/llm-files/refs/heads/main/images/patient-3910-l.png"  // Replace with a real image URL
//		String gtJsonPath = "src/main/resources/3910L.json"  // Path to example expected JSON
		
		
		String mimetype = "image/png"
		
		String featureMappingsFilePath = "src/main/resources/generated_emfsyncer_mappings.json"
		if (featureMappingsFilePath)
			SKIP_FEATURE_MAPPINGS_GEN = true
		
		
		def datasetPath = "src/main/resources/sample_10.json"
		def jsonSlurper = new JsonSlurper()
		def jsonData = new File(datasetPath).text
		def entries = jsonSlurper.parseText(jsonData)
			
		
		def logFilePath = "${OUTPUT_DIRPATH}/iterations.json"
		def counterFile = new File("${OUTPUT_DIRPATH}/global_iteration_counter.txt")
		int iterationCount = counterFile.exists() ? counterFile.text.toInteger() : 1
		
		int exampleCount = 1
		entries.each { entry ->
			if (exampleCount > MAX_EXAMPLES || iterationCount > MAX_ITERATIONS) {
				return // Stop processing if max examples or max iterations are reached
			}
			
			
			def imageUrl = entry.url
			def gtJson = entry.json
			
			
			runRefinementLoop(imageUrl, mimetype, gtJson, OUTPUT_DIRPATH, featureMappingsFilePath, MAX_ITERATIONS, F1_THRESHOLD)
			
			
		}
		
		println "\t✔️ Script execution complete. Exiting..."
		System.exit(0)
		
	}
	
	
	
	
	
	
	
	
	static void runRefinementLoop(String imageUrl, String mimetype, Map gtJson, String outputDirPath, String featureMappingsFilePath, int MAX_ITERATIONS, float F1_THRESHOLD) {
	
		def logFilePath = "${outputDirPath}/iterations.json"
		def counterFile = new File("${outputDirPath}/global_iteration_counter.txt")
	
		// Read or initialize the global iteration counter
		int globalIteration = counterFile.exists() ? counterFile.text.toInteger() : 1
	
		File outputDir = new File(outputDirPath)
		if (outputDir.exists() && globalIteration == 1) outputDir.deleteDir()
	
		while (globalIteration < MAX_ITERATIONS) {
			println("""
-----------------------------------------------
➕ Iteration ${globalIteration} / ${MAX_ITERATIONS}
-----------------------------------------------""")
			
			// Define iteration folder using the global iteration counter
			File iterationDir = new File("${outputDir.path}/iteration_${String.format('%02d', globalIteration)}")
			if (!iterationDir.exists()) iterationDir.mkdirs()
	
			copyFeatureMappingsAndReflection(globalIteration, outputDir.path)
	
			String outputMetamodelJsonPath = "${iterationDir.path}/generated_metamodel.json"
			String outputEcorePath = "${iterationDir.path}/generated_metamodel.ecore"
			String outputGuidelinesPromptPath = "${iterationDir.path}/extraction_guidelines.md"
			String outputJsonPath = "${iterationDir.path}/extractedData.json"
			String outputXmiPath = "${iterationDir.path}/extractedData.xmi"
			String outputAnalysisPath = "${iterationDir.path}/analysis.md"
			String outputFeatureMappingJsonPath = "${iterationDir.path}/generated_emfsyncer_mappings.json"
			if (featureMappingsFilePath) {
				outputFeatureMappingJsonPath = featureMappingsFilePath
			}
			
			String expectedJsonPath = "${iterationDir.path}/gtModel.json"
			Utils.saveJson(gtJson, expectedJsonPath)
			String gtXmiPath = "${iterationDir.path}/gtModel.xmi"
			
			// Step 1: Generate Metamodel & Guidelines
			generateOrRefineMetamodelAndGuidelines(
												   imageUrl, mimetype, expectedJsonPath,
												   outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath,
												   globalIteration)
	
			// Step 2: Extract Data
			extractDataFromImage( imageUrl, mimetype, outputEcorePath, outputGuidelinesPromptPath, outputJsonPath)
	
			// Step 3: Convert Extracted JSON to EMF Model
			convertJsonToEMF(outputJsonPath, outputEcorePath, outputXmiPath)
	
			// Step 4: Ensure Feature Mappings
			ensureFeatureMappings( outputEcorePath, outputFeatureMappingJsonPath)
	
			// Step 5: Convert Ground Truth JSON to EMF Model
			convertJsonToEMF(expectedJsonPath, outputEcorePath, gtXmiPath)
	
			// Step 6: Compare Extracted Model with Ground Truth
			def metrics = compareModels(outputEcorePath, outputFeatureMappingJsonPath, outputXmiPath, gtXmiPath)
	
			// Step 7: Log Results & Check Termination
			boolean continueRefinement = checkAndLogIteration(
				imageUrl, mimetype,
				outputJsonPath, expectedJsonPath, outputEcorePath, outputGuidelinesPromptPath,
				outputAnalysisPath, metrics, logFilePath, globalIteration, MAX_ITERATIONS, F1_THRESHOLD)
	
			// Increment and persist the global iteration counter
			counterFile.text = (++globalIteration).toString()

			if (!continueRefinement || metrics.objectF1 >= F1_THRESHOLD) {
				break;
			}
	
		}
	}
	
	
	
	

	static void generateOrRefineMetamodelAndGuidelines(String imageUrl, String mimetype, String expectedJsonPath,
	                                                   String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath,
	                                                   int iteration) {
	    if (iteration == 1) {
	        generateMetamodelAndGuidelines( imageUrl, mimetype, new File(expectedJsonPath).text,
	                                       outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
	    } else {
			def outputDirPath =  new File(new File(outputMetamodelJsonPath).parent).parent
			
			
			
			// get the best iteration until now
			def logFile = new File("output/iterations.json")
			def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
			def bestIterationEntry = pastIterations.max { it.metrics.objectF1 }
			def prevIteration = bestIterationEntry.iteration
			
			// get the previous guidelines from its corresponding folder
			def prev_dirPath = "${outputDirPath}/iteration_${String.format('%02d', prevIteration)}"
			
			if (!new File(prev_dirPath).exists()) {
				prev_dirPath = "${outputDirPath}/iteration_${String.format('%02d', prevIteration)}_BACKTRACKED"
			}
			
			def prevOutputJsonText = iteration > 1 ? "${prev_dirPath}/extractedData.json" : null
			def prevMetamodelJsonPath = iteration > 1 ? "${prev_dirPath}/generated_metamodel.json" : null
			def prevGuidelinesPath = iteration > 1 ? "${prev_dirPath}/extraction_guidelines.md" : null
			def analysisPath = iteration > 1 ? "${prev_dirPath}/analysis.md" : null
			
	        refineMetamodelAndGuidelines( imageUrl, mimetype, prevOutputJsonText, expectedJsonPath,
	                                     prevMetamodelJsonPath, prevGuidelinesPath, analysisPath,
	                                     outputMetamodelJsonPath, outputEcorePath, outputGuidelinesPromptPath)
	    }
	}



	
	/**
	 * Generates a textual metamodel and extraction guidelines for a given image using LLM.
	 * Stores the metamodel in structured textual format and generates extraction guidelines.
	 */
	static void generateMetamodelAndGuidelines(
                                           String imageUrl, String mimetype,
										   String expectedJson, 
                                           String outputMetamodelJsonPath, String outputEcorePath, 
                                           String outputGuidelinesPromptPath) {
        println "⚙️ Generating metamodel and extraction guidelines for: ${imageUrl}"	
	    // Call LLM to infer a metamodel from the image
	    def client = new LLMClient()
	    
		def metamodelPrompt = """
${SYSTEM_CONTEXT}

Given the attached image that contains unstructured data and a oracle json document 
with the extracted data from this image, generate a textual description 
of the domain model that helps capture the extracted data. 
The textual description should include:
- **Entities** (class names)
- **Intrinsic properties** (attributes with types)
- **Extrinsic properties** (relationships with multiplicities (lower bound, upper bound) and constraints - composition, uniqueness, ordering, etc.)

Only include relevant concepts without making additional assumptions that are not 
clearly aligned with the provided data.

### Expected output of our system

${expectedJson}
"""
	
	    def refinedMetamodel_text = client.call_prompt_with_image_url(metamodelPrompt.toString(), imageUrl, mimetype, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
//		println('------------------')
//		println("Extracted metamodel: ${refinedMetamodel_text.body.message}")
		
		def metamodel_json = client.extractMetamodel(refinedMetamodel_text.body.message, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
//		println('------------------')
//		println("Extracted metamodel Ecore: ${JsonOutput.prettyPrint(JsonOutput.toJson( metamodel_json.body.message ))}")
		Utils.saveJson(metamodel_json.body.message, outputMetamodelJsonPath)
		
		// Save extracted metamodel
		EPackage metamodel = EcorePackage.eINSTANCE;

		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))

		syncer.loadSourceModel(outputMetamodelJsonPath)
		
		// FIX: map current 
		syncer.forwardSync()
		
		syncer.saveTargetModel(outputEcorePath)

		
		
		
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		
			    
	    // Generate extraction guidelines using LLM
	    def guidelinePrompt = """
${SYSTEM_CONTEXT}

Based on the Ecore metamodel below, generate precise extraction guidelines for another LLM to process similar images and accurately extract relevant data:
1. Extract data elements from images similar to the one attached, avoiding overfitting. 
2. Identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.
3. Structure the extracted data in JSON format according to the schema defined by the metamodel below.

### Metamodel

${metamodel_puml}

### Oracle JSON Document

${expectedJson}

### Your Task

Write a self-contained guidelines to extract all relevant data (according to the metamodel) from the given image according to the following principles:
- Ensure alignment with the refined metamodel.
- Be as concise and targeted as possible.
- Write the guidelines using markdown but do not use headers or subheaders (with `#`, `##` etc).
- Your guidelines will be instructions for another LLM to process similar images and accurately extract relevant data.
- The guidelines should be applicable to other examples, it is important to avoid overfitting.
"""
	
	    def extractionGuidelines = client.call_prompt_with_image_url(guidelinePrompt.toString(), imageUrl, mimetype, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
//		println('------------------')	
//		println('Extraction guidelines: ' + extractionGuidelines.body.message)

	    // Save extraction guidelines
	    def guidelinesFile = new File(outputGuidelinesPromptPath)
	    guidelinesFile.text = extractionGuidelines.body.message
	    println "\t✔️ Extraction guidelines saved: ${guidelinesFile.path}"
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	static void refineMetamodelAndGuidelines(
											 String imageUrl, String mimetype,
											 String prevOutputJsonPath, String expectedJsonPath,
											 String prevMetamodelJsonPath, String prevGuidelinesPath,
											 String analysisPath,
											 String outputMetamodelJsonPath, String outputEcorePath,
											 String outputGuidelinesPromptPath) {
		println "⚙️ Refining metamodel and extraction guidelines for: ${imageUrl}"

		
		String dirPath = new File(outputMetamodelJsonPath).parent
		
		String prevMetamodelText = new File(prevMetamodelJsonPath).text
		String prevGuidelinesText = new File(prevGuidelinesPath).text
		String prevOutputJsonText = new File(prevOutputJsonPath).text
		String expectedJsonText = new File(expectedJsonPath).text
		String analysisText = new File(analysisPath).text

	
		def client = new LLMClient()
	
		
		
		
		
//		### Extracted output of our system
//		
//		${prevOutputJsonText}
//		
//		### Expected output of our system
//		
//		${expectedJsonText}
//		
		
		// **Step 1: Refinement Prompt for Metamodel**
		def metamodelRefinementPrompt = """
${SYSTEM_CONTEXT}

A previous iteration of the extraction process produced **evaluation results** (precision, recall, F1-score) 
both at object and feature levels, comparing the extracted JSON with the expected JSON (ground truth).
Errors in the extraction process have been analyzed, and **specific refinements** have been suggested.

### **Your Task:**
Refine the **metamodel** below based on the given analysis. Make targeted changes without discarding correct elements.

### **Previous Metamodel (Ecore model in JSON Format)**
```
${prevMetamodelText}
```

### **Previous Extraction Guidelines**
```
${prevGuidelinesText}
```

### **Analysis of Extraction Errors**
```
${analysisText}
```

### **Instructions:**
- Improve the metamodel by adding, removing, or modifying entities, attributes, and relationships.
- Preserve correct structures unless the analysis suggests specific changes.
- Do not discard the entire metamodel. Modify only what is necessary.
- Return the refined metamodel in a structured textual format, highlighting:
  - Entities (class names)
  - Intrinsic properties (attributes with types)
  - Extrinsic properties (relationships with multiplicities, constraints - composition, uniqueness, ordering, etc.)
"""
	
//		def refinedMetamodel_text = client.call_prompt(metamodelRefinementPrompt.toString(), llmModel.value, Utils.getApiKey(llmModel), MAX_TOKENS, temp)
//		println('------------------')
//		println("Refined Metamodel: ${refinedMetamodel_text.body.message}")
	
		// Convert refined metamodel to JSON (Ecore format)
		def refinedMetamodel_json = client.extractMetamodel(metamodelRefinementPrompt.toString(), LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)
		def newMetamodelText = JsonOutput.prettyPrint(JsonOutput.toJson(refinedMetamodel_json.body.message))
		Utils.saveJson(refinedMetamodel_json.body.message, outputMetamodelJsonPath)
	
		// Save refined metamodel as Ecore model
		EPackage metamodel = EcorePackage.eINSTANCE
	
		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
	
		syncer.loadSourceModel(outputMetamodelJsonPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputEcorePath)
	
		def refinedMetamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
//		println('------------------')
//		println("Refined Metamodel PlantUML: ${refinedMetamodel_puml}")
	
		// **Step 2: Refinement Prompt for Extraction Guidelines**
		def guidelineRefinementPrompt = """
${SYSTEM_CONTEXT}

The metamodel and extraction guidelines must be **refined** based on evaluation metrics and analysis of extraction errors.


### **Previous Metamodel (Ecore model in JSON Format)**
```
${prevMetamodelText}
```

### **New Metamodel (Ecore model in JSON Format)**
```
${newMetamodelText}
```

### **Previous Extraction Guidelines**
```
${prevGuidelinesText}
```

### **Recommended updates**
```
${analysisText}
```

### Your task

Remember the aim of the data extraction guidelines for another LLM to process similar images and accurately extract relevant data:
1. Extract data elements from images similar to the one attached, avoiding overfitting. 
2. Identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.
3. Structure the extracted data in JSON format according to the schema defined by the metamodel below.

Write a self-contained update of the **previous extraction guidelines** (without saying it is a refinement) to address the recommended updates above according to the following principles:
- Ensure alignment with the refined metamodel.
- Be as concise and targeted as possible.
- Write the guidelines using markdown but do not use headers or subheaders (with `#`, `##` etc).
- Your guidelines will be instructions for another LLM to process similar images and accurately extract relevant data.
"""
		

		
	
		def refinedGuidelines = client.call_prompt_with_image_url(guidelineRefinementPrompt.toString(), imageUrl, mimetype, LLM_MODEL_NAME_REFINEMENT.value, Utils.getApiKey(LLM_MODEL_NAME_REFINEMENT), MAX_TOKENS, TEMP_REFINEMENT)
//		println('------------------')
//		println('Refined Extraction Guidelines: ' + refinedGuidelines.body.message)
	
		// Save refined extraction guidelines
		def guidelinesFile = new File(outputGuidelinesPromptPath)
		guidelinesFile.text = refinedGuidelines.body.message
		println "\t✔️ Refined Extraction Guidelines saved: ${guidelinesFile.path}"
		
		
		new File("${dirPath}/prompt_extraction_refinement.md").text = guidelineRefinementPrompt.toString()

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	static def extractDataFromImage(String imageUrl, String mimetype, String outputEcorePath, String ouputGuidelinesPromptPath, String outputJsonPath) {
		
		def guidelines = new File(ouputGuidelinesPromptPath).text
//		println("""⚙️ Applying extraction guidelines (${ouputGuidelinesPromptPath}) to image...
//
//${guidelines}
//""")
		
		def metamodelPuml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)

		def client = new LLMClient()
		def response = client.extractTypedJsonFromImageUrl(guidelines, metamodelPuml, imageUrl, mimetype, LLM_MODEL_NAME_OBJECT_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_OBJECT_SYSTEM), MAX_TOKENS, TEMP_OBJECT_SYSTEM)

		def jsonFile = new File(outputJsonPath)
		jsonFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(response.body.message))

		println("\t✔️ Extracted JSON response saved to tmp.json")
		return response
	}

	
	def static checkForTypeField(value) {
		if (value instanceof Map) {
			// If it's a Map, check if it has the 'type' field
			if (!value.containsKey('type')) {
				println "Missing 'type' field in map: $value"
				return false
			}
			// Recursively check the values inside the map
			value.each { key, val ->
				if (!checkForTypeField(val)) {
					return false
				}
			}
		} else if (value instanceof List) {
			// If it's a List, check all the items in the list
			value.each { item ->
				if (!checkForTypeField(item)) {
					return false
				}
			}
		}
		return true
	}
	
	
	static def convertJsonToEMF(String outputJsonPath, String outputEcorePath, String outputXmiPath) {
		
		
//		def jsonSlurper = new JsonSlurper()
//		def jsonListOrMap = jsonSlurper.parseText(new File(outputJsonPath).text)
//		def isValid = checkForTypeField(jsonListOrMap)
//		
//		if (isValid) {
		
			Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
			EPackage metamodel = (EPackage) metamodelRes.getContents().get(0)
	
			def syncer = new EMFSyncer()
			syncer.enableEagerMode()
			syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
			syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
			
			syncer.loadSourceModel(outputJsonPath)
			syncer.forwardSync()
			syncer.saveTargetModel(outputXmiPath)

			println("\t✔️ Model saved to ${outputXmiPath}")
//		}
	}
	
	static def validateExtractedModelAgainstExpected(String gtJsonPath, String outputEcorePath, String outputXmiPath) {

		println "🔍 Validating extracted model against expected JSON..."
	
		// Load metamodel
		Resource metamodelRes = YAMTLModule.preloadMetamodel(outputEcorePath)
		EPackage metamodel = metamodelRes.contents[0] as EPackage
	
		// Setup EMFSyncer
		def syncer = new EMFSyncer()
		syncer.enableEagerMode()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF_untyped("json", [pk: UntypedModelPackage.eINSTANCE]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("vfm", [pk: metamodel]))
	
		// Convert expected JSON into EMF model
		syncer.loadSourceModel(gtJsonPath)
		syncer.forwardSync()
		syncer.saveTargetModel(outputXmiPath)
	
		
		def metrics = syncer.getForwardMetrics()
		return metrics
	}
	
	
	
	
	
	
	static void generateFeatureMappings(String outputEcorePath, String outputFeatureMappingJsonPath) {

		println "⚙️ Generating feature mappings for metamodel: ${outputEcorePath}"
	
		// Convert Ecore to EMFatic format
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)
		if (!metamodel_puml || metamodel_puml.trim().isEmpty()) {
			throw new RuntimeException("Failed to convert Ecore metamodel to EMFatic format. Ensure the metamodel is valid.")
		}
	
		// Construct LLM Prompt
		def prompt = """
Given this Ecore metamodel in EMFatic format:

```
${metamodel_puml}
```

We want to configure EMFSyncer to compare models of this metamodel. **EMFSyncer** synchronizes models by 
**matching objects via a similarity relation** rather than exact equality. 
Objects are aligned using **fingerprints** and **distinguishing attributes** (e.g., `id`, `name`).

**Feature selection guidance for LLM:**
1. **Prioritize distinguishing attributes** (e.g., unique IDs, names) for matching objects.
2. **Exclude mutable attributes** that may vary despite objects being the same.
3. **Use FeatureMapping** to define which attributes are synchronized.
4. **Enable renaming or transformation** where feature names differ between models.

Apply the following heuristics:
* Each class should have at least one feature selected.
* Use attributes that look like identifiers first.
* If no attributes look like identifiers, use references that look like identifiers.
* Use containment references only if strictly necessary (i.e., to check structural consistency when there is no eOpposite reference of the containment reference).

Create a JSON configuration file specifying the selected features using this format:

json
[
  {
    "className": "..",
    "featureName": ".."
  }
]


The **LLM should select features** that uniquely **identify objects** but avoid including **all properties**, ensuring **schema alignment** while preserving flexibility in model comparison.

Produce **JSON only** and nothing else.
"""
	
		// Send the prompt to LLM
		def client = new LLMClient()
		def response = client.call_prompt_to_json(prompt, LLM_MODEL_NAME_META_SYSTEM.value, Utils.getApiKey(LLM_MODEL_NAME_META_SYSTEM), MAX_TOKENS, TEMP_META_SYSTEM)
	
		// Extract response body
		def featureMappingsJson = response?.body
		if (!featureMappingsJson || featureMappingsJson.trim().isEmpty()) {
			throw new RuntimeException("LLM response is empty or invalid. Check API response for errors.")
		}
	
		// Save feature mappings to JSON file
		def outputFile = new File(outputFeatureMappingJsonPath)
		outputFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(new JsonSlurper().parseText(featureMappingsJson)))
	
		println "\t✔️ Feature mappings saved: ${outputFeatureMappingJsonPath}"
	}
	
	
	static void ensureFeatureMappings(String outputEcorePath, String outputFeatureMappingJsonPath) {

		if (SKIP_FEATURE_MAPPINGS_GEN)
			return 
		
		if (!new File(outputFeatureMappingJsonPath).exists()) {
			println "⚠ Feature mappings file not found: ${outputFeatureMappingJsonPath}"
			println "⚙️ Generating a new feature mappings file..."
			
			// Generate the feature mappings
			generateFeatureMappings( outputEcorePath, outputFeatureMappingJsonPath)
		} else {
			println "\t✔️ Feature mappings file found: ${outputFeatureMappingJsonPath}"
			
			// Read the existing feature mappings
			def fileContents = new File(outputFeatureMappingJsonPath).text
			
			
			def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)

			println("""
------------------
Metamodel (PlantUML): 
${metamodel_puml}

Feature mappigns (JSON):
${JsonOutput.prettyPrint(fileContents)}
------------------
""")
	
		}
		
		Utils.waitForUserConfirmation()
				
		println "\t✔️ Feature mappings confirmed. Proceeding with comparison."
	}
	
	
	
	
	/**
	 * Configure the EMFSyncer with feature mappings and compare two models.
	 * 
	 * Flexible but relies on manual input.
	 * 
	 * @param metamodelFilePath
	 * @param extractedModelPath
	 * @param gtModelPath
	 * @param featureMappingFile
	 * @return
	 */
	static def compareModels(String outputEcorePath, String outputFeatureMappingJsonPath, String outputXmiPath, String gtXmiPath)  {
		def metamodel = YAMTLModule.preloadMetamodel(outputEcorePath)
		def pk = metamodel.contents[0] as EPackage
	
		def syncer = new EMFSyncer()
		syncer.setSourceModelHandler(new EMFSyncerParameter_EMF("e", [pk: pk]))
		syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("g", [pk: pk]))
		syncer.enableStateExtent()
	
		// Validate and Load Feature Mappings
		def mappingFile = new File(outputFeatureMappingJsonPath)
		if (!mappingFile.exists()) {
			throw new RuntimeException("Feature mapping file not found: ${outputFeatureMappingJsonPath}")
		}
	
		def mappingsJson
		try {
			mappingsJson = new JsonSlurper().parseText(mappingFile.text)
		} catch (Exception e) {
			throw new RuntimeException("Error parsing feature mapping file: ${e.message}")
		}
	
		// Ensure mappings have correct format
		def mappings = []
		mappingsJson.each { entry ->
			if (!(entry instanceof Map) || !entry.containsKey("className") || !entry.containsKey("featureName")) {
				throw new RuntimeException("Invalid feature mapping format in ${featureMappingFile}. Expected keys: 'className' and 'featureName'")
			}
			mappings << FeatureMappingFactory.create(entry.className, entry.featureName, entry.className, entry.featureName)
		}
	
		syncer.setSimilarityRelation(true, mappings, ComparisonMode.EXACT)
	
		// Load Models and Get Root Objects
		def sourceModelRootObjects = []
		try {
			sourceModelRootObjects = syncer.getModelContents(outputXmiPath)
		} catch (Exception e) {
			println("⚠️ Error loading source model: ${e.message}")
			return new SynchronizationMetricsRecord()
		}
		def targetModelRootObjects = syncer.getModelContents(gtXmiPath)
	
		if (sourceModelRootObjects.isEmpty() || targetModelRootObjects.isEmpty()) {
			throw new RuntimeException("Error: One or both models have no root objects. Ensure the extracted and ground truth models are correctly formatted.")
		}
	
		syncer.setSourceModel(sourceModelRootObjects)
		syncer.setTargetModel(targetModelRootObjects)
	
		// Perform Model Comparison
		syncer.match()
	
		def metrics = syncer.getForwardMetrics()
		return metrics
	}
	
	
	

	
	
	static String analyseExtractedData(
		String imageUrl, String mimetype,
		String outputJsonPath, String gtJsonPath,
		String outputEcorePath, String ouputGuidelinesPromptPath,
		String outputAnalysisPath,
		Map iterationEntry) {
	
		def dirPath =  new File(ouputGuidelinesPromptPath).parent
		
		
		// Retrieve past analyses from log file
		def logFile = new File("output/iterations.json")
		def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
		
		
		def goodDecisions = pastIterations.findAll { !it.containsKey('backtracked_to_iteration') }.collect {
			"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}

##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
		}.join("\n\n")
		
		def backtrackedDecisions = pastIterations.findAll { it.containsKey('backtracked_to_iteration') }.collect {
			"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}
 
##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
		}.join("\n\n")
		
		def pastAnalyses = """
### Good iterations
${goodDecisions}

### Backtracked iterations
${backtrackedDecisions}
"""
		
	
		def prompt = """
${SYSTEM_CONTEXT}

## Available Information

### 1. **Current Metamodel (PlantUML format)**
```
${EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)}
```

### 2. **Current Extraction Guidelines**
```
${new File(ouputGuidelinesPromptPath).text}
```

### 3. **Expected JSON Output (Ground Truth)**
```
${new File(gtJsonPath).text}
```

### 4. **Extracted JSON Output**
```
${new File(outputJsonPath).text}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**.

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **Precision:** ${iterationEntry.metrics.objectPrecision} resulting in an improvement of ${iterationEntry.precision_increment} from the previous iteration.
- **Recall:** ${iterationEntry.metrics.objectRecall}  resulting in an improvement of ${iterationEntry.recall_increment} from the previous iteration.
- **F1-score:** ${iterationEntry.metrics.objectF1} resulting in an improvement of ${iterationEntry.f1_score_increment} from the previous iteration.

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **Precision:** ${iterationEntry.metrics.featurePrecision}
- **Recall:** ${iterationEntry.metrics.featureRecall}
- **F1-score:** ${iterationEntry.metrics.featureF1}

## **Historical Analysis of Errors**
Review these previous analyses and highlight long-standing sources of errors that have not been solved yet when evaluating the current extraction results:
```
${pastAnalyses}
```

## Analysis Task

Your task is to analyze discrepancies between the **extracted JSON** and the **expected JSON** with respect to the attached image, 
using the provided **evaluation metrics** and **historical analysis of errors**. Consider the following priorities (by order of importance):
1. Identify persistent errors that have appeared in **multiple iterations**, focus on addressing them either in the metamodel or in the extraction guidelines.
2. Give priority to those issues affecting to a larger part of the model.
3. Ensure that previous issues do not reappear after refinements. In particular, try to avoid those action that led to a worse result in the past.
4. If the improvement is small, make sure the recommendation emphatically asks for a more innovative approach.

For recommendations, give insights into how to extract data from the image more accurately, by identifying graphical elements such as lines, labels, shapes, 
or color boundaries that serve as delimiters for structured data and describing how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

## Your response

Respond with a simple bullet list list with the top 3 actionable recommendations to improve the extraction process, 
clearly indicating whether they have to be applied to the metamodel or the guidelines, and avoiding repeating previous suggestions.

Be as concise and directive as possible. The reflections will be used by a LLM to improve the extraction process using prompt engineering only.
"""
	
		new File("${dirPath}/prompt_reflection.md").text = prompt


		// Send refinement prompt to LLM
		def client = new LLMClient()
		def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
	
		def analysisData = response?.body?.message
		if (!analysisData || analysisData.trim().isEmpty()) {
			throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
		}
	
		// Save analysis to file
		new File(outputAnalysisPath).text = analysisData
		println "\t✔️ Analysis saved: ${outputAnalysisPath}"
	
		return analysisData
	}
	
	
	
	
	
	
	static String analyseExtractedDataForBacktracking(
		String imageUrl, String mimetype,
		String outputJsonPath, String gtJsonPath,
		String outputEcorePath, String ouputGuidelinesPromptPath,
		String outputAnalysisPath,
		Map iterationEntry) {
	
		
		def dirPath =  new File(ouputGuidelinesPromptPath).parent
	
		// Retrieve past analyses from log file
		def logFile = new File("output/iterations.json")
		def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []

		
		
		def goodDecisions = pastIterations.findAll { !it.containsKey('backtracked_to_iteration') }.collect {
			"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}

##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
		}.join("\n\n")
		
		def backtrackedDecisions = pastIterations.findAll { it.containsKey('backtracked_to_iteration') }.collect {
			"""
#### Iteration ${it.iteration} with F1 score ${it.metrics.objectF1}
 
##### Extraction Guidelines

${it.extraction_guidelines}
    
##### Reflection (Recommended Actions)

${it.previous_analysis}
"""
		}.join("\n\n")
		
		def pastAnalyses = """
### Good iterations
${goodDecisions}

### Backtracked iterations
${backtrackedDecisions}
"""
		
		
		
		
	
		def prompt = """
${SYSTEM_CONTEXT}

## Available Information

### 1. **Current Metamodel (PlantUML format)**
```
${EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(outputEcorePath)}
```

### 2. **Current Extraction Guidelines**
```
${new File(ouputGuidelinesPromptPath).text}
```

### 3. **Expected JSON Output (Ground Truth)**
```
${new File(gtJsonPath).text}
```

### 4. **Extracted JSON Output**
```
${new File(outputJsonPath).text}
```

### 5. **Evaluation Metrics**

The following metrics assess how well the extracted model aligns with the expected model at both **object** and **feature levels**.

#### 5.1. **Object-Level Metrics** (Entity Matching)
- **Precision:** ${iterationEntry.metrics.objectPrecision} resulting in a deterioration of ${iterationEntry.precision_increment} from the previous iteration.
- **Recall:** ${iterationEntry.metrics.objectRecall}  resulting in a deterioration of ${iterationEntry.recall_increment} from the previous iteration.
- **F1-score:** ${iterationEntry.metrics.objectF1} resulting in a deterioration of ${iterationEntry.f1_score_increment} from the previous iteration.

#### 5.2. **Feature-Level Metrics** (Attribute Matching)
- **Precision:** ${iterationEntry.metrics.featurePrecision}
- **Recall:** ${iterationEntry.metrics.featureRecall}
- **F1-score:** ${iterationEntry.metrics.featureF1}

## **Historical Analysis of Errors**
Review these previous analyses and highlight long-standing sources of errors that have not been solved yet when evaluating the current extraction results:

```
${pastAnalyses}
```

## Analysis Task

The current iteration has shown a decrease in the F1-score compared to the best iteration as shown above. If the deterioration is substantial, sugest a drastic change in the extraction guidelines or metamodel from what was proposed for this iteration.

Your task is to identify the top 3 reasons for this decrease and suggest targeted refinements to address them.

Aim to fix those issues that affect a larger part of the model and have appeared in multiple iterations and not yet solved.

In particular, identify graphical elements such as lines, labels, shapes, or color boundaries that serve as delimiters for structured data and describe how these elements define the layout and positioning of data, 
specifying concrete spatial relationships such as relative position to axis labels (i.e., before or after, above or below), containment within table cells, or alignment with chart markers.

Respond with a brief list bullet points, clearly indicating whether they have to be applied to the metamodel or the guidelines.

Remember that the recommendations are for an LLM to improve the extraction process using prompt engineering only.
"""
	

		new File("${dirPath}/prompt_reflection.md").text = prompt

	
		// Send refinement prompt to LLM
		def client = new LLMClient()
		def response = client.call_prompt_with_image_url(prompt, imageUrl, mimetype, LLM_MODEL_NAME_REFLECTION.value, Utils.getApiKey(LLM_MODEL_NAME_REFLECTION), MAX_TOKENS, TEMP_REFLECTION)
	
		def analysisData = response?.body?.message
		if (!analysisData || analysisData.trim().isEmpty()) {
			throw new RuntimeException("LLM refinement response is empty. Aborting refinement.")
		}
	
		// Save analysis to file
		new File(outputAnalysisPath).text = analysisData
		println "\t✔️ Analysis saved: ${outputAnalysisPath}"
	
		return analysisData
	}
	
	
	
	
	static boolean checkAndLogIteration(
		String imageUrl, String mimetype,
		String outputJsonPath, String gtJsonPath,
		String outputEcorePath, String ouputGuidelinesPromptPath,
		String outputAnalysisPath,
		SynchronizationMetricsRecord metrics, String logFilePath,
		int currentIteration, int MAX_ITERATIONS, float F1_THRESHOLD) {
	
		
		def dirPath =  new File(ouputGuidelinesPromptPath).parent
		def prevAnalysisFile = new File("${dirPath}/previous_analysis.md")
		
		def logFile = new File(logFilePath)
		def pastIterations = logFile.exists() ? new JsonSlurper().parseText(logFile.text) : []
		def f1_score = metrics.objectF1 as float
	
		
		def iterationEntry = [
			"iteration": currentIteration,
			"timestamp": new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date()),
			"metamodel": outputEcorePath,
			"extraction_guidelines": new File(ouputGuidelinesPromptPath).text,
			"extracted_output": outputJsonPath,
			"expected_output": gtJsonPath,
			"metrics": metrics,
			"previous_analysis": prevAnalysisFile.exists() ? prevAnalysisFile.text : ""
		]
		
		def prevF1Score = 0.0f
		def bestIterationEntry = iterationEntry
		if (!pastIterations.empty) {
			// Handle backtracking if the new F1-score is worse than the previous iteration
			bestIterationEntry = pastIterations.max { it.metrics.objectF1 }
			prevF1Score = bestIterationEntry?.metrics.objectF1
			iterationEntry["f1_score_increment"] = iterationEntry.metrics.objectF1 - bestIterationEntry.metrics.objectF1
			iterationEntry["recall_increment"] = iterationEntry.metrics.objectRecall - bestIterationEntry.metrics.objectRecall
			iterationEntry["precision_increment"] = iterationEntry.metrics.objectPrecision - bestIterationEntry.metrics.objectPrecision
		} else {
			iterationEntry["f1_score_increment"] = iterationEntry.metrics.objectF1
			iterationEntry["recall_increment"] = iterationEntry.metrics.objectRecall
			iterationEntry["precision_increment"] = iterationEntry.metrics.objectPrecision
		}
		
		
	
		if (f1_score >= F1_THRESHOLD) {
			println "🚩 F1-score (${f1_score}) meets the threshold. No refinement needed."
			iterationEntry["analysis"] = "Final iteration - No further refinements needed."
			pastIterations << iterationEntry
			logFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(pastIterations))
			return false
		}
	
		
		if (prevF1Score > 0 && f1_score < prevF1Score) {
			println "⚠ F1-score did not improve (${f1_score} <= ${prevF1Score}). Backtracking to previous iteration."
	
			iterationEntry["analysis"] = analyseExtractedDataForBacktracking(
				imageUrl, mimetype,
				outputJsonPath, gtJsonPath,
				outputEcorePath, ouputGuidelinesPromptPath,
				outputAnalysisPath,
				iterationEntry)
			iterationEntry["backtracked_to_iteration"] = bestIterationEntry.iteration
			// Update the log file with the backtracked iteration
			pastIterations << iterationEntry
			logFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(pastIterations))
			
			// Rename current iteration folder
			File iterationDir = new File("output/iteration_${String.format('%02d', currentIteration)}")
			if (iterationDir.exists()) {
				iterationDir.renameTo("output/iteration_${String.format('%02d', currentIteration)}_BACKTRACKED")
				println "🗑️ Backtracked iteration folder: ${iterationDir.path}"
			}
	
			return true	
		} 
			
		// Normal analysis process
		iterationEntry["analysis"] = analyseExtractedData(
			imageUrl, mimetype,
			outputJsonPath, gtJsonPath,
			outputEcorePath, ouputGuidelinesPromptPath,
			outputAnalysisPath,
			iterationEntry)
	
		pastIterations << iterationEntry
		logFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(pastIterations))
		println "\t✔️ F1-score (${f1_score}) while threshold is ${F1_THRESHOLD}: need further refinement."
		println "\t✔️ Logged iteration ${currentIteration} in ${logFilePath}"
	
		return currentIteration < MAX_ITERATIONS
	}
	
	
	
	
	
	
	
	
	
	
	
	
	// HELPERS
	
	
	static void copyFeatureMappingsAndReflection(int currentIteration, String outputDirPath) {
		if (currentIteration > 1) {
			File prevMappingFile = new File("${outputDirPath}/iteration_${String.format('%02d', currentIteration - 1)}/generated_emfsyncer_mappings.json")
			File newMappingFile = new File("${outputDirPath}/iteration_${String.format('%02d', currentIteration)}/generated_emfsyncer_mappings.json")
	
			if (prevMappingFile.exists() && !newMappingFile.exists()) {
				newMappingFile.text = prevMappingFile.text
			}
			
			File prevReflectionFile = new File("${outputDirPath}/iteration_${String.format('%02d', currentIteration - 1)}/analysis.md")
			File newReflectionFile = new File("${outputDirPath}/iteration_${String.format('%02d', currentIteration)}/previous_analysis.md")
	
			if (prevReflectionFile.exists() && !newReflectionFile.exists()) {
				newReflectionFile.text = prevReflectionFile.text
			}
		}
	}

	
	def getHighestObjectF1Iteration(String jsonFilePath) {
		Map json = new JsonSlurper().parse(new File(jsonFilePath))
		def highest = json.max { it.metrics.objectF1 }
		return highest.iteration
	}
}
