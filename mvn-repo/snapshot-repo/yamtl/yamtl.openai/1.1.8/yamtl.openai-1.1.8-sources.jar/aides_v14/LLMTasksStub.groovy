package aides_v14

import emf_syncer.roles.SynchronizationMetricsRecord

// Stubbed version of LLMTasks class to avoid real API calls
class LLMTasksStub {

    static String SYSTEM_CONTEXT = """
    Our system extracts structured data from images based on a **metamodel** and predefined **extraction guidelines**. 
    The **metamodel** defines entities, attributes, and relationships, 
    while the **extraction guidelines** instruct how to extract and format data into a JSON structure. 

    After processing, the extracted JSON is compared with an expected JSON reference. 
    Evaluation metrics (precision, recall, and F1-score) indicate alignment between 
    the extracted and expected data (ground truth). 
    """
    
    // ✅ Stub for generateOrRefineMetamodelAndGuidelines static method
    static void generateOrRefineMetamodel(String imageUrl, String mimetype, String strategyText, String expectedJsonPath,
                                                       String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath,
                                                       String strategyId, int iteration, String parentStrategyId) {
        println "🔹 Stubbed: Generating or refining metamodel and guidelines for strategy: ${strategyText}"
    }
    
	// ✅ Stub for generateOrRefineMetamodelAndGuidelines static method
	static String generateOrRefineGuidelines(String imageUrl, String mimetype, String strategyText, String expectedJsonPath,
													   String outputMetamodelJsonPath, String outputEcorePath, String outputGuidelinesPromptPath,
													   String strategyId, int iteration, String parentStrategyId) {
		return new File('src/main/resources/sample_iteration/extraction_guidelines.md').text
	}

    // ✅ Stub for generateOrRefineStrategies static method
    static String generateOrRefineStrategies(String imageUrl, String mimetype,  int branching_factor, Map bestStrategy) {
        return '''[
            {
                "id": 1,
                "name": "Grid-Based Extraction",
                "guidelines": "Extract values based on grid structure."
            },
            {
                "id": 2,
                "name": "Quadrant-Based Extraction",
                "guidelines": "Extract values based on quadrant segmentation."
            }
        ]'''
    }

	static Object extractDataFromImage(String imageUrl, String mimetype, String outputEcorePath, String ouputGuidelinesPromptPath, String outputJsonPath) {
		println "🔹 Stubbed: Extracting data from image: ${imageUrl}"
		
		// Mocked response simulating the structure of the actual LLM response
		return [body: [message: '{"mocked": "extracted json"}']]
	}

    // ✅ Stub for analyseExtractedData static method
    static String analyseExtractedData(
        String imageUrl, String mimetype, String outputJsonPath, String gtJsonPath, String outputEcorePath,
        String ouputGuidelinesPromptPath, String outputAnalysisPath, Map iterationEntry) {
        println "🔹 Stubbed: Analyzing extracted data for image: ${imageUrl}"
        return "Mocked analysis result"
    }

    // ✅ Stub for analyseExtractedDataForBacktracking static method
    static String analyseExtractedDataForBacktracking(
        String imageUrl, String mimetype, String outputJsonPath, String gtJsonPath, String outputEcorePath,
        String ouputGuidelinesPromptPath, String outputAnalysisPath, Map iterationEntry) {
        println "🔹 Stubbed: Analyzing extracted data for backtracking on image: ${imageUrl}"
        return "Mocked backtracking analysis result"
    }

	static void ensureFeatureMappings(String outputEcorePath, String outputFeatureMappingJsonPath) {
		println "🔹 Stubbed: ensureFeatureMappings"
	}


	
	
	static void convertJsonToEMF(String outputJsonPath, String outputEcorePath, String outputXmiPath) {
		println "🔹 Stubbed: convertJsonToEMF"
	}
	
	
	static SynchronizationMetricsRecord compareModels(String outputEcorePath, String outputFeatureMappingJsonPath, String outputXmiPath, String gtXmiPath)  {
		println "🔹 Stubbed: compareModels"
		def metrics = new SynchronizationMetricsRecord()
		metrics.objectF1 = 0.8
		return metrics
	}
	
}
