package aides_v14

interface DecisionStrategy {
    List<Map> generateCandidates(String imageUrl, String mimetype, SearchNode bestParentNode, String reflectionIfBacktracking, int branchingFactor)
}
