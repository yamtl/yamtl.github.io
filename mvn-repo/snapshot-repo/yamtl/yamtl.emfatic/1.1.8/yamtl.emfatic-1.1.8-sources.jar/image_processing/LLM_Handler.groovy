package image_processing

import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.resource.Resource

import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncerParameter_EMF_untyped
import groovy.json.JsonOutput
import prettyprinting.EMFPrettyPrinter
import untypedModel.UntypedModelPackage
import yamtl.core.YAMTLModule

class LLM_Handler extends YAMTLModule {
	
	
	static void main(String... args) {
		def image_url = 'https://raw.githubusercontent.com/yamtl/yamtl.openai/main/images/vfm_647R.png'
		def metamodel_filePath = 'model/visualFieldMap.ecore'
		def metamodel_puml = EMFPrettyPrinter.ecore_to_classDiagram_PlantUML(metamodel_filePath)
		println (metamodel_puml)
		
		def prompt = '''Extract the numerical sensitivity values from the matrix, ensuring that the structure and separators are preserved accurately.
Formatting Rules:
* When two values in the same row are separated by a vertical line, consider them in separate quadrants.
* When two values in the same column are separated by a horizontal line, consider them in separate quadrants.
* Maintain the exact spatial structure of the original table, including all separations.
  * All values before the vertical line and above the horizontal line are in the quadrant "TOP_LEFT".
  * All values after the vertical line and above the horizontal line are in the quadrant "TOP_RIGHT"
  * All values before the vertical line and below the horizontal line are in the quadrant "BOTTOM_LEFT"
  * All values after the vertical line and below the horizontal line are in the quadrant "BOTTOM_RIGHT"

Output the result in JSON using the schema below so that each JSON object has a field 'type' with the name of the class it is instantiating:'''
		
		
		def client = new RestApiClient("http://localhost:5000")
		def response = client.extractData(
			metamodel_puml,
			prompt,
			image_url,
			"gpt-4o-mini"
		)
		
		def json_file = new File('tmp.json')
		if (json_file.exists()) {
			json_file.delete()
		}
		json_file<<JsonOutput.prettyPrint(JsonOutput.toJson(response))
		System.out.println("JSON response saved to tmp.json");
		
		
		Resource metamodelRes = LLM_Handler.preloadMetamodel(metamodel_filePath)
		EPackage metamodel = (EPackage)metamodelRes.getContents().get(0);
		
		
		def syncer = new EMFSyncer();
		syncer.enableEagerMode();
		syncer.setSourceModelHandler( new EMFSyncerParameter_EMF_untyped("json", Map.of("pk", UntypedModelPackage.eINSTANCE)) );
		syncer.setTargetModelHandler( new EMFSyncerParameter_EMF("vfm", Map.of("pk",metamodel)) );

		// Load the model
		syncer.loadSourceModel(json_file.getAbsolutePath());
		
		// Sync the model
		syncer.forwardSync();
		syncer.saveTargetModel("./output.xmi");
		System.out.println("Model saved to output.xmi");
	}
}
