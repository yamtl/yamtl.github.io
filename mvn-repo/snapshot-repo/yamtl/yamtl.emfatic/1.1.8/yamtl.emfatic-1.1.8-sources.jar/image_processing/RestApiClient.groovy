package image_processing;

import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.net.HttpURLConnection
import java.net.URL

class RestApiClient {
    String baseUrl

    RestApiClient(String baseUrl) {
        this.baseUrl = baseUrl
    }

    def extractData(String metamodelPuml, String prompt, String imageUrl, String openaiModel, Double temp = 0.01) {
        def payload = [
            metamodel_puml: metamodelPuml,
            prompt: prompt,
            image_url: imageUrl,
            openai_model: openaiModel,
            temp: temp
        ]

        def jsonPayload = JsonOutput.toJson(payload)
        def url = new URL("${baseUrl}/extract-data")
        def connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.outputStream.withWriter("UTF-8") { it.write(jsonPayload) }

        def responseCode = connection.responseCode
        if (responseCode == HttpURLConnection.HTTP_OK) {
            def jsonResponse = new JsonSlurper().parse(connection.inputStream)
            return jsonResponse
        } else {
            def errorResponse = connection.errorStream?.text ?: "Unknown error"
            throw new RuntimeException("Request failed with status: ${responseCode}, response: ${errorResponse}")
        }
    }
}
