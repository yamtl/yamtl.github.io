package yamtl.openai.not_working;

import java.nio.file.Files
import java.nio.file.Paths

import com.fasterxml.jackson.databind.ObjectMapper
import com.openai.client.OpenAIClient
import com.openai.client.okhttp.OpenAIOkHttpClient
import com.openai.models.ChatCompletion
import com.openai.models.ChatCompletionCreateParams


/**
 * This class contains a method that uses the official OpenAI Java SDK
 * to extract structured data from an image based on a parameterized prompt.
 */
class OpenAIImageExtractor {

    /**
     * Extracts JSON structured data from the given image.
     *
     * @param metamodel_puml   a String containing the PlantUML text that defines the JSON schema
     * @param prompt           a parameterized prompt (see example prompt below)
     * @param image_filePath   the path to the image file to be analyzed
     * @param openai_model     the OpenAI model identifier (for example, "gpt-4o" or any model supported by your account)
     * @param temp             the temperature for the API call (default is 0.01)
     * @return a JSON String representing the extracted structured data
     */
    static String extractData(String metamodel_puml, String prompt, String image_filePath, String openai_model, double temp = 0.01) {
        // Read the image file and encode it as base64
        File imageFile = new File(image_filePath)
        if (!imageFile.exists()) {
            throw new FileNotFoundException("Image file not found at: ${image_filePath}")
        }
        byte[] imageBytes = Files.readAllBytes(Paths.get(image_filePath))
        String base64Image = Base64.encoder.encodeToString(imageBytes)
//		String imageDataUrl = "data:image/jpeg;base64," + base64Image
		

        // Build the combined prompt by appending the image and metamodel
        String combinedPrompt = """\
${prompt}

Base64-encoded image (image/png):
${base64Image}

Metamodel:
${metamodel_puml}"""
        
		
		// Construct the message content
//		String messageContent = "[{\"type\": \"text\", \"text\": \"$combinedPrompt\"}, {\"type\": \"image_url\", \"image_url\": {\"url\": \"$imageDataUrl\"}}]"

		
        // Get the API key from the environment variable
        String apiKey = System.getenv("OPENAI_API_KEY")
        if (!apiKey?.trim()) {
            throw new IllegalStateException("Environment variable OPENAI_API_KEY is not set.")
        }
        
        // Create the OpenAI client using the official SDK
        OpenAIClient client = OpenAIOkHttpClient.builder()
                .apiKey(apiKey)
                .build()

        // Build the chat completion request.
        // Here we treat the entire combined prompt as a "user" message.
        ChatCompletionCreateParams params = ChatCompletionCreateParams.builder()
                .addUserMessage(combinedPrompt)
                .model(openai_model)
                .temperature(temp)
				.maxCompletionTokens(16384)
                .build()

        // Call the chat completions endpoint
        ChatCompletion completion = client.chat().completions().create(params)

		
		
        // Extract and return the text from the first choice.
        if (completion?.choices != null && !completion.choices.value.isEmpty()) {
		    return completion.choices.value.get(0).message.value.content
		} else {
            throw new RuntimeException("No completion returned from the OpenAI API.")
        }
    }

    /**
     * Main method that illustrates how to call extractData.
     * The result (JSON text) is printed and saved to a file named 'output.json'.
     */
    static void main(String[] args) {
        // Example metamodel (PlantUML schema) for demonstration.
        String metamodel_puml = '''
@startuml

class VisualFieldTest {
  + testID: String
  + patientID: String
  + testType: String  // "10-2", "24-2", "30-2", etc.
  + eyeTested: String // "LEFT" or "RIGHT"
  + date: Date
}

class Quadrant {
  + quadrantType: String  // "TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"
}

class SensitivityPoint {
  + row: Integer
  + column: Integer
  + sensitivityValue: Float // Decibels (dB)
}

VisualFieldTest "1" -- "4" Quadrant : contains
Quadrant "1" -- "many" SensitivityPoint : has

@enduml
'''

        // Example prompt as provided in the requirements.
        String prompt = '''Extract the numerical sensitivity values from the matrix, ensuring that the structure and separators are preserved accurately.
Formatting Rules:
* When two values in the same row are separated by a vertical line, consider them in separate quadrants.
* When two values in the same column are separated by a horizontal line, consider them in separate quatrants.
* Maintain the exact spatial structure of the original table, including all separations.
  * All values before the vertical line and above the horizontal line are in the quadrant "TOP_LEFT".
  * All values after the vertical line and above the horizontal line are in the quadrant "TOP_RIGHT"
  * All values before the vertical line and below the horizontal line are in the quadrant "BOTTOM_LEFT"
  * All values before the vertical line and below the horizontal line are in the quadrant "BOTTOM_RIGHT"

Please provide only the JSON object as the output, without any additional text or explanation.

Output the result in JSON using this schema:'''

        // Set the image file path, OpenAI model, and optionally adjust the temperature.
        String image_filePath = "src/main/resources/vfm_647R.png"
        String openai_model = "gpt-4o"  // adjust as needed

        try {
            String jsonResult = extractData(metamodel_puml, prompt, image_filePath, openai_model)
            println "Received JSON result:"
            println jsonResult

            // Save the JSON result to a file named 'output.json'
            File outputFile = new File("output.json")
            outputFile.write(jsonResult, "UTF-8")
            println "Output saved to ${outputFile.absolutePath}"
        } catch(Exception e) {
            e.printStackTrace()
        }
    }
}
