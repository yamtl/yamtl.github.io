package yamtl.openai.not_working

import com.fasterxml.jackson.databind.ObjectMapper
import com.openai.client.OpenAIClient
import com.openai.client.okhttp.OpenAIOkHttpClient
import com.openai.models.Upload
import com.openai.models.UploadCreateParams

/**
 * This class demonstrates how to upload an image using the official OpenAI Java SDK’s upload service
 * (via client.uploads()) and then use a multimodal chat completion request to extract structured data.
 */
class OpenAIImageExtractor_rest_url {

    /**
     * Extracts JSON structured data from the given image.
     *
     * @param metamodel_puml   a String containing the PlantUML text that defines the JSON schema
     * @param prompt           the prompt text for the LLM
     * @param image_filePath   the path to the image file to be analyzed
     * @param openai_model     the OpenAI model identifier (e.g., "gpt-4o")
     * @param temp             the temperature for the API call (default is 0.01)
     * @return a JSON String representing the extracted structured data
     */
    static String extractData(String metamodel_puml, String prompt, String image_url, String openai_model, double temp = 0.01) {
        
        // Get the API key from the environment
        String apiKey = System.getenv("OPENAI_API_KEY")
        if (!apiKey?.trim()) {
            throw new IllegalStateException("Environment variable OPENAI_API_KEY is not set.")
        }
        
        // Create the OpenAI client using the official SDK
        OpenAIClient client = OpenAIOkHttpClient.builder()
                .apiKey(apiKey)
                .build()
        
        
				
				
				
        // Build the structured message content: text for the prompt, an image attachment (using file_id), and metamodel text.
        def messages = [
            [
                role: "user",
                content: [
                    [ type: "text", text: prompt + metamodel_puml],
                    [ type: "image_url", image_url: [ url: image_url, detail: "high" ] ]
                ]
            ]
        ]
        
        // Prepare the request body using the ObjectMapper.
        ObjectMapper mapper = new ObjectMapper()
        def requestBody = [
            model       : openai_model,
            messages    : messages,
            temperature : temp,
            max_tokens  : 16384
        ]
        String requestBodyJson = mapper.writeValueAsString(requestBody)
        
        // Call the chat completions endpoint directly using an HTTP POST.
        URL url = new URL("https://api.openai.com/v1/chat/completions")
        HttpURLConnection connection = (HttpURLConnection) url.openConnection()
        connection.setRequestMethod("POST")
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Authorization", "Bearer ${apiKey}")
        
        connection.getOutputStream().withWriter("UTF-8") { writer ->
            writer.write(requestBodyJson)
        }
        
        String response = connection.getInputStream().getText("UTF-8")
        def jsonResponse = mapper.readTree(response)
        if (jsonResponse.get("choices") && jsonResponse.get("choices").size() > 0) {
            return jsonResponse.get("choices").get(0).get("message").get("content").asText()
        } else {
            throw new RuntimeException("No completion returned from the OpenAI API.")
        }
    }
    
    /**
     * Main method illustrating how to call extractData.
     * The JSON result is printed and saved to an output file.
     */
    static void main(String[] args) {
        // Example PlantUML metamodel (defines the JSON schema)
        String metamodel_puml = '''
@startuml

class VisualFieldTest {
  + testID: String
  + patientID: String
  + testType: String  // "10-2", "24-2", "30-2", etc.
  + eyeTested: String // "LEFT" or "RIGHT"
  + date: Date
}

class Quadrant {
  + quadrantType: String  // "TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"
}

class SensitivityPoint {
  + row: Integer
  + column: Integer
  + sensitivityValue: Float // Decibels (dB)
}

VisualFieldTest "1" -- "4" Quadrant : contains
Quadrant "1" -- "many" SensitivityPoint : has

@enduml
'''
        
        // Example prompt as provided in your requirements.
        String prompt = '''Extract the numerical sensitivity values from the matrix, ensuring that the structure and separators are preserved accurately.
Formatting Rules:
* When two values in the same row are separated by a vertical line, consider them in separate quadrants.
* When two values in the same column are separated by a horizontal line, consider them in separate quadrants.
* Maintain the exact spatial structure of the original table, including all separations.
  * All values before the vertical line and above the horizontal line are in the quadrant "TOP_LEFT".
  * All values after the vertical line and above the horizontal line are in the quadrant "TOP_RIGHT"
  * All values before the vertical line and below the horizontal line are in the quadrant "BOTTOM_LEFT"
  * All values after the vertical line and below the horizontal line are in the quadrant "BOTTOM_RIGHT"

Please provide only the JSON object as the output, without any additional text or explanation.

Output the result in JSON using this schema:'''
        
        // Set the image file path and OpenAI model identifier.
        String image_url = "https://raw.githubusercontent.com/yamtl/yamtl.openai/main/images/vfm_647R.png"
        String openai_model = "gpt-4o"  // adjust as needed
        
        try {
            String jsonResult = extractData(metamodel_puml, prompt, image_url, openai_model)
            println "Received JSON result:"
            println jsonResult
            
            // Save the JSON result to a file named 'output.json'
            File outputFile = new File("output.json")
            outputFile.write(jsonResult, "UTF-8")
            println "Output saved to ${outputFile.absolutePath}"
        } catch(Exception e) {
            e.printStackTrace()
        }
    }
}
