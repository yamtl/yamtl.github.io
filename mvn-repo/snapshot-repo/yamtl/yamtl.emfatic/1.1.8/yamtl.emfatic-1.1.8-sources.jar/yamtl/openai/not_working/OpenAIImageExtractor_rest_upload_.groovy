package yamtl.openai.not_working

import java.nio.file.Files;

import com.fasterxml.jackson.databind.ObjectMapper
import com.openai.client.OpenAIClient
import com.openai.client.okhttp.OpenAIOkHttpClient
import com.openai.models.FilePurpose
import com.openai.models.Upload
import com.openai.models.UploadCreateParams

/**
 * This class demonstrates how to upload an image using the official OpenAI Java SDK’s upload service
 * (via client.uploads()) and then call the chat completions endpoint with a multimodal message.
 */
class OpenAIImageExtractor_rest_upload_ {

    /**
     * Extracts JSON structured data from the given image.
     *
     * @param metamodel_puml   a String containing the PlantUML text that defines the JSON schema
     * @param prompt           the prompt text for the LLM
     * @param imageFilePath    the path to the image file to be analyzed
     * @param openai_model     the OpenAI model identifier (e.g., "gpt-4o")
     * @param temp             the temperature for the API call (default is 0.01)
     * @return a JSON String representing the extracted structured data
     */
    static String extractData(String metamodel_puml, String prompt, String imageFilePath, String openai_model, double temp = 0.01) {

        // Get API key from environment
        String apiKey = System.getenv("OPENAI_API_KEY")
        if (!apiKey?.trim()) {
            throw new IllegalStateException("Environment variable OPENAI_API_KEY is not set.")
        }

        // Create the OpenAI client using the official SDK
        OpenAIClient client = OpenAIOkHttpClient.builder()
                .apiKey(apiKey)
                .build()

        // Upload the image file using the upload service with UploadCreateParams
        File imageFile = new File(imageFilePath)
        if (!imageFile.exists()) {
            throw new FileNotFoundException("Image file not found at: ${imageFilePath}")
        }
        InputStream imageStream = new FileInputStream(imageFile)
		
		byte[] imageBytes = imageFile.bytes
		
        def uploadParams = UploadCreateParams.builder()
				.bytes(imageBytes.length)	
                .filename(imageFilePath)
                .purpose(FilePurpose.VISION)
				.mimeType("image/png")
                .build()

        Upload upload = client.uploads().create(uploadParams)
        String fileId = upload.id()
        println "Uploaded file with id: ${fileId}"

        // Build the structured message content (exactly as in the Python script):
        //  - a text block for the prompt
        //  - an image_file attachment that references the file_id
        //  - a text block for the metamodel
        def messages = [
            [
                role: "user",
                content: [
                    [ type: "text", text: prompt ],
                    [ type: "image_file", image_file: [ file_id: fileId, detail: "auto" ] ],
                    [ type: "text", text: "Metamodel:\n" + metamodel_puml ]
                ]
            ]
        ]

        // Build the request body
        ObjectMapper mapper = new ObjectMapper()
        def requestBody = [
            model       : openai_model,
            messages    : messages,
            temperature : temp,
            max_tokens  : 16384
        ]
        String requestBodyJson = mapper.writeValueAsString(requestBody)

        // Send the POST request to the chat completions endpoint
        URL url = new URL("https://api.openai.com/v1/chat/completions")
        HttpURLConnection connection = (HttpURLConnection) url.openConnection()
        connection.setRequestMethod("POST")
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Authorization", "Bearer ${apiKey}")

        connection.getOutputStream().withWriter("UTF-8") { writer ->
            writer.write(requestBodyJson)
        }

        String response = connection.getInputStream().getText("UTF-8")
        def jsonResponse = mapper.readTree(response)
        if (jsonResponse.get("choices") && jsonResponse.get("choices").size() > 0) {
            return jsonResponse.get("choices").get(0).get("message").get("content").asText()
        } else {
            throw new RuntimeException("No completion returned from the OpenAI API.")
        }
    }

    /**
     * Main method illustrating how to call extractData.
     */
    static void main(String[] args) {
        // Example metamodel (PlantUML schema)
        String metamodel_puml = '''
@startuml

class VisualFieldTest {
  + testID: String
  + patientID: String
  + testType: String  // "10-2", "24-2", "30-2", etc.
  + eyeTested: String // "LEFT" or "RIGHT"
  + date: Date
}

class Quadrant {
  + quadrantType: String  // "TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"
}

class SensitivityPoint {
  + row: Integer
  + column: Integer
  + sensitivityValue: Float // Decibels (dB)
}

VisualFieldTest "1" -- "4" Quadrant : contains
Quadrant "1" -- "many" SensitivityPoint : has

@enduml
'''

        // Example prompt
        String prompt = '''Extract the numerical sensitivity values from the matrix, ensuring that the structure and separators are preserved accurately.
Formatting Rules:
* When two values in the same row are separated by a vertical line, consider them in separate quadrants.
* When two values in the same column are separated by a horizontal line, consider them in separate quadrants.
* Maintain the exact spatial structure of the original table, including all separations.
  * All values before the vertical line and above the horizontal line are in the quadrant "TOP_LEFT".
  * All values after the vertical line and above the horizontal line are in the quadrant "TOP_RIGHT"
  * All values before the vertical line and below the horizontal line are in the quadrant "BOTTOM_LEFT"
  * All values after the vertical line and below the horizontal line are in the quadrant "BOTTOM_RIGHT"

Please provide only the JSON object as the output, without any additional text or explanation.

Output the result in JSON using this schema:'''

        // Set the image file path and model
        String imageFilePath = "src/main/resources/vfm_647R.png"
        String openai_model = "gpt-4o"  // adjust as needed

        try {
            String jsonResult = extractData(metamodel_puml, prompt, imageFilePath, openai_model)
            println "Received JSON result:"
            println jsonResult

            // Optionally, save the result to output.json
            new File("output.json").withWriter("UTF-8") { it.write(jsonResult) }
            println "Output saved to output.json"
        } catch(Exception e) {
            e.printStackTrace()
        }
    }
}
