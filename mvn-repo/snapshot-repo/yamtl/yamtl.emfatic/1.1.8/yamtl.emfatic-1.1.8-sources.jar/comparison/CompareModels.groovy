package comparison;

import emf_syncer.EMFSyncer
import emf_syncer.EMFSyncerParameter_EMF
import emf_syncer.EMFSyncer.ComparisonMode
import emf_syncer.dsl.FeatureMappingFactory
import yamtl.core.YAMTLModule

public class CompareModels {
	static void main(String... args) {
		def extractedModelPath = 'src/main/groovy/comparison/extractedData.xmi'
		def gtModelPath = 'src/main/groovy/comparison/gtModel.xmi'
		
        def metamodel = YAMTLModule.preloadMetamodel("model/visualFieldMap.ecore")
        def pk = metamodel.contents[0]

        def syncer = new EMFSyncer()
        syncer.setSourceModelHandler(new EMFSyncerParameter_EMF("e", [pk: pk]))
        syncer.setTargetModelHandler(new EMFSyncerParameter_EMF("g", [pk: pk]))
        syncer.enableStateExtent()

        def mappings = [
//            FeatureMappingFactory.create("VisualFieldMap", "patientID", "VisualFieldMap", "patientID"),
//            FeatureMappingFactory.create("VisualFieldMap", "testType", "VisualFieldMap", "testType"),
//            FeatureMappingFactory.create("VisualFieldMap", "eyeTested", "VisualFieldMap", "eyeTested"),
            FeatureMappingFactory.create("Quadrant", "quadrantType", "Quadrant", "quadrantType"),
            FeatureMappingFactory.create("SensitivityPoint", "owningQuadrant", "SensitivityPoint", "owningQuadrant"),
            FeatureMappingFactory.create("SensitivityPoint", "row", "SensitivityPoint", "row"),
            FeatureMappingFactory.create("SensitivityPoint", "column", "SensitivityPoint", "column")
        ]

        syncer.setSimilarityRelation(true, mappings, ComparisonMode.EXACT)
        syncer.loadSourceModel(extractedModelPath)
        syncer.loadTargetModel(gtModelPath)
        syncer.match()

        def metrics = syncer.getForwardMetrics()
        println("Comparison metrics: \n" + metrics)
        println(metrics.toString())
    }
}

