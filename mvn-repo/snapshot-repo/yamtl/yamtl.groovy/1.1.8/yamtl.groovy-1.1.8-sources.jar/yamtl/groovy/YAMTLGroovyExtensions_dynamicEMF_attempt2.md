package yamtl.groovy

import java.lang.instrument.Instrumentation

import org.eclipse.emf.common.util.EList
import org.eclipse.emf.ecore.EClass
import org.eclipse.emf.ecore.EClassifier
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.EPackage

import untypedModel.ERecord
import yamtl.core.YAMTLModule

class YAMTLGroovyExtensions_dynamicEMF {
	
	static void applyMetaClassModifications(Class<?> targetInterface) {
		// Enable ExpandoMetaClass for all classes
		ExpandoMetaClass.enableGlobally()

		// Iterate over all currently loaded classes and apply the modifications
		GroovySystem.metaClassRegistry.each { MetaClass metaClass ->
		println("${metaClass.theClass} ---implements--> ${targetInterface}: ${targetInterface.isAssignableFrom(metaClass.theClass) }")
			if (targetInterface.isAssignableFrom(metaClass.theClass) && !metaClass.theClass.isInterface()) {
				applyMetaClassModificationsToClass(metaClass.theClass)
			}
		}
	}
	
    static void applyMetaClassModificationsToClass(Class<?> clazz) {
        clazz.metaClass.getProperty = { String propName ->
            def result

            if (delegate instanceof EPackage) {
                def foundClassifier = findEClass(delegate, propName)
                if (foundClassifier != null) return foundClassifier
            }

            if (delegate instanceof ERecord) {
                def attValue = delegate.attributes.get(propName)
                if (attValue) return attValue

                def refValue = delegate.references.get(propName)
                if (refValue) return refValue

                def contValue = delegate.containments.get(propName)
                if (contValue) return contValue
            }

            def metaProperty = delegate.metaClass.getMetaProperty(propName)

            if (metaProperty) {
                result = metaProperty.getProperty(delegate)
            } else {
                def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
                if (feature) {
                    result = delegate.eGet(feature)
                } else {
                    return null // throw new MissingPropertyException(propName, delegate.getClass())
                }
            }
            return result
        }

        clazz.metaClass.setProperty = { String propName, value ->
            def metaProperty = delegate.metaClass.getMetaProperty(propName)
            if (metaProperty) {
                def expectedType = metaProperty.type
                if (expectedType.name == 'java.lang.String' && value.getClass().name == 'org.codehaus.groovy.runtime.GStringImpl')
                    metaProperty.setProperty(delegate, value as String)
                else if (!expectedType.isInstance(value)) {
                    value = module.fetch(value)
                    println("resolved" + value)
                    metaProperty.setProperty(delegate, value)
                } else {
                    metaProperty.setProperty(delegate, value)
                }
            } else {
                def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
                if (feature) {
                    def expectedType = feature.eType
                    if (expectedType.name == 'java.lang.String' && value.getClass().name == 'org.codehaus.groovy.runtime.GStringImpl')
                        metaProperty.setProperty(delegate, value as String)
                    else if (!expectedType.isInstance(value)) {
                        value = module.fetch(value)
                        metaProperty.setProperty(delegate, value)
                    } else {
                        metaProperty.setProperty(delegate, value)
                    }
                } else {
                    println(propName)
                    throw new MissingPropertyException(propName, delegate.getClass())
                }
            }
        }
    }

//	
//	def static applyMetaClassModifications(EPackage ePackage) {
//		ePackage.eClassifiers.each { EClassifier classifier ->
//					
//
//			if (classifier instanceof EClass) {
//				def eClass = classifier as EClass
//				def metaClass = eClass.getInstanceClass().metaClass
//				
//				metaClass.getProperty = { String propName ->
//					def result
//					
//					if (delegate instanceof EPackage) {
//						def foundClassifier = findEClass(delegate, propName)
//						if (foundClassifier != null) return foundClassifier
//					}
//					
//					if (delegate instanceof ERecord) {
//						def attValue = delegate.attributes.get(propName)
//						if (attValue) return attValue
//						
//						def refValue = delegate.references.get(propName)
//						if (refValue) return refValue
//						
//						def contValue = delegate.containments.get(propName)
//						if (contValue) return contValue
//					}
//					
//					def metaProperty = delegate.metaClass.getMetaProperty(propName)
//					
//					if (metaProperty) {
//						result = metaProperty.getProperty(delegate)
//					} else {
//						def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
//						if (feature) {
//							result = delegate.eGet(feature)
//						} else {
//							return null // throw new MissingPropertyException(propName, delegate.getClass())
//						}
//					}
//					return result
//				}
//				
//				metaClass.setProperty = { String propName, value ->
//					def metaProperty = delegate.metaClass.getMetaProperty(propName)
//					if (metaProperty) {
//						def expectedType = metaProperty.type
//						if (expectedType.name == 'java.lang.String' && value.getClass().name == 'org.codehaus.groovy.runtime.GStringImpl')
//							metaProperty.setProperty(delegate, value as String)
//						else if (!expectedType.isInstance(value)) {
//							value = module.fetch(value)
//							println("resolved" + value)
//							metaProperty.setProperty(delegate, value)
//						} else {
//							metaProperty.setProperty(delegate, value)
//						}
//					} else {
//						def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
//						if (feature) {
//							def expectedType = feature.eType
//							if (expectedType.name == 'java.lang.String' && value.getClass().name == 'org.codehaus.groovy.runtime.GStringImpl')
//								metaProperty.setProperty(delegate, value as String)
//							else if (!expectedType.isInstance(value)) {
//								value = module.fetch(value)
//								metaProperty.setProperty(delegate, value)
//							} else {
//								metaProperty.setProperty(delegate, value)
//							}
//						} else {
//							println(propName)
//							throw new MissingPropertyException(propName, delegate.getClass())
//						}
//					}
//				}
//			}
//		}
//	}
	
	static def init(YAMTLModule module, List<EPackage> pkList) {
		def originalInvokeMethod = module.metaClass.getMetaMethod("invokeMethod", [String, Object[]] as Class[])
		def originalGetProperty = module.metaClass.getMetaMethod("getProperty", [String] as Class[])

		module.metaClass.getProperty = { String propName ->
			
			def result = null
			def metaProp = metaClass.hasProperty(this, propName)
			if (metaProp != null) {
				return metaProp.getProperty(this)
			} else {
				try {
					def field = module.getClass().getDeclaredField(propName)
					if (field != null) {
						result = field.get(module)
					} 
				} catch (NoSuchFieldException e) {
			        if (result == null) {
				        result = module.fetch(propName)
				    }
				}
			}
			if (result != null) {
				def clazz = result.getClass()
				return result.asType(clazz)
			} else return null
		}
		
		// Enable ExpandoMetaClass globally
		GroovySystem.metaClassRegistry.metaClassCreationHandle = new ExpandoMetaClassCreationHandle()

		EObject.metaClass.getProperty = { String propName ->
		    def result
			
			if (delegate instanceof EPackage) {
				def classifier = findEClass(delegate, propName)
				if (classifier != null) return classifier
			}
			
			if (delegate instanceof ERecord) {
				
				def attValue = delegate.attributes.get(propName)
				if (attValue) return attValue
				
				def refValue = delegate.references.get(propName)
				if (refValue) return refValue
				
				def contValue = delegate.containments.get(propName)
				if (contValue) return contValue
	
			}
			
		    def metaProperty = delegate.metaClass.getMetaProperty(propName)
		
		    if (metaProperty) {
		        result = metaProperty.getProperty(delegate)
		    } else {
		        def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
		        if (feature) {
		            result = delegate.eGet(feature)
		        } else {
		            return null // throw new MissingPropertyException(propName, delegate.getClass())
		        }
		    }
		    return result
		}
		
		EObject.metaClass.setProperty = { String propName, value ->
			def metaProperty = delegate.metaClass.getMetaProperty(propName)
			if (metaProperty) {
				def expectedType = metaProperty.type
				if (expectedType.name == 'java.lang.String' && value.getClass().name == 'org.codehaus.groovy.runtime.GStringImpl')
					metaProperty.setProperty(delegate, value as String)
				else if (!expectedType.isInstance(value)) {
					value = module.fetch(value)
					println("resolved" + value)
					metaProperty.setProperty(delegate, value)
				} else {
					metaProperty.setProperty(delegate, value)
				}
			} else {
				def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
				if (feature) {
					def expectedType = feature.eType
					if (expectedType.name == 'java.lang.String' && value.getClass().name == 'org.codehaus.groovy.runtime.GStringImpl')
						metaProperty.setProperty(delegate, value as String)
					else if (!expectedType.isInstance(value)) {
						value = module.fetch(value)
						metaProperty.setProperty(delegate, value)
					} else {
						metaProperty.setProperty(delegate, value)
					}
				} else {
					println(propName)
					throw new MissingPropertyException(propName, delegate.getClass())
				}
			}
		}
		
		pkList.each{ ePackage ->
			ePackage.eClassifiers.each { EClassifier classifier ->
				if (classifier instanceof EClass) {
					def eClass = classifier as EClass
					applyMetaClassModifications(eClass.getInstanceClass())
				}
			}
		}
		
		// Store the original methods to avoid recursion
		def originalAdd = EList.metaClass.getMetaMethod("add", Object)
		def originalAddAll = EList.metaClass.getMetaMethod("addAll", Collection)
		
		// Override add and addAll methods for EList
		EList.metaClass.add = { element ->
			
			if (element) {
				
				if (delegate.eStructuralFeature) {
					def expectedType = delegate.eStructuralFeature.eType
				
					if (!expectedType.isInstance(element)) {
						element = module.fetch(element)
					}
					// do not add those objects that could not be resolved (fetch returns null)
					if (element)
						originalAdd.invoke(delegate, element)
				}
			}
		}
		
		EList.metaClass.addAll = { Collection elements ->
			if (elements && elements.size()>0) {
				if (delegate.eStructuralFeature) {
					def expectedType = delegate.eStructuralFeature.eType
					elements = elements.collect { element ->
						if (!expectedType.isInstance(element)) {
							module.fetch(element)
						} else {
							element
						}
					}
					// do not add those objects that could not be resolved (fetch returns null)
					originalAddAll.invoke(delegate, elements.findAll{ it != null })
				}
			}
		}
	}
	
	
	def static findEClass(EPackage ePackage, String className) {
		// Check direct classifiers
		EClassifier classifier = ePackage.getEClassifiers().find { it instanceof EClass && it.name == className }
		if (classifier instanceof EClass) {
			return classifier
		}
	
		// Recursively check subpackages
		for (EPackage subPackage : ePackage.getESubpackages()) {
			EClass result = findEClass(subPackage, className)
			if (result != null) {
				return result
			}
		}
	
		// Return null if not found
		return null
	}

	
}
