package yamtl.groovy

import untypedModel.ERecord
import untypedModel.impl.ERecordImpl
import untypedModel.utils.ERecordImplAccessors
import untypedModel.utils.ERecordUtil

class EMFSyncerGroovyExtensions {
	static ERecordUtil util = new ERecordUtil()
	
	static def init() {
		
		/**
		 * property: explores attributes, references and containments
		 * childOf_Type
		 * childrenOf_Type
		 */
		ERecordImplAccessors.metaClass.getProperty = { String propName ->
			
			if (propName.startsWith("childOf_")) {
				def typeName = propName - "childOf_"
				return childOfType(delegate, typeName)
			}
			if (propName.startsWith("childrenOf_")) {
				def typeName = propName - "childrenOf_"
				return childrenOfType(delegate, typeName)
			}
			
			def result = util.get(delegate, propName)
			if (result != null) {
				def clazz = result.getClass()
				return result.asType(clazz)
			} 
			return result
		}

		ERecordImplAccessors.metaClass.setProperty = { String propName, value ->
			util.set(delegate, propName, value)
		}

		
//		syncer.metaClass.getProperty = { String propName ->
//			def result = null
//			def metaProp = metaClass.hasProperty(this, propName)
//			if (metaProp != null) {
//				return metaProp.getProperty(this)
//			} else {
//				try {
//					def field = module.getClass().getDeclaredField(propName)
//					if (field != null) {
//						result = field.get(module)
//					} 
//				} catch (NoSuchFieldException e) {
//									
//				    if (result == null) {
//				        result = module.fetch(propName)
//				    }
//				}
//			}
//			if (result != null) {
//				def clazz = result.getClass()
//				return result.asType(clazz)
//			} else return null
//		}
	
		
		// TODO fetch for operations and lazy rules so that we don't have to use fetch
	}

//	def static ERecord childOfType(ERecord r , String type) {
//		r ? childrenOfType(r,type)?.get(0) : null
//	}
//	
//	def static List<ERecord> childrenOfType(ERecord r , String type) {
//		r ? r.children.findAll{r2 -> r2.type==type+"Context"} : null
//	}
	
	def static ERecord childOfType(ERecord r , String type) {
		if (r != null) {
			def children = childrenOfType(r,type)
			if (children != null && !children.isEmpty())
				return children.get(0) 
		}
		return null
	}
	
	def static List<ERecord> childrenOfType(ERecord r , String type) {
		if (r != null) {
			def children = r.children.findAll{r2 -> 
				r2.type==type+"Context"
			}
			return children
		}
		return null
	}
}


