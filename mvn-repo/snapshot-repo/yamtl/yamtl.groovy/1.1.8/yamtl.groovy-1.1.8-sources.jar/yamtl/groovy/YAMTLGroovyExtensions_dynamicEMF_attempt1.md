package yamtl.groovy

import org.eclipse.emf.common.util.BasicEList
import org.eclipse.emf.ecore.EClass
import org.eclipse.emf.ecore.EClassifier
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.EPackage

import untypedModel.ERecord
import yamtl.core.YAMTLModule

class YAMTLGroovyExtensions_dynamicEMF {
	static def init(YAMTLModule module) {

		module.metaClass.getProperty = { String propName ->
			
			def result = null
			def metaProp = metaClass.hasProperty(this, propName)
			if (metaProp != null) {
				return metaProp.getProperty(this)
			} else {
				try {
					def field = module.getClass().getDeclaredField(propName)
					if (field != null) {
						result = field.get(module)
					} 
				} catch (NoSuchFieldException e) {
			        if (result == null) {
				        result = module.fetch(propName)
				    }
				}
			}
			if (result != null) {
				def clazz = result.getClass()
				return result.asType(clazz)
			} else return null
		}
		
		
		// Enable ExpandoMetaClass globally
		// Otherwise the classes implementing the metamodel are not instrumented
		GroovySystem.metaClassRegistry.metaClassCreationHandle = new ExpandoMetaClassCreationHandle()
		
		EObject.metaClass.getProperty = { String propName ->
		    def result
			
			if (delegate instanceof EPackage) {
				def classifier = findEClass(delegate, propName)
				if (classifier != null) return classifier
			}
			
			if (delegate instanceof ERecord) {
				
				def attValue = delegate.attributes.get(propName)
				if (attValue) return attValue
				
				def refValue = delegate.references.get(propName)
				if (refValue) return refValue
				
				def contValue = delegate.containments.get(propName)
				if (contValue) return contValue
	
			}
			
		    def metaProperty = delegate.metaClass.getMetaProperty(propName)
		
		    if (metaProperty) {
		        result = metaProperty.getProperty(delegate)
		    } else {
		        def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
		        if (feature) {
		            result = delegate.eGet(feature)
		        } else {
		            return null // throw new MissingPropertyException(propName, delegate.getClass())
		        }
		    }
		    return result
		}
		
		
		// TODO: somehow the module.fetch(element) is using a datatype that does not correspond with the one used in the match
		// this only happens when the same transformation is executed several times, including instantiating the class:
		// either the value is stale, or the matchPool is stale
		// It works when the trafo is instantiated once only though
		EObject.metaClass.setProperty = { String propName, value ->
			def feature = (delegate as EObject).eClass().getEStructuralFeature(propName)
			if (feature) {
				def expectedType = feature.eType
//				println("${expectedType.name} ---- ${ value.getClass().name}")
				if (((expectedType.instanceTypeName == 'java.lang.String')||(expectedType.instanceTypeName == 'EString')) && value.getClass().name == 'org.codehaus.groovy.runtime.GStringImpl') {
                    value = value as String
            		(delegate as EObject).eSet(feature, value)
				} else if (!expectedType.isInstance(value)) {
					if (feature.many) {
						if (value.size()>0) {
							if (!expectedType.isInstance(value.get(0))) {
								def elements = value.collect { element ->
									module.fetch(element)
								}
								def newList = elements.findAll{ it != null }
								def newListSameType = new BasicEList(newList)
								def metaProperty = delegate.metaClass.getMetaProperty(propName)
								if (metaProperty) 
									metaProperty.setProperty(delegate, newListSameType)
							} else {
								// Call the original setProperty method
								if (value) {
									def metaProperty = delegate.metaClass.getMetaProperty(propName)
									if (metaProperty) 
										metaProperty.setProperty(delegate, value)
								}
							}
						}
					} else {
						value = module.fetch(value)
						if (value) {
							def metaProperty = delegate.metaClass.getMetaProperty(propName)
							if (metaProperty) 
								metaProperty.setProperty(delegate, value)
						}
					}
				} else {
					if (value) {
						def metaProperty = delegate.metaClass.getMetaProperty(propName)
						if (metaProperty) 
							metaProperty.setProperty(delegate, value)
					}
				} 
			} else {
				def metaProperty = delegate.metaClass.getMetaProperty(propName)
				if (metaProperty) {
					metaProperty.setProperty(delegate, value)
				} else {
					println(propName)
					throw new MissingPropertyException(propName, delegate.getClass())
				}
			}
		}
		
//		// Store the original methods to avoid recursion
//		def originalAdd = EList.metaClass.getMetaMethod("add", Object)
//		def originalAddAll = EList.metaClass.getMetaMethod("addAll", Collection)
//		
//		// Override add and addAll methods for EList
//		EList.metaClass.add = { element ->
//			
//			if (element) {
//				
//				if (delegate.eStructuralFeature) {
//					def expectedType = delegate.eStructuralFeature.eType
//				
//					if (!expectedType.isInstance(element)) {
//						element = module.fetch(element)
//					}
//					// do not add those objects that could not be resolved (fetch returns null)
//					if (element)
//						originalAdd.invoke(delegate, element)
//				}
//			}
//		}
//		
//		EList.metaClass.addAll = { Collection elements ->
//			if (elements && elements.size()>0) {
//				if (delegate.eStructuralFeature) {
//					def expectedType = delegate.eStructuralFeature.eType
//					elements = elements.collect { element ->
//						if (!expectedType.isInstance(element)) {
//							module.fetch(element)
//						} else {
//							element
//						}
//					}
//					// do not add those objects that could not be resolved (fetch returns null)
//					originalAddAll.invoke(delegate, elements.findAll{ it != null })
//				}
//			}
//		}
	}
	
	
	
	
	def static findEClass(EPackage ePackage, String className) {
		// Check direct classifiers
		EClassifier classifier = ePackage.getEClassifiers().find { it instanceof EClass && it.name == className }
		if (classifier instanceof EClass) {
			return classifier
		}
	
		// Recursively check subpackages
		for (EPackage subPackage : ePackage.getESubpackages()) {
			EClass result = findEClass(subPackage, className)
			if (result != null) {
				return result
			}
		}
	
		// Return null if not found
		return null
	}
}
