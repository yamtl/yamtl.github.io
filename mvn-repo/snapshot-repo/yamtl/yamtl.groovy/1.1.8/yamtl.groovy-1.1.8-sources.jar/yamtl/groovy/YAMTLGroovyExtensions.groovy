package yamtl.groovy

import untypedModel.ERecord
import untypedModel.impl.ERecordImpl
import untypedModel.utils.ERecordUtil
import yamtl.core.RuleModifier
import yamtl.core.YAMTLModule

class YAMTLGroovyExtensions {
	static ERecordUtil util = new ERecordUtil()
	
	
	static def init(YAMTLModule module) {

	
		
		/**
		 * SEMI-STRUCTURED MODELS
		 */
		ERecordImpl.metaClass.getProperty = { String propName ->
			if (propName.startsWith("childOf_")) {
				def typeName = propName - "childOf_"
				return childOfType(delegate, typeName)
			}
			if (propName.startsWith("childrenOf_")) {
				def typeName = propName - "childrenOf_"
				return childrenOfType(delegate, typeName)
			}
			
			def result = util.get(delegate, propName)
			if (result != null) {
				def clazz = result.getClass()
				return result.asType(clazz)
			} 
			return result
		}

		ERecordImpl.metaClass.setProperty = { String propName, value ->
			util.set(delegate, propName, value)
		}

		
		ERecordImpl.metaClass.toString = {
			"Custom ERecord (${delegate.type}): name=${delegate.name}"
		}

		
		
		
		
		
		// fetch for operations and lazy rules so that we don't have to use fetch
        def lazyRuleNames = module.getRuleStore().values().findAll { r -> r.modifier != RuleModifier.MATCHED }.collect{r -> r.name}
        def operationNames = module.getHelperStore().values().collect { o -> o.name }
        def interceptedMethodNames = lazyRuleNames + operationNames
		interceptedMethodNames.each { methodName ->
			module.metaClass."$methodName" = { Object... args ->
				// Intercepted logic
				switch (args.length) {
					case 1: 
						// static operation helper
						def argMap = args[0]
						module.fetch(methodName as String, argMap as Map<String,Object>)
						break
					case 2: 
						// contextual operation helper
						def inVar = args[0]
						// NO output var name: def outVar = args[1].toString()
						def argMap = args[1]
						module.fetch(inVar, methodName, argMap)
						break
					case 3:
						def inVar = args[0]
						def outVar = args[1].toString()
						def argMap = args[2]
						module.fetch(inVar, outVar, methodName, argMap)
						break
				}
					
			}
		}
		
		// this must be exactly as in YAMTLGroovyExtensions_dynamicEMF
		module.metaClass.getProperty = { String propName ->
			def result = null
			def metaProp = metaClass.hasProperty(this, propName)
			if (metaProp != null) {
				return metaProp.getProperty(this)
			} else {
				try {
					def field = module.getClass().getDeclaredField(propName)
					if (field != null) {
						def priorAccessLevel = field.canAccess(module)
						field.setAccessible(true) // Grant access to private/protected fields (less secure)
				        result = field.get(module)
				        field.setAccessible(priorAccessLevel) // Revert access (optional)
					} 
				} catch (NoSuchFieldException e) {
									
				    if (result == null) {
				        result = module.fetch(propName)
				    }
				}
			}
			if (result != null) {
				def clazz = result.getClass()
				return result.asType(clazz)
			} else return null
		}
		
	}
	
	def static ERecord childOfType(ERecord r , String type) {
		if (r != null) {
			def children = childrenOfType(r,type)
			if (children != null && !children.isEmpty())
				return children.get(0)
		}
		return null
	}
	
	def static List<ERecord> childrenOfType(ERecord r , String type) {
		if (r != null) {
			def children = r.children.findAll{r2 ->
				r2.type==type+"Context"
			}
			return children
		}
		return null
	}
}
