package yamtl.core

import yamtl.dsl.Header
import yamtl.groovy.YAMTLGroovyExtensions
import yamtl.groovy.YAMTLGroovyExtensions_dynamicEMF

class YAMTLModuleGroovy extends YAMTLModule {
	
	

	@Override
	def Header header() {
		def header = super.header()
		/*
		 *  adds EMF extensions to interpret
		 *  - getters/setters of an EObject: t.name instead of t.getName()
		 *  - reference to classifiers inside an EPackage: llPk.Node instead of llPk.getEClassifier('Node')
		 */
		YAMTLGroovyExtensions_dynamicEMF.init(this)
		
		// loads setter/getter for ERecord
		YAMTLGroovyExtensions.init(this)
		
		return header
	}
	
	@Override
	def void helperStore(List<YAMTLHelper> list) {
		super.helperStore(list)
		// initialize operations so that they can be invoked without fetch
		YAMTLGroovyExtensions.init(this)
	}
	
}
