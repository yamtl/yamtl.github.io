/**
 */
package untypedModel;

import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.FeatureType#getName <em>Name</em>}</li>
 *   <li>{@link untypedModel.FeatureType#getOwner <em>Owner</em>}</li>
 *   <li>{@link untypedModel.FeatureType#getEmfType <em>Emf Type</em>}</li>
 *   <li>{@link untypedModel.FeatureType#getEmfFeatureType <em>Emf Feature Type</em>}</li>
 * </ul>
 *
 * @see untypedModel.UntypedModelPackage#getFeatureType()
 * @model
 * @generated
 */
public interface FeatureType extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see untypedModel.UntypedModelPackage#getFeatureType_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link untypedModel.FeatureType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Owner</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link untypedModel.ERecordType#getFeatureTypes <em>Feature Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owner</em>' container reference.
	 * @see #setOwner(ERecordType)
	 * @see untypedModel.UntypedModelPackage#getFeatureType_Owner()
	 * @see untypedModel.ERecordType#getFeatureTypes
	 * @model opposite="featureTypes" required="true" transient="false"
	 * @generated
	 */
	ERecordType getOwner();

	/**
	 * Sets the value of the '{@link untypedModel.FeatureType#getOwner <em>Owner</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owner</em>' container reference.
	 * @see #getOwner()
	 * @generated
	 */
	void setOwner(ERecordType value);

	/**
	 * Returns the value of the '<em><b>Emf Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Emf Type</em>' reference.
	 * @see #setEmfType(EClassifier)
	 * @see untypedModel.UntypedModelPackage#getFeatureType_EmfType()
	 * @model required="true"
	 * @generated
	 */
	EClassifier getEmfType();

	/**
	 * Sets the value of the '{@link untypedModel.FeatureType#getEmfType <em>Emf Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Emf Type</em>' reference.
	 * @see #getEmfType()
	 * @generated
	 */
	void setEmfType(EClassifier value);

	/**
	 * Returns the value of the '<em><b>Emf Feature Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Emf Feature Type</em>' reference.
	 * @see #setEmfFeatureType(EStructuralFeature)
	 * @see untypedModel.UntypedModelPackage#getFeatureType_EmfFeatureType()
	 * @model
	 * @generated
	 */
	EStructuralFeature getEmfFeatureType();

	/**
	 * Sets the value of the '{@link untypedModel.FeatureType#getEmfFeatureType <em>Emf Feature Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Emf Feature Type</em>' reference.
	 * @see #getEmfFeatureType()
	 * @generated
	 */
	void setEmfFeatureType(EStructuralFeature value);

} // FeatureType
