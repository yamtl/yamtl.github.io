/**
 */
package untypedModel;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.EMap;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ERecord Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.ERecordType#getName <em>Name</em>}</li>
 *   <li>{@link untypedModel.ERecordType#get__instances <em>instances</em>}</li>
 *   <li>{@link untypedModel.ERecordType#getFeatureTypes <em>Feature Types</em>}</li>
 *   <li>{@link untypedModel.ERecordType#getFieldTypes <em>Field Types</em>}</li>
 *   <li>{@link untypedModel.ERecordType#getOwner <em>Owner</em>}</li>
 *   <li>{@link untypedModel.ERecordType#getEmfType <em>Emf Type</em>}</li>
 * </ul>
 *
 * @see untypedModel.UntypedModelPackage#getERecordType()
 * @model
 * @generated
 */
public interface ERecordType extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see untypedModel.UntypedModelPackage#getERecordType_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link untypedModel.ERecordType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>instances</b></em>' reference list.
	 * The list contents are of type {@link untypedModel.ERecord}.
	 * It is bidirectional and its opposite is '{@link untypedModel.ERecord#get__type <em>type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>instances</em>' reference list.
	 * @see untypedModel.UntypedModelPackage#getERecordType___instances()
	 * @see untypedModel.ERecord#get__type
	 * @model opposite="__type"
	 * @generated
	 */
	EList<ERecord> get__instances();

	/**
	 * Returns the value of the '<em><b>Feature Types</b></em>' containment reference list.
	 * The list contents are of type {@link untypedModel.FeatureType}.
	 * It is bidirectional and its opposite is '{@link untypedModel.FeatureType#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Feature Types</em>' containment reference list.
	 * @see untypedModel.UntypedModelPackage#getERecordType_FeatureTypes()
	 * @see untypedModel.FeatureType#getOwner
	 * @model opposite="owner" containment="true"
	 * @generated
	 */
	EList<FeatureType> getFeatureTypes();

	/**
	 * Returns the value of the '<em><b>Field Types</b></em>' map.
	 * The key is of type {@link java.lang.String},
	 * and the value is of type {@link untypedModel.FeatureType},
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Field Types</em>' map.
	 * @see untypedModel.UntypedModelPackage#getERecordType_FieldTypes()
	 * @model mapType="untypedModel.ERecordFieldType&lt;org.eclipse.emf.ecore.EString, untypedModel.FeatureType&gt;"
	 * @generated
	 */
	EMap<String, FeatureType> getFieldTypes();

	/**
	 * Returns the value of the '<em><b>Owner</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link untypedModel.UntypedModel#getERecordTypes <em>ERecord Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owner</em>' container reference.
	 * @see #setOwner(UntypedModel)
	 * @see untypedModel.UntypedModelPackage#getERecordType_Owner()
	 * @see untypedModel.UntypedModel#getERecordTypes
	 * @model opposite="eRecordTypes" required="true" transient="false"
	 * @generated
	 */
	UntypedModel getOwner();

	/**
	 * Sets the value of the '{@link untypedModel.ERecordType#getOwner <em>Owner</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owner</em>' container reference.
	 * @see #getOwner()
	 * @generated
	 */
	void setOwner(UntypedModel value);

	/**
	 * Returns the value of the '<em><b>Emf Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Emf Type</em>' reference.
	 * @see #setEmfType(EClass)
	 * @see untypedModel.UntypedModelPackage#getERecordType_EmfType()
	 * @model
	 * @generated
	 */
	EClass getEmfType();

	/**
	 * Sets the value of the '{@link untypedModel.ERecordType#getEmfType <em>Emf Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Emf Type</em>' reference.
	 * @see #getEmfType()
	 * @generated
	 */
	void setEmfType(EClass value);

} // ERecordType
