/**
 */
package untypedModel;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see untypedModel.UntypedModelFactory
 * @model kind="package"
 * @generated
 */
public interface UntypedModelPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "untypedModel";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "https://yamtl.github.io/emfsyncer/untypedModel";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "um";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UntypedModelPackage eINSTANCE = untypedModel.impl.UntypedModelPackageImpl.init();

	/**
	 * The meta object id for the '{@link untypedModel.impl.ERecordContainerImpl <em>ERecord Container</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.ERecordContainerImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getERecordContainer()
	 * @generated
	 */
	int ERECORD_CONTAINER = 0;

	/**
	 * The feature id for the '<em><b>children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_CONTAINER__CHILDREN = 0;

	/**
	 * The number of structural features of the '<em>ERecord Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_CONTAINER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>ERecord Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_CONTAINER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.UntypedModelImpl <em>Untyped Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.UntypedModelImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getUntypedModel()
	 * @generated
	 */
	int UNTYPED_MODEL = 1;

	/**
	 * The feature id for the '<em><b>children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNTYPED_MODEL__CHILDREN = ERECORD_CONTAINER__CHILDREN;

	/**
	 * The feature id for the '<em><b>ERecord Types</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNTYPED_MODEL__ERECORD_TYPES = ERECORD_CONTAINER_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Untyped Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNTYPED_MODEL_FEATURE_COUNT = ERECORD_CONTAINER_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Untyped Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNTYPED_MODEL_OPERATION_COUNT = ERECORD_CONTAINER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.ERecordImpl <em>ERecord</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.ERecordImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getERecord()
	 * @generated
	 */
	int ERECORD = 2;

	/**
	 * The feature id for the '<em><b>children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__CHILDREN = ERECORD_CONTAINER__CHILDREN;

	/**
	 * The feature id for the '<em><b>type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__TYPE = ERECORD_CONTAINER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__ATTRIBUTES = ERECORD_CONTAINER_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>References</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__REFERENCES = ERECORD_CONTAINER_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Containments</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__CONTAINMENTS = ERECORD_CONTAINER_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>parent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__PARENT = ERECORD_CONTAINER_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>uuid Field Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__UUID_FIELD_NAME = ERECORD_CONTAINER_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>uuid</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD__UUID = ERECORD_CONTAINER_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the '<em>ERecord</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_FEATURE_COUNT = ERECORD_CONTAINER_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>ERecord</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_OPERATION_COUNT = ERECORD_CONTAINER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.AttributeValueImpl <em>Attribute Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.AttributeValueImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getAttributeValue()
	 * @generated
	 */
	int ATTRIBUTE_VALUE = 3;

	/**
	 * The feature id for the '<em><b>Key</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_VALUE__KEY = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_VALUE__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Attribute Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_VALUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attribute Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_VALUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.ReferenceValueImpl <em>Reference Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.ReferenceValueImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getReferenceValue()
	 * @generated
	 */
	int REFERENCE_VALUE = 4;

	/**
	 * The feature id for the '<em><b>Key</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_VALUE__KEY = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_VALUE__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Reference Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_VALUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Reference Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_VALUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.ContainmentValueImpl <em>Containment Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.ContainmentValueImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getContainmentValue()
	 * @generated
	 */
	int CONTAINMENT_VALUE = 5;

	/**
	 * The feature id for the '<em><b>Key</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINMENT_VALUE__KEY = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINMENT_VALUE__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Containment Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINMENT_VALUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Containment Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINMENT_VALUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.ERecordTypeImpl <em>ERecord Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.ERecordTypeImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getERecordType()
	 * @generated
	 */
	int ERECORD_TYPE = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE__NAME = 0;

	/**
	 * The feature id for the '<em><b>instances</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE__INSTANCES = 1;

	/**
	 * The feature id for the '<em><b>Feature Types</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE__FEATURE_TYPES = 2;

	/**
	 * The feature id for the '<em><b>Field Types</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE__FIELD_TYPES = 3;

	/**
	 * The feature id for the '<em><b>Owner</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE__OWNER = 4;

	/**
	 * The feature id for the '<em><b>Emf Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE__EMF_TYPE = 5;

	/**
	 * The number of structural features of the '<em>ERecord Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>ERecord Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.FeatureTypeImpl <em>Feature Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.FeatureTypeImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getFeatureType()
	 * @generated
	 */
	int FEATURE_TYPE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_TYPE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Owner</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_TYPE__OWNER = 1;

	/**
	 * The feature id for the '<em><b>Emf Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_TYPE__EMF_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Emf Feature Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_TYPE__EMF_FEATURE_TYPE = 3;

	/**
	 * The number of structural features of the '<em>Feature Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_TYPE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Feature Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link untypedModel.impl.ERecordFieldTypeImpl <em>ERecord Field Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see untypedModel.impl.ERecordFieldTypeImpl
	 * @see untypedModel.impl.UntypedModelPackageImpl#getERecordFieldType()
	 * @generated
	 */
	int ERECORD_FIELD_TYPE = 8;

	/**
	 * The feature id for the '<em><b>Key</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_FIELD_TYPE__KEY = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_FIELD_TYPE__VALUE = 1;

	/**
	 * The number of structural features of the '<em>ERecord Field Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_FIELD_TYPE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>ERecord Field Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERECORD_FIELD_TYPE_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link untypedModel.ERecordContainer <em>ERecord Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ERecord Container</em>'.
	 * @see untypedModel.ERecordContainer
	 * @generated
	 */
	EClass getERecordContainer();

	/**
	 * Returns the meta object for the containment reference list '{@link untypedModel.ERecordContainer#get__children <em>children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>children</em>'.
	 * @see untypedModel.ERecordContainer#get__children()
	 * @see #getERecordContainer()
	 * @generated
	 */
	EReference getERecordContainer___children();

	/**
	 * Returns the meta object for class '{@link untypedModel.UntypedModel <em>Untyped Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Untyped Model</em>'.
	 * @see untypedModel.UntypedModel
	 * @generated
	 */
	EClass getUntypedModel();

	/**
	 * Returns the meta object for the containment reference list '{@link untypedModel.UntypedModel#getERecordTypes <em>ERecord Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>ERecord Types</em>'.
	 * @see untypedModel.UntypedModel#getERecordTypes()
	 * @see #getUntypedModel()
	 * @generated
	 */
	EReference getUntypedModel_ERecordTypes();

	/**
	 * Returns the meta object for class '{@link untypedModel.ERecord <em>ERecord</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ERecord</em>'.
	 * @see untypedModel.ERecord
	 * @generated
	 */
	EClass getERecord();

	/**
	 * Returns the meta object for the reference '{@link untypedModel.ERecord#get__type <em>type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>type</em>'.
	 * @see untypedModel.ERecord#get__type()
	 * @see #getERecord()
	 * @generated
	 */
	EReference getERecord___type();

	/**
	 * Returns the meta object for the map '{@link untypedModel.ERecord#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>Attributes</em>'.
	 * @see untypedModel.ERecord#getAttributes()
	 * @see #getERecord()
	 * @generated
	 */
	EReference getERecord_Attributes();

	/**
	 * Returns the meta object for the map '{@link untypedModel.ERecord#getReferences <em>References</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>References</em>'.
	 * @see untypedModel.ERecord#getReferences()
	 * @see #getERecord()
	 * @generated
	 */
	EReference getERecord_References();

	/**
	 * Returns the meta object for the map '{@link untypedModel.ERecord#getContainments <em>Containments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>Containments</em>'.
	 * @see untypedModel.ERecord#getContainments()
	 * @see #getERecord()
	 * @generated
	 */
	EReference getERecord_Containments();

	/**
	 * Returns the meta object for the container reference '{@link untypedModel.ERecord#get__parent <em>parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>parent</em>'.
	 * @see untypedModel.ERecord#get__parent()
	 * @see #getERecord()
	 * @generated
	 */
	EReference getERecord___parent();

	/**
	 * Returns the meta object for the attribute '{@link untypedModel.ERecord#get__uuidFieldName <em>uuid Field Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>uuid Field Name</em>'.
	 * @see untypedModel.ERecord#get__uuidFieldName()
	 * @see #getERecord()
	 * @generated
	 */
	EAttribute getERecord___uuidFieldName();

	/**
	 * Returns the meta object for the attribute '{@link untypedModel.ERecord#get__uuid <em>uuid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>uuid</em>'.
	 * @see untypedModel.ERecord#get__uuid()
	 * @see #getERecord()
	 * @generated
	 */
	EAttribute getERecord___uuid();

	/**
	 * Returns the meta object for class '{@link java.util.Map.Entry <em>Attribute Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute Value</em>'.
	 * @see java.util.Map.Entry
	 * @model keyDataType="org.eclipse.emf.ecore.EString"
	 *        valueDataType="org.eclipse.emf.ecore.EJavaObject"
	 * @generated
	 */
	EClass getAttributeValue();

	/**
	 * Returns the meta object for the attribute '{@link java.util.Map.Entry <em>Key</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Key</em>'.
	 * @see java.util.Map.Entry
	 * @see #getAttributeValue()
	 * @generated
	 */
	EAttribute getAttributeValue_Key();

	/**
	 * Returns the meta object for the attribute '{@link java.util.Map.Entry <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see java.util.Map.Entry
	 * @see #getAttributeValue()
	 * @generated
	 */
	EAttribute getAttributeValue_Value();

	/**
	 * Returns the meta object for class '{@link java.util.Map.Entry <em>Reference Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reference Value</em>'.
	 * @see java.util.Map.Entry
	 * @model keyDataType="org.eclipse.emf.ecore.EString"
	 *        valueType="untypedModel.ERecord" valueMany="true"
	 * @generated
	 */
	EClass getReferenceValue();

	/**
	 * Returns the meta object for the attribute '{@link java.util.Map.Entry <em>Key</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Key</em>'.
	 * @see java.util.Map.Entry
	 * @see #getReferenceValue()
	 * @generated
	 */
	EAttribute getReferenceValue_Key();

	/**
	 * Returns the meta object for the reference list '{@link java.util.Map.Entry <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Value</em>'.
	 * @see java.util.Map.Entry
	 * @see #getReferenceValue()
	 * @generated
	 */
	EReference getReferenceValue_Value();

	/**
	 * Returns the meta object for class '{@link java.util.Map.Entry <em>Containment Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Containment Value</em>'.
	 * @see java.util.Map.Entry
	 * @model keyDataType="org.eclipse.emf.ecore.EString"
	 *        valueType="untypedModel.ERecord" valueContainment="true" valueMany="true"
	 * @generated
	 */
	EClass getContainmentValue();

	/**
	 * Returns the meta object for the attribute '{@link java.util.Map.Entry <em>Key</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Key</em>'.
	 * @see java.util.Map.Entry
	 * @see #getContainmentValue()
	 * @generated
	 */
	EAttribute getContainmentValue_Key();

	/**
	 * Returns the meta object for the containment reference list '{@link java.util.Map.Entry <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Value</em>'.
	 * @see java.util.Map.Entry
	 * @see #getContainmentValue()
	 * @generated
	 */
	EReference getContainmentValue_Value();

	/**
	 * Returns the meta object for class '{@link untypedModel.ERecordType <em>ERecord Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ERecord Type</em>'.
	 * @see untypedModel.ERecordType
	 * @generated
	 */
	EClass getERecordType();

	/**
	 * Returns the meta object for the attribute '{@link untypedModel.ERecordType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see untypedModel.ERecordType#getName()
	 * @see #getERecordType()
	 * @generated
	 */
	EAttribute getERecordType_Name();

	/**
	 * Returns the meta object for the reference list '{@link untypedModel.ERecordType#get__instances <em>instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>instances</em>'.
	 * @see untypedModel.ERecordType#get__instances()
	 * @see #getERecordType()
	 * @generated
	 */
	EReference getERecordType___instances();

	/**
	 * Returns the meta object for the containment reference list '{@link untypedModel.ERecordType#getFeatureTypes <em>Feature Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Feature Types</em>'.
	 * @see untypedModel.ERecordType#getFeatureTypes()
	 * @see #getERecordType()
	 * @generated
	 */
	EReference getERecordType_FeatureTypes();

	/**
	 * Returns the meta object for the map '{@link untypedModel.ERecordType#getFieldTypes <em>Field Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>Field Types</em>'.
	 * @see untypedModel.ERecordType#getFieldTypes()
	 * @see #getERecordType()
	 * @generated
	 */
	EReference getERecordType_FieldTypes();

	/**
	 * Returns the meta object for the container reference '{@link untypedModel.ERecordType#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Owner</em>'.
	 * @see untypedModel.ERecordType#getOwner()
	 * @see #getERecordType()
	 * @generated
	 */
	EReference getERecordType_Owner();

	/**
	 * Returns the meta object for the reference '{@link untypedModel.ERecordType#getEmfType <em>Emf Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Emf Type</em>'.
	 * @see untypedModel.ERecordType#getEmfType()
	 * @see #getERecordType()
	 * @generated
	 */
	EReference getERecordType_EmfType();

	/**
	 * Returns the meta object for class '{@link untypedModel.FeatureType <em>Feature Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Feature Type</em>'.
	 * @see untypedModel.FeatureType
	 * @generated
	 */
	EClass getFeatureType();

	/**
	 * Returns the meta object for the attribute '{@link untypedModel.FeatureType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see untypedModel.FeatureType#getName()
	 * @see #getFeatureType()
	 * @generated
	 */
	EAttribute getFeatureType_Name();

	/**
	 * Returns the meta object for the container reference '{@link untypedModel.FeatureType#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Owner</em>'.
	 * @see untypedModel.FeatureType#getOwner()
	 * @see #getFeatureType()
	 * @generated
	 */
	EReference getFeatureType_Owner();

	/**
	 * Returns the meta object for the reference '{@link untypedModel.FeatureType#getEmfType <em>Emf Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Emf Type</em>'.
	 * @see untypedModel.FeatureType#getEmfType()
	 * @see #getFeatureType()
	 * @generated
	 */
	EReference getFeatureType_EmfType();

	/**
	 * Returns the meta object for the reference '{@link untypedModel.FeatureType#getEmfFeatureType <em>Emf Feature Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Emf Feature Type</em>'.
	 * @see untypedModel.FeatureType#getEmfFeatureType()
	 * @see #getFeatureType()
	 * @generated
	 */
	EReference getFeatureType_EmfFeatureType();

	/**
	 * Returns the meta object for class '{@link java.util.Map.Entry <em>ERecord Field Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ERecord Field Type</em>'.
	 * @see java.util.Map.Entry
	 * @model keyDataType="org.eclipse.emf.ecore.EString"
	 *        valueType="untypedModel.FeatureType"
	 * @generated
	 */
	EClass getERecordFieldType();

	/**
	 * Returns the meta object for the attribute '{@link java.util.Map.Entry <em>Key</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Key</em>'.
	 * @see java.util.Map.Entry
	 * @see #getERecordFieldType()
	 * @generated
	 */
	EAttribute getERecordFieldType_Key();

	/**
	 * Returns the meta object for the reference '{@link java.util.Map.Entry <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Value</em>'.
	 * @see java.util.Map.Entry
	 * @see #getERecordFieldType()
	 * @generated
	 */
	EReference getERecordFieldType_Value();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	UntypedModelFactory getUntypedModelFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link untypedModel.impl.ERecordContainerImpl <em>ERecord Container</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.ERecordContainerImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getERecordContainer()
		 * @generated
		 */
		EClass ERECORD_CONTAINER = eINSTANCE.getERecordContainer();

		/**
		 * The meta object literal for the '<em><b>children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD_CONTAINER__CHILDREN = eINSTANCE.getERecordContainer___children();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.UntypedModelImpl <em>Untyped Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.UntypedModelImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getUntypedModel()
		 * @generated
		 */
		EClass UNTYPED_MODEL = eINSTANCE.getUntypedModel();

		/**
		 * The meta object literal for the '<em><b>ERecord Types</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UNTYPED_MODEL__ERECORD_TYPES = eINSTANCE.getUntypedModel_ERecordTypes();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.ERecordImpl <em>ERecord</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.ERecordImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getERecord()
		 * @generated
		 */
		EClass ERECORD = eINSTANCE.getERecord();

		/**
		 * The meta object literal for the '<em><b>type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD__TYPE = eINSTANCE.getERecord___type();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD__ATTRIBUTES = eINSTANCE.getERecord_Attributes();

		/**
		 * The meta object literal for the '<em><b>References</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD__REFERENCES = eINSTANCE.getERecord_References();

		/**
		 * The meta object literal for the '<em><b>Containments</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD__CONTAINMENTS = eINSTANCE.getERecord_Containments();

		/**
		 * The meta object literal for the '<em><b>parent</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD__PARENT = eINSTANCE.getERecord___parent();

		/**
		 * The meta object literal for the '<em><b>uuid Field Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ERECORD__UUID_FIELD_NAME = eINSTANCE.getERecord___uuidFieldName();

		/**
		 * The meta object literal for the '<em><b>uuid</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ERECORD__UUID = eINSTANCE.getERecord___uuid();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.AttributeValueImpl <em>Attribute Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.AttributeValueImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getAttributeValue()
		 * @generated
		 */
		EClass ATTRIBUTE_VALUE = eINSTANCE.getAttributeValue();

		/**
		 * The meta object literal for the '<em><b>Key</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE_VALUE__KEY = eINSTANCE.getAttributeValue_Key();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE_VALUE__VALUE = eINSTANCE.getAttributeValue_Value();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.ReferenceValueImpl <em>Reference Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.ReferenceValueImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getReferenceValue()
		 * @generated
		 */
		EClass REFERENCE_VALUE = eINSTANCE.getReferenceValue();

		/**
		 * The meta object literal for the '<em><b>Key</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REFERENCE_VALUE__KEY = eINSTANCE.getReferenceValue_Key();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFERENCE_VALUE__VALUE = eINSTANCE.getReferenceValue_Value();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.ContainmentValueImpl <em>Containment Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.ContainmentValueImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getContainmentValue()
		 * @generated
		 */
		EClass CONTAINMENT_VALUE = eINSTANCE.getContainmentValue();

		/**
		 * The meta object literal for the '<em><b>Key</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINMENT_VALUE__KEY = eINSTANCE.getContainmentValue_Key();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINMENT_VALUE__VALUE = eINSTANCE.getContainmentValue_Value();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.ERecordTypeImpl <em>ERecord Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.ERecordTypeImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getERecordType()
		 * @generated
		 */
		EClass ERECORD_TYPE = eINSTANCE.getERecordType();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ERECORD_TYPE__NAME = eINSTANCE.getERecordType_Name();

		/**
		 * The meta object literal for the '<em><b>instances</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD_TYPE__INSTANCES = eINSTANCE.getERecordType___instances();

		/**
		 * The meta object literal for the '<em><b>Feature Types</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD_TYPE__FEATURE_TYPES = eINSTANCE.getERecordType_FeatureTypes();

		/**
		 * The meta object literal for the '<em><b>Field Types</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD_TYPE__FIELD_TYPES = eINSTANCE.getERecordType_FieldTypes();

		/**
		 * The meta object literal for the '<em><b>Owner</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD_TYPE__OWNER = eINSTANCE.getERecordType_Owner();

		/**
		 * The meta object literal for the '<em><b>Emf Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD_TYPE__EMF_TYPE = eINSTANCE.getERecordType_EmfType();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.FeatureTypeImpl <em>Feature Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.FeatureTypeImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getFeatureType()
		 * @generated
		 */
		EClass FEATURE_TYPE = eINSTANCE.getFeatureType();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FEATURE_TYPE__NAME = eINSTANCE.getFeatureType_Name();

		/**
		 * The meta object literal for the '<em><b>Owner</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_TYPE__OWNER = eINSTANCE.getFeatureType_Owner();

		/**
		 * The meta object literal for the '<em><b>Emf Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_TYPE__EMF_TYPE = eINSTANCE.getFeatureType_EmfType();

		/**
		 * The meta object literal for the '<em><b>Emf Feature Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_TYPE__EMF_FEATURE_TYPE = eINSTANCE.getFeatureType_EmfFeatureType();

		/**
		 * The meta object literal for the '{@link untypedModel.impl.ERecordFieldTypeImpl <em>ERecord Field Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see untypedModel.impl.ERecordFieldTypeImpl
		 * @see untypedModel.impl.UntypedModelPackageImpl#getERecordFieldType()
		 * @generated
		 */
		EClass ERECORD_FIELD_TYPE = eINSTANCE.getERecordFieldType();

		/**
		 * The meta object literal for the '<em><b>Key</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ERECORD_FIELD_TYPE__KEY = eINSTANCE.getERecordFieldType_Key();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ERECORD_FIELD_TYPE__VALUE = eINSTANCE.getERecordFieldType_Value();

	}

} //UntypedModelPackage
