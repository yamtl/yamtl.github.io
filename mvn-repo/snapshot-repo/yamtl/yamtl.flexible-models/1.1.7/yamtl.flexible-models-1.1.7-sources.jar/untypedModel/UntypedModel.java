/**
 */
package untypedModel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Untyped Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.UntypedModel#getERecordTypes <em>ERecord Types</em>}</li>
 * </ul>
 *
 * @see untypedModel.UntypedModelPackage#getUntypedModel()
 * @model
 * @generated
 */
public interface UntypedModel extends ERecordContainer {
	/**
	 * Returns the value of the '<em><b>ERecord Types</b></em>' containment reference list.
	 * The list contents are of type {@link untypedModel.ERecordType}.
	 * It is bidirectional and its opposite is '{@link untypedModel.ERecordType#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ERecord Types</em>' containment reference list.
	 * @see untypedModel.UntypedModelPackage#getUntypedModel_ERecordTypes()
	 * @see untypedModel.ERecordType#getOwner
	 * @model opposite="owner" containment="true"
	 * @generated
	 */
	EList<ERecordType> getERecordTypes();

} // UntypedModel
