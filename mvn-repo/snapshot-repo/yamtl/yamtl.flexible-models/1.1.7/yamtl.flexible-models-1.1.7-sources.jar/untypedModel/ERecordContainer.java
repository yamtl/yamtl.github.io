/**
 */
package untypedModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ERecord Container</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.ERecordContainer#get__children <em>children</em>}</li>
 * </ul>
 *
 * @see untypedModel.UntypedModelPackage#getERecordContainer()
 * @model abstract="true"
 * @generated
 */
public interface ERecordContainer extends EObject {
	/**
	 * Returns the value of the '<em><b>children</b></em>' containment reference list.
	 * The list contents are of type {@link untypedModel.ERecord}.
	 * It is bidirectional and its opposite is '{@link untypedModel.ERecord#get__parent <em>parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>children</em>' containment reference list.
	 * @see untypedModel.UntypedModelPackage#getERecordContainer___children()
	 * @see untypedModel.ERecord#get__parent
	 * @model opposite="__parent" containment="true"
	 * @generated
	 */
	EList<ERecord> get__children();

} // ERecordContainer
