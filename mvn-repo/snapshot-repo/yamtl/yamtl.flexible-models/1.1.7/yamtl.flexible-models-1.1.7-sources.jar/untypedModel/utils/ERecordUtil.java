package untypedModel.utils;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EcorePackage;

import untypedModel.ERecord;

public class ERecordUtil {
	public ERecordUtil() {};

    public final static String  TYPE_ATTRIBUTE = "type";

    public Object get(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) {
            result = record.getContainments().get(fieldName);
            if (result == null) {
                result = record.getReferences().get(fieldName);
            }
        }
        return result;
    }
    
    public String getString(ERecord record, String fieldName) throws Exception {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        if (result instanceof String) {
            return (String) result;
        } else {
            throw new RuntimeException("The property " + fieldName + " does not contain a String value. The type found is " + result.getClass().getName());
        }
    }

    /**
     * This method is used to get a Boolean. If the attribute is not present, then 'false' is returned.
     * @param record
     * @param fieldName
     * @return
     * @throws Exception
     */
    public Boolean getBoolean(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return false;
        return switch (result.getClass().getSimpleName()) {
            case "Boolean" -> (Boolean) result;
            case "String" -> Boolean.valueOf((String) result);
            default -> null;
        };
    }

    public Integer getInteger(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        return switch (result.getClass().getSimpleName()) {
            case "Integer" -> (Integer) result;
            case "String" -> Integer.valueOf((String) result);
            default -> null;
        };
    }

    public Long getLong(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        return switch (result.getClass().getSimpleName()) {
            case "Long" -> (Long) result;
            case "String" -> Long.valueOf((String) result);
            default -> null;
        };
    }

    public Short getShort(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        return switch (result.getClass().getSimpleName()) {
            case "Short" -> (Short) result;
            case "String" -> Short.valueOf((String) result);
            default -> null;
        };
    }

    public Byte getByte(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        return switch (result.getClass().getSimpleName()) {
            case "Byte" -> (Byte) result;
            case "String" -> Byte.valueOf((String) result);
            default -> null;
        };
    }


    public Float getFloat(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        return switch (result.getClass().getSimpleName()) {
            case "Float" -> (Float) result;
            case "String" -> Float.valueOf((String) result);
            default -> null;
        };
    }

    public Double getDouble(ERecord record, String fieldName) {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        return switch (result.getClass().getSimpleName()) {
            case "Double" -> (Double) result;
            case "String" -> Double.valueOf((String) result);
            default -> null;
        };
    }

    public Date getDate(ERecord record, String fieldName, String format) throws ParseException {
        Object result = record.getAttributes().get(fieldName);
        if (result == null) return null;
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return switch (result.getClass().getSimpleName()) {
            case "Date" -> (Date) result;
            case "String" -> sdf.parse((String) result);
            default -> null;
        };
    }


    /** REFERENCES **/

    public List<ERecord> getRefs(ERecord record, String fieldName) {
        List<ERecord> result = record.getContainments().get(fieldName);
        if (result == null) {
            result = record.getReferences().get(fieldName);
        }
        return result;
    }
    
    public ERecord getRef(ERecord record, String fieldName) throws Exception {
    	List<ERecord> result = record.getContainments().get(fieldName);
    	if (result == null) {
    		result = record.getReferences().get(fieldName);
    		if (result != null) {
    			if (result.size() > 1) {
    				throw new Exception("Cardinality constraint violation in the accessor 'getRef' to field '" + fieldName + "' in the object " + record.toString() + ". getRefs() should be used to access lists with more than one object.");
    			} else {
    				return result.get(0);
    			}
    		}
    	} else {
    		if (result.size() > 1) {
    			throw new Exception("Cardinality constraint violation in the accessor 'getRef' to field '" + fieldName + "' in the object " + record.toString() + ". getRefs() should be used to access lists with more than one object.");
    		} else {
    			return result.get(0);
    		}
    	}
    	return null;
    }

    
	/**
	 * SETTERS with UPSERT behaviour:
	 * - if field is not present, it is inserted
	 * - if field is present, it is updated and the update overrides the previous value
     *
	 * References are set as containment by default. If you want to set a reference, use the method setRefs.
     *
     * References are stored as lists, even if they have cardinality 1. This allows reference traversals without having to use downcasts.
     *
	 * @throws Exception 
	 */
    public void set(ERecord record, String fieldName, Object value) {
        if (value == null) {
            deleteField(record, fieldName);
        } else {

            if (value instanceof List<?>) {
                List<?> valueList = (List<?>) value;
                if (valueList.isEmpty()) {
                    record.getAttributes().put(fieldName, new BasicEList<>());
                    record.getReferences().remove(fieldName);
                    record.getContainments().remove(fieldName);
                } else {
                    Object attValue = valueList.get(0);
                    if (isPrimitiveType(attValue)) {
                        record.getAttributes().put(fieldName, valueList);
                        record.getReferences().remove(fieldName);
                        record.getContainments().remove(fieldName);
                    } else {
                        if (attValue instanceof ERecord) {
                            var parameterList = (List<ERecord>) value;
                            var list = new BasicEList<ERecord>(parameterList.size());
                            list.addAll(parameterList);
                            record.getContainments().put(fieldName, list);
                            record.getAttributes().remove(fieldName);
                            record.getReferences().remove(fieldName);
                        } else {
                            throw new RuntimeException("Could not set field " + fieldName + " to value " + value);
                        }
                    }
                }
            } else {
                if (isPrimitiveType(value)) {
                    record.getAttributes().put(fieldName, value.toString());
                    record.getContainments().remove(fieldName);
                    record.getReferences().remove(fieldName);
                } else {
                    if (value instanceof ERecord) {
                        EList<ERecord> list = new BasicEList<>();
                        list.add((ERecord) value);
                        record.getContainments().put(fieldName, list);
                        record.getAttributes().remove(fieldName);
                        record.getReferences().remove(fieldName);
                    } else {
                        throw new RuntimeException("Could not set field " + fieldName + " to value " + value);
                    }
                }
            }
        }
    }

    private void deleteField(ERecord record, String fieldName) {
    	record.getAttributes().remove(fieldName);
    	record.getContainments().remove(fieldName);
    	record.getReferences().remove(fieldName);
    }


    /**
     * Set references as references and not as containments.
     * @param record
     * @param fieldName
     * @param value
     * @throws Exception
     */
    public void setRefs(ERecord record, String fieldName, Object value) throws Exception {
        if (value == null) deleteField(record, fieldName);
        else {

            if (value instanceof List<?>) {
                List<?> valueList = (List<?>) value;
                if (valueList.isEmpty()) {
                    record.getReferences().put(fieldName, new BasicEList<>());
                    record.getAttributes().remove(fieldName);
                    record.getContainments().remove(fieldName);
                } else {
                    Object refValue = valueList.get(0);
                    if (refValue instanceof ERecord) {
                        var parameterList = (List<ERecord>) value;
                        var list = new BasicEList<ERecord>(parameterList.size());
                        list.addAll(parameterList);
                        // set containment
                        record.getReferences().put(fieldName, list);
                        record.getAttributes().remove(fieldName);
                        record.getContainments().remove(fieldName);

                        // Artur 11-05-2023: commented because it gives problems when the original program has 
                        // a tree structure and uses its own hierarchical structure. For example, ANTLR grammar parsers.
                        //
                        // set parent reference
//                        for (ERecord childObject : list) {
//                            // avoid self-recursive containment
//
//                            if (!(EcoreUtil.isAncestor(childObject, record)))
//                                childObject.set__parent(record);
//                        }
                    } else {
                        throw new Exception("Could not set reference field " + fieldName + " to value " + value);
                    }
                }
            } else {
                if (value instanceof ERecord) {
                    // containment
                    EList<ERecord> list = new BasicEList<>();
                    list.add((ERecord) value);
                    record.getReferences().put(fieldName, list);
                    record.getAttributes().remove(fieldName);
                    record.getContainments().remove(fieldName);

                    // Artur 11-05-2023: commented because it gives problems when the original program has 
                    // a tree structure and uses its own hierarchical structure. For example, ANTLR grammar parsers.
                    //
                    // set parent reference
                    // set parent reference
                    // avoid self-recursive containment
//                    if (!(EcoreUtil.isAncestor((EObject) value, record)))
//                        ((ERecord) value).set__parent(record);
                } else {
                    throw new Exception("Could not set reference field " + fieldName + " to value " + value);
                }
            }
        }
    }


    /**
     * HELPERS
     */


    public List<String> getFeatureNames(ERecord record) {

        List<String> list = new ArrayList<>();
        for (var field : record.getAttributes()) {
            list.add(field.getKey());
        }
        for (var field : record.getContainments()) {
            list.add(field.getKey());
        }
        for (var field : record.getReferences()) {
            list.add(field.getKey());
        }
        return list;
    }



    public boolean isPrimitiveType(Class clazz) {
        if (clazz.isEnum()
                || clazz.isPrimitive()
                || clazz.equals(String.class)
                || clazz.equals(Integer.class)
                || clazz.equals(BigDecimal.class)
                || clazz.equals(Boolean.class)
                || clazz.equals(Double.class)
                || clazz.equals(Float.class)
                || clazz.equals(Long.class)
                || clazz.equals(Short.class)
                || clazz.equals(Byte.class)
                || clazz.equals(Character.class)
                || clazz.equals(AtomicBoolean.class)
                || clazz.equals(AtomicInteger.class)
                || clazz.equals(AtomicIntegerArray.class)
                || clazz.equals(AtomicLong.class)
                || clazz.equals(AtomicLongArray.class)
        ) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean isPrimitiveType(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof List) {
            return isPrimitiveTypeList((List<?>) obj);
        }
        return isPrimitiveType(obj.getClass());
    }
    
    public boolean isPrimitiveTypeList(List<?> list) {
        for (Object element : list) {
            if (element instanceof List) {
                // Recursive call to check nested list
                if (!isPrimitiveTypeList((List<?>) element)) {
                    return false;
                }
            } else {
                // Check if the element is a primitive type or a wrapper of a primitive type
                if (!isPrimitiveType(element)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Returns the EMF Ecore datatype corresponding to the given object value. This function
     * determines the datatype based on the type of the value or the type of the elements in
     * a list value. If the value is a list, the function infers the datatype based on the
     * type of the first non-null element in the list. If the value is a single non-null
     * value, the function determines the datatype based on the type of the value. If the
     * value is a String, the function checks if it represents a valid date using a list of
     * common date formats:
     * <ul>
     *     <li>dd/MM/yyyy</li>
     *     <li>MM/dd/yyyy</li>
     *     <li>yyyy/MM/dd</li>
     *     <li>yyyy/dd/MM</li>
     *     <li>dd-MM-yyyy</li>
     *     <li>MM-dd-yyyy</li>
     *     <li>yyyy-MM-dd</li>
     *     <li>yyyy-dd-MM</li>
     *     <li>dd.MM.yyyy</li>
     *     <li>MM.dd.yyyy</li>
     *     <li>yyyy.MM.dd</li>
     *     <li>yyyy.dd.MM</li>
     *     <li>dd_MMM_yyyy</li>
     *     <li>MMM_dd_yyyy</li>
     *     <li>yyyy_MMM_dd</li>
     *     <li>yyyy_dd_MMM</li>
     *     <li>ddMMMyyyy</li>
     *     <li>MMMddyyyy</li>
     *     <li>yyyyMMMdd</li>
     *     <li>yyyyddMMM</li>
     * </ul>
     * If the value does not match any of the supported datatypes, the function returns null.
     * This function is designed to work with the EMF Ecore library.
     *
     * @param value the object value to determine the datatype for
     * @return the EMF Ecore datatype corresponding to the given value, or null if the
     *         datatype cannot be determined
     */
    public static EClassifier emfTypeOf(Object value) {
        if (value instanceof List) {
            List<?> list = (List<?>) value;
            if (list.isEmpty()) {
                return null; // cannot infer type for empty list
            } else {
                Object firstValue = list.get(0);
                EClassifier elementType = emfTypeOf(firstValue);
                return elementType;
            }
        } else {
            return emfTypeOfSingleValue(value);
        }
    }

    private static EClassifier emfTypeOfSingleValue(Object value) {
        String className = value!=null ? value.getClass().getSimpleName() : "";
    	return switch (className) {
            case "String" -> {
                if (isDate((String)value)) {
                    yield EcorePackage.Literals.EDATE;
                } else {
                    yield EcorePackage.Literals.ESTRING;
                }
            }
            case "Boolean" -> EcorePackage.Literals.EBOOLEAN;
            case "Integer", "int" -> EcorePackage.Literals.EINT;
            case "Double", "double" -> EcorePackage.Literals.EDOUBLE;
            case "Float", "float" -> EcorePackage.Literals.EFLOAT;
            case "Long", "long" -> EcorePackage.Literals.ELONG;
            case "Short", "short" -> EcorePackage.Literals.ESHORT;
            case "Byte", "byte" -> EcorePackage.Literals.EBYTE;
            case "Character", "char" -> EcorePackage.Literals.ECHAR;
            case "EObject" -> ((EObject) value).eClass();
            default -> null;
        };
    }

    private static final List<String> DATE_FORMATS = Arrays.asList(
            "dd/MM/yyyy", "MM/dd/yyyy", "yyyy/MM/dd", "yyyy/dd/MM",
            "dd-MM-yyyy", "MM-dd-yyyy", "yyyy-MM-dd", "yyyy-dd-MM",
            "dd.MM.yyyy", "MM.dd.yyyy", "yyyy.MM.dd", "yyyy.dd.MM",
            "dd_MMM_yyyy", "MMM_dd_yyyy", "yyyy_MMM_dd", "yyyy_dd_MMM",
            "ddMMMyyyy", "MMMddyyyy", "yyyyMMMdd", "yyyyddMMM"
    );

    private static boolean isDate(String value) {
        for (String pattern : DATE_FORMATS) {
            SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
            dateFormat.setLenient(false);
            try {
                Date date = dateFormat.parse(value);
                return true;
            } catch (ParseException e) {
                // Ignore and try next pattern
            }
        }
        return false;
    }


}


