package untypedModel.utils;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

import untypedModel.*;
import untypedModel.impl.ERecordImpl;

public class ERecordImplAccessors extends ERecordImpl {
	public ERecordImplAccessors() {};

    private ERecordUtil util = new ERecordUtil();

	public static ERecordImplAccessors createInstance() {
	    return new ERecordImplAccessors();
	}



    public Object get(String fieldName) {
        return util.get(this, fieldName);
    }


    public Boolean getBoolean(String fieldName) {
        return util.getBoolean(this, fieldName);
    }

    public String getString(String fieldName) throws Exception {
        return util.getString(this, fieldName);
    }

    public Integer getInteger(String fieldName) {
        return util.getInteger(this, fieldName);
    }

    public Double getDouble(String fieldName) {
        return util.getDouble(this, fieldName);
    }

    public Long getLong(String fieldName) {
        return util.getLong(this, fieldName);
    }
    public Short getShort(String fieldName) {
        return util.getShort(this, fieldName);
    }

    public Date getDate(String fieldName, String format) throws ParseException {
        return util.getDate(this, fieldName, format);
    }








    /**
     *
     * REFERENCES
     *
     **/

    public List<ERecord> getRefs(String fieldName) {
        List<ERecord> result = this.getContainments().get(fieldName);
        if (result == null) {
            result = this.getReferences().get(fieldName);
        }
        return result;
    }

    public ERecord getRef(String fieldName) throws Exception {
    	List<ERecord> result = this.getContainments().get(fieldName);
    	if (result == null) {
    		result = this.getReferences().get(fieldName);
    		if (result != null) {
    			if (result.size() > 1) {
    				throw new Exception("Cardinality constraint violation in the accessor 'getRef' to field '" + fieldName + "' in the object " + this.toString() + ". getRefs() should be used to access lists with more than one object.");
    			} else {
    				return result.get(0);
    			}
    		}
    	} else {
    		if (result.size() > 1) {
    			throw new Exception("Cardinality constraint violation in the accessor 'getRef' to field '" + fieldName + "' in the object " + this.toString() + ". getRefs() should be used to access lists with more than one object.");
    		} else {
    			return result.get(0);
    		}
    	}
    	return null;
    }

    public List<String> getFeatureNames() {
        return util.getFeatureNames(this);
    }

	/**
	 * SETTERS with UPSERT behaviour:
	 * - if field is not present, it is inserted
	 * - if field is present, it is updated and the update overrides the previous value
	 *
	 * References are set as containment
	 * @throws Exception
	 */
    public void set(String fieldName, Object value) throws Exception {
        util.set(this, fieldName, value);
    }
    public void setRefs(String fieldName, List<ERecord> value) throws Exception {
        util.setRefs(this, fieldName, value);
    }



}


