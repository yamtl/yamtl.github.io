/**
 */
package untypedModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

import untypedModel.ERecordType;
import untypedModel.UntypedModel;
import untypedModel.UntypedModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Untyped Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.impl.UntypedModelImpl#getERecordTypes <em>ERecord Types</em>}</li>
 * </ul>
 *
 * @generated
 */
public class UntypedModelImpl extends ERecordContainerImpl implements UntypedModel {
	/**
	 * The cached value of the '{@link #getERecordTypes() <em>ERecord Types</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getERecordTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<ERecordType> eRecordTypes;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UntypedModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UntypedModelPackage.Literals.UNTYPED_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ERecordType> getERecordTypes() {
		if (eRecordTypes == null) {
			eRecordTypes = new EObjectContainmentWithInverseEList<ERecordType>(ERecordType.class, this, UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES, UntypedModelPackage.ERECORD_TYPE__OWNER);
		}
		return eRecordTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getERecordTypes()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES:
				return ((InternalEList<?>)getERecordTypes()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES:
				return getERecordTypes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES:
				getERecordTypes().clear();
				getERecordTypes().addAll((Collection<? extends ERecordType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES:
				getERecordTypes().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES:
				return eRecordTypes != null && !eRecordTypes.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //UntypedModelImpl
