/**
 */
package untypedModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.EMap;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.EcoreEMap;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import untypedModel.ERecord;
import untypedModel.ERecordType;
import untypedModel.FeatureType;
import untypedModel.UntypedModel;
import untypedModel.UntypedModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ERecord Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.impl.ERecordTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordTypeImpl#get__instances <em>instances</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordTypeImpl#getFeatureTypes <em>Feature Types</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordTypeImpl#getFieldTypes <em>Field Types</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordTypeImpl#getOwner <em>Owner</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordTypeImpl#getEmfType <em>Emf Type</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ERecordTypeImpl extends MinimalEObjectImpl.Container implements ERecordType {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #get__instances() <em>instances</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #get__instances()
	 * @generated
	 * @ordered
	 */
	protected EList<ERecord> __instances;

	/**
	 * The cached value of the '{@link #getFeatureTypes() <em>Feature Types</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFeatureTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<FeatureType> featureTypes;

	/**
	 * The cached value of the '{@link #getFieldTypes() <em>Field Types</em>}' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFieldTypes()
	 * @generated
	 * @ordered
	 */
	protected EMap<String, FeatureType> fieldTypes;

	/**
	 * The cached value of the '{@link #getEmfType() <em>Emf Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmfType()
	 * @generated
	 * @ordered
	 */
	protected EClass emfType;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ERecordTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UntypedModelPackage.Literals.ERECORD_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD_TYPE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ERecord> get__instances() {
		if (__instances == null) {
			__instances = new EObjectWithInverseResolvingEList<ERecord>(ERecord.class, this, UntypedModelPackage.ERECORD_TYPE__INSTANCES, UntypedModelPackage.ERECORD__TYPE);
		}
		return __instances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FeatureType> getFeatureTypes() {
		if (featureTypes == null) {
			featureTypes = new EObjectContainmentWithInverseEList<FeatureType>(FeatureType.class, this, UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES, UntypedModelPackage.FEATURE_TYPE__OWNER);
		}
		return featureTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EMap<String, FeatureType> getFieldTypes() {
		if (fieldTypes == null) {
			fieldTypes = new EcoreEMap<String,FeatureType>(UntypedModelPackage.Literals.ERECORD_FIELD_TYPE, ERecordFieldTypeImpl.class, this, UntypedModelPackage.ERECORD_TYPE__FIELD_TYPES);
		}
		return fieldTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UntypedModel getOwner() {
		if (eContainerFeatureID() != UntypedModelPackage.ERECORD_TYPE__OWNER) return null;
		return (UntypedModel)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOwner(UntypedModel newOwner, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newOwner, UntypedModelPackage.ERECORD_TYPE__OWNER, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwner(UntypedModel newOwner) {
		if (newOwner != eInternalContainer() || (eContainerFeatureID() != UntypedModelPackage.ERECORD_TYPE__OWNER && newOwner != null)) {
			if (EcoreUtil.isAncestor(this, newOwner))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newOwner != null)
				msgs = ((InternalEObject)newOwner).eInverseAdd(this, UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES, UntypedModel.class, msgs);
			msgs = basicSetOwner(newOwner, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD_TYPE__OWNER, newOwner, newOwner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEmfType() {
		if (emfType != null && emfType.eIsProxy()) {
			InternalEObject oldEmfType = (InternalEObject)emfType;
			emfType = (EClass)eResolveProxy(oldEmfType);
			if (emfType != oldEmfType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UntypedModelPackage.ERECORD_TYPE__EMF_TYPE, oldEmfType, emfType));
			}
		}
		return emfType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass basicGetEmfType() {
		return emfType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmfType(EClass newEmfType) {
		EClass oldEmfType = emfType;
		emfType = newEmfType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD_TYPE__EMF_TYPE, oldEmfType, emfType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_TYPE__INSTANCES:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)get__instances()).basicAdd(otherEnd, msgs);
			case UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getFeatureTypes()).basicAdd(otherEnd, msgs);
			case UntypedModelPackage.ERECORD_TYPE__OWNER:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetOwner((UntypedModel)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_TYPE__INSTANCES:
				return ((InternalEList<?>)get__instances()).basicRemove(otherEnd, msgs);
			case UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES:
				return ((InternalEList<?>)getFeatureTypes()).basicRemove(otherEnd, msgs);
			case UntypedModelPackage.ERECORD_TYPE__FIELD_TYPES:
				return ((InternalEList<?>)getFieldTypes()).basicRemove(otherEnd, msgs);
			case UntypedModelPackage.ERECORD_TYPE__OWNER:
				return basicSetOwner(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case UntypedModelPackage.ERECORD_TYPE__OWNER:
				return eInternalContainer().eInverseRemove(this, UntypedModelPackage.UNTYPED_MODEL__ERECORD_TYPES, UntypedModel.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_TYPE__NAME:
				return getName();
			case UntypedModelPackage.ERECORD_TYPE__INSTANCES:
				return get__instances();
			case UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES:
				return getFeatureTypes();
			case UntypedModelPackage.ERECORD_TYPE__FIELD_TYPES:
				if (coreType) return getFieldTypes();
				else return getFieldTypes().map();
			case UntypedModelPackage.ERECORD_TYPE__OWNER:
				return getOwner();
			case UntypedModelPackage.ERECORD_TYPE__EMF_TYPE:
				if (resolve) return getEmfType();
				return basicGetEmfType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_TYPE__NAME:
				setName((String)newValue);
				return;
			case UntypedModelPackage.ERECORD_TYPE__INSTANCES:
				get__instances().clear();
				get__instances().addAll((Collection<? extends ERecord>)newValue);
				return;
			case UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES:
				getFeatureTypes().clear();
				getFeatureTypes().addAll((Collection<? extends FeatureType>)newValue);
				return;
			case UntypedModelPackage.ERECORD_TYPE__FIELD_TYPES:
				((EStructuralFeature.Setting)getFieldTypes()).set(newValue);
				return;
			case UntypedModelPackage.ERECORD_TYPE__OWNER:
				setOwner((UntypedModel)newValue);
				return;
			case UntypedModelPackage.ERECORD_TYPE__EMF_TYPE:
				setEmfType((EClass)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_TYPE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case UntypedModelPackage.ERECORD_TYPE__INSTANCES:
				get__instances().clear();
				return;
			case UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES:
				getFeatureTypes().clear();
				return;
			case UntypedModelPackage.ERECORD_TYPE__FIELD_TYPES:
				getFieldTypes().clear();
				return;
			case UntypedModelPackage.ERECORD_TYPE__OWNER:
				setOwner((UntypedModel)null);
				return;
			case UntypedModelPackage.ERECORD_TYPE__EMF_TYPE:
				setEmfType((EClass)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_TYPE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case UntypedModelPackage.ERECORD_TYPE__INSTANCES:
				return __instances != null && !__instances.isEmpty();
			case UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES:
				return featureTypes != null && !featureTypes.isEmpty();
			case UntypedModelPackage.ERECORD_TYPE__FIELD_TYPES:
				return fieldTypes != null && !fieldTypes.isEmpty();
			case UntypedModelPackage.ERECORD_TYPE__OWNER:
				return getOwner() != null;
			case UntypedModelPackage.ERECORD_TYPE__EMF_TYPE:
				return emfType != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ERecordTypeImpl
