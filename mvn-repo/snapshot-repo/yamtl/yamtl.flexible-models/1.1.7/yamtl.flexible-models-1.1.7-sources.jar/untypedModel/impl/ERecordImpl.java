/**
 */
package untypedModel.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.EMap;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EcoreEMap;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import untypedModel.ERecord;
import untypedModel.ERecordContainer;
import untypedModel.ERecordType;
import untypedModel.UntypedModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ERecord</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.impl.ERecordImpl#get__type <em>type</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordImpl#getReferences <em>References</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordImpl#getContainments <em>Containments</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordImpl#get__parent <em>parent</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordImpl#get__uuidFieldName <em>uuid Field Name</em>}</li>
 *   <li>{@link untypedModel.impl.ERecordImpl#get__uuid <em>uuid</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ERecordImpl extends ERecordContainerImpl implements ERecord {
	/**
	 * The cached value of the '{@link #get__type() <em>type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #get__type()
	 * @generated
	 * @ordered
	 */
	protected ERecordType __type;

	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EMap<String, Object> attributes;

	/**
	 * The cached value of the '{@link #getReferences() <em>References</em>}' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReferences()
	 * @generated
	 * @ordered
	 */
	protected EMap<String, EList<ERecord>> references;

	/**
	 * The cached value of the '{@link #getContainments() <em>Containments</em>}' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainments()
	 * @generated
	 * @ordered
	 */
	protected EMap<String, EList<ERecord>> containments;

	/**
	 * The default value of the '{@link #get__uuidFieldName() <em>uuid Field Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #get__uuidFieldName()
	 * @generated
	 * @ordered
	 */
	protected static final String _UUID_FIELD_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #get__uuidFieldName() <em>uuid Field Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #get__uuidFieldName()
	 * @generated
	 * @ordered
	 */
	protected String __uuidFieldName = _UUID_FIELD_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #get__uuid() <em>uuid</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #get__uuid()
	 * @generated
	 * @ordered
	 */
	protected static final long _UUID_EDEFAULT = 0L;

	/**
	 * The cached value of the '{@link #get__uuid() <em>uuid</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #get__uuid()
	 * @generated
	 * @ordered
	 */
	protected long __uuid = _UUID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ERecordImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UntypedModelPackage.Literals.ERECORD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERecordType get__type() {
		if (__type != null && __type.eIsProxy()) {
			InternalEObject old__type = (InternalEObject)__type;
			__type = (ERecordType)eResolveProxy(old__type);
			if (__type != old__type) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UntypedModelPackage.ERECORD__TYPE, old__type, __type));
			}
		}
		return __type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERecordType basicGet__type() {
		return __type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSet__type(ERecordType new__type, NotificationChain msgs) {
		ERecordType old__type = __type;
		__type = new__type;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD__TYPE, old__type, new__type);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void set__type(ERecordType new__type) {
		if (new__type != __type) {
			NotificationChain msgs = null;
			if (__type != null)
				msgs = ((InternalEObject)__type).eInverseRemove(this, UntypedModelPackage.ERECORD_TYPE__INSTANCES, ERecordType.class, msgs);
			if (new__type != null)
				msgs = ((InternalEObject)new__type).eInverseAdd(this, UntypedModelPackage.ERECORD_TYPE__INSTANCES, ERecordType.class, msgs);
			msgs = basicSet__type(new__type, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD__TYPE, new__type, new__type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EMap<String, Object> getAttributes() {
		if (attributes == null) {
			attributes = new EcoreEMap<String,Object>(UntypedModelPackage.Literals.ATTRIBUTE_VALUE, AttributeValueImpl.class, this, UntypedModelPackage.ERECORD__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EMap<String, EList<ERecord>> getReferences() {
		if (references == null) {
			references = new EcoreEMap<String,EList<ERecord>>(UntypedModelPackage.Literals.REFERENCE_VALUE, ReferenceValueImpl.class, this, UntypedModelPackage.ERECORD__REFERENCES);
		}
		return references;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EMap<String, EList<ERecord>> getContainments() {
		if (containments == null) {
			containments = new EcoreEMap<String,EList<ERecord>>(UntypedModelPackage.Literals.CONTAINMENT_VALUE, ContainmentValueImpl.class, this, UntypedModelPackage.ERECORD__CONTAINMENTS);
		}
		return containments;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERecordContainer get__parent() {
		if (eContainerFeatureID() != UntypedModelPackage.ERECORD__PARENT) return null;
		return (ERecordContainer)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSet__parent(ERecordContainer new__parent, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)new__parent, UntypedModelPackage.ERECORD__PARENT, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void set__parent(ERecordContainer new__parent) {
		if (new__parent != eInternalContainer() || (eContainerFeatureID() != UntypedModelPackage.ERECORD__PARENT && new__parent != null)) {
			if (EcoreUtil.isAncestor(this, new__parent))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (new__parent != null)
				msgs = ((InternalEObject)new__parent).eInverseAdd(this, UntypedModelPackage.ERECORD_CONTAINER__CHILDREN, ERecordContainer.class, msgs);
			msgs = basicSet__parent(new__parent, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD__PARENT, new__parent, new__parent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String get__uuidFieldName() {
		return __uuidFieldName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void set__uuidFieldName(String new__uuidFieldName) {
		String old__uuidFieldName = __uuidFieldName;
		__uuidFieldName = new__uuidFieldName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD__UUID_FIELD_NAME, old__uuidFieldName, __uuidFieldName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public long get__uuid() {
		return __uuid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void set__uuid(long new__uuid) {
		long old__uuid = __uuid;
		__uuid = new__uuid;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.ERECORD__UUID, old__uuid, __uuid));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD__TYPE:
				if (__type != null)
					msgs = ((InternalEObject)__type).eInverseRemove(this, UntypedModelPackage.ERECORD_TYPE__INSTANCES, ERecordType.class, msgs);
				return basicSet__type((ERecordType)otherEnd, msgs);
			case UntypedModelPackage.ERECORD__PARENT:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSet__parent((ERecordContainer)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD__TYPE:
				return basicSet__type(null, msgs);
			case UntypedModelPackage.ERECORD__ATTRIBUTES:
				return ((InternalEList<?>)getAttributes()).basicRemove(otherEnd, msgs);
			case UntypedModelPackage.ERECORD__REFERENCES:
				return ((InternalEList<?>)getReferences()).basicRemove(otherEnd, msgs);
			case UntypedModelPackage.ERECORD__CONTAINMENTS:
				return ((InternalEList<?>)getContainments()).basicRemove(otherEnd, msgs);
			case UntypedModelPackage.ERECORD__PARENT:
				return basicSet__parent(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case UntypedModelPackage.ERECORD__PARENT:
				return eInternalContainer().eInverseRemove(this, UntypedModelPackage.ERECORD_CONTAINER__CHILDREN, ERecordContainer.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD__TYPE:
				if (resolve) return get__type();
				return basicGet__type();
			case UntypedModelPackage.ERECORD__ATTRIBUTES:
				if (coreType) return getAttributes();
				else return getAttributes().map();
			case UntypedModelPackage.ERECORD__REFERENCES:
				if (coreType) return getReferences();
				else return getReferences().map();
			case UntypedModelPackage.ERECORD__CONTAINMENTS:
				if (coreType) return getContainments();
				else return getContainments().map();
			case UntypedModelPackage.ERECORD__PARENT:
				return get__parent();
			case UntypedModelPackage.ERECORD__UUID_FIELD_NAME:
				return get__uuidFieldName();
			case UntypedModelPackage.ERECORD__UUID:
				return get__uuid();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD__TYPE:
				set__type((ERecordType)newValue);
				return;
			case UntypedModelPackage.ERECORD__ATTRIBUTES:
				((EStructuralFeature.Setting)getAttributes()).set(newValue);
				return;
			case UntypedModelPackage.ERECORD__REFERENCES:
				((EStructuralFeature.Setting)getReferences()).set(newValue);
				return;
			case UntypedModelPackage.ERECORD__CONTAINMENTS:
				((EStructuralFeature.Setting)getContainments()).set(newValue);
				return;
			case UntypedModelPackage.ERECORD__PARENT:
				set__parent((ERecordContainer)newValue);
				return;
			case UntypedModelPackage.ERECORD__UUID_FIELD_NAME:
				set__uuidFieldName((String)newValue);
				return;
			case UntypedModelPackage.ERECORD__UUID:
				set__uuid((Long)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD__TYPE:
				set__type((ERecordType)null);
				return;
			case UntypedModelPackage.ERECORD__ATTRIBUTES:
				getAttributes().clear();
				return;
			case UntypedModelPackage.ERECORD__REFERENCES:
				getReferences().clear();
				return;
			case UntypedModelPackage.ERECORD__CONTAINMENTS:
				getContainments().clear();
				return;
			case UntypedModelPackage.ERECORD__PARENT:
				set__parent((ERecordContainer)null);
				return;
			case UntypedModelPackage.ERECORD__UUID_FIELD_NAME:
				set__uuidFieldName(_UUID_FIELD_NAME_EDEFAULT);
				return;
			case UntypedModelPackage.ERECORD__UUID:
				set__uuid(_UUID_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD__TYPE:
				return __type != null;
			case UntypedModelPackage.ERECORD__ATTRIBUTES:
				return attributes != null && !attributes.isEmpty();
			case UntypedModelPackage.ERECORD__REFERENCES:
				return references != null && !references.isEmpty();
			case UntypedModelPackage.ERECORD__CONTAINMENTS:
				return containments != null && !containments.isEmpty();
			case UntypedModelPackage.ERECORD__PARENT:
				return get__parent() != null;
			case UntypedModelPackage.ERECORD__UUID_FIELD_NAME:
				return _UUID_FIELD_NAME_EDEFAULT == null ? __uuidFieldName != null : !_UUID_FIELD_NAME_EDEFAULT.equals(__uuidFieldName);
			case UntypedModelPackage.ERECORD__UUID:
				return __uuid != _UUID_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (__uuidFieldName: ");
		result.append(__uuidFieldName);
		result.append(", __uuid: ");
		result.append(__uuid);
		result.append(')');
		return result.toString();
	}

} //ERecordImpl
