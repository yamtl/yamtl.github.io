/**
 */
package untypedModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

import untypedModel.ERecord;
import untypedModel.ERecordContainer;
import untypedModel.UntypedModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ERecord Container</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.impl.ERecordContainerImpl#get__children <em>children</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ERecordContainerImpl extends MinimalEObjectImpl.Container implements ERecordContainer {
	/**
	 * The cached value of the '{@link #get__children() <em>children</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #get__children()
	 * @generated
	 * @ordered
	 */
	protected EList<ERecord> __children;
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ERecordContainerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UntypedModelPackage.Literals.ERECORD_CONTAINER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ERecord> get__children() {
		if (__children == null) {
			__children = new EObjectContainmentWithInverseEList<ERecord>(ERecord.class, this, UntypedModelPackage.ERECORD_CONTAINER__CHILDREN, UntypedModelPackage.ERECORD__PARENT);
		}
		return __children;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_CONTAINER__CHILDREN:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)get__children()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_CONTAINER__CHILDREN:
				return ((InternalEList<?>)get__children()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_CONTAINER__CHILDREN:
				return get__children();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_CONTAINER__CHILDREN:
				get__children().clear();
				get__children().addAll((Collection<? extends ERecord>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_CONTAINER__CHILDREN:
				get__children().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.ERECORD_CONTAINER__CHILDREN:
				return __children != null && !__children.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ERecordContainerImpl
