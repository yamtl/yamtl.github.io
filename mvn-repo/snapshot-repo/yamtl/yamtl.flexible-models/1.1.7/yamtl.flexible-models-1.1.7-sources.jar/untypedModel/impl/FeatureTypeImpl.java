/**
 */
package untypedModel.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EcoreUtil;

import untypedModel.ERecordType;
import untypedModel.FeatureType;
import untypedModel.UntypedModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Feature Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.impl.FeatureTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link untypedModel.impl.FeatureTypeImpl#getOwner <em>Owner</em>}</li>
 *   <li>{@link untypedModel.impl.FeatureTypeImpl#getEmfType <em>Emf Type</em>}</li>
 *   <li>{@link untypedModel.impl.FeatureTypeImpl#getEmfFeatureType <em>Emf Feature Type</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FeatureTypeImpl extends MinimalEObjectImpl.Container implements FeatureType {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getEmfType() <em>Emf Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmfType()
	 * @generated
	 * @ordered
	 */
	protected EClassifier emfType;

	/**
	 * The cached value of the '{@link #getEmfFeatureType() <em>Emf Feature Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmfFeatureType()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature emfFeatureType;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FeatureTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UntypedModelPackage.Literals.FEATURE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.FEATURE_TYPE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERecordType getOwner() {
		if (eContainerFeatureID() != UntypedModelPackage.FEATURE_TYPE__OWNER) return null;
		return (ERecordType)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOwner(ERecordType newOwner, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newOwner, UntypedModelPackage.FEATURE_TYPE__OWNER, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwner(ERecordType newOwner) {
		if (newOwner != eInternalContainer() || (eContainerFeatureID() != UntypedModelPackage.FEATURE_TYPE__OWNER && newOwner != null)) {
			if (EcoreUtil.isAncestor(this, newOwner))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newOwner != null)
				msgs = ((InternalEObject)newOwner).eInverseAdd(this, UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES, ERecordType.class, msgs);
			msgs = basicSetOwner(newOwner, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.FEATURE_TYPE__OWNER, newOwner, newOwner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClassifier getEmfType() {
		if (emfType != null && emfType.eIsProxy()) {
			InternalEObject oldEmfType = (InternalEObject)emfType;
			emfType = (EClassifier)eResolveProxy(oldEmfType);
			if (emfType != oldEmfType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UntypedModelPackage.FEATURE_TYPE__EMF_TYPE, oldEmfType, emfType));
			}
		}
		return emfType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClassifier basicGetEmfType() {
		return emfType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmfType(EClassifier newEmfType) {
		EClassifier oldEmfType = emfType;
		emfType = newEmfType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.FEATURE_TYPE__EMF_TYPE, oldEmfType, emfType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EStructuralFeature getEmfFeatureType() {
		if (emfFeatureType != null && emfFeatureType.eIsProxy()) {
			InternalEObject oldEmfFeatureType = (InternalEObject)emfFeatureType;
			emfFeatureType = (EStructuralFeature)eResolveProxy(oldEmfFeatureType);
			if (emfFeatureType != oldEmfFeatureType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UntypedModelPackage.FEATURE_TYPE__EMF_FEATURE_TYPE, oldEmfFeatureType, emfFeatureType));
			}
		}
		return emfFeatureType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EStructuralFeature basicGetEmfFeatureType() {
		return emfFeatureType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmfFeatureType(EStructuralFeature newEmfFeatureType) {
		EStructuralFeature oldEmfFeatureType = emfFeatureType;
		emfFeatureType = newEmfFeatureType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UntypedModelPackage.FEATURE_TYPE__EMF_FEATURE_TYPE, oldEmfFeatureType, emfFeatureType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.FEATURE_TYPE__OWNER:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetOwner((ERecordType)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case UntypedModelPackage.FEATURE_TYPE__OWNER:
				return basicSetOwner(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case UntypedModelPackage.FEATURE_TYPE__OWNER:
				return eInternalContainer().eInverseRemove(this, UntypedModelPackage.ERECORD_TYPE__FEATURE_TYPES, ERecordType.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case UntypedModelPackage.FEATURE_TYPE__NAME:
				return getName();
			case UntypedModelPackage.FEATURE_TYPE__OWNER:
				return getOwner();
			case UntypedModelPackage.FEATURE_TYPE__EMF_TYPE:
				if (resolve) return getEmfType();
				return basicGetEmfType();
			case UntypedModelPackage.FEATURE_TYPE__EMF_FEATURE_TYPE:
				if (resolve) return getEmfFeatureType();
				return basicGetEmfFeatureType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case UntypedModelPackage.FEATURE_TYPE__NAME:
				setName((String)newValue);
				return;
			case UntypedModelPackage.FEATURE_TYPE__OWNER:
				setOwner((ERecordType)newValue);
				return;
			case UntypedModelPackage.FEATURE_TYPE__EMF_TYPE:
				setEmfType((EClassifier)newValue);
				return;
			case UntypedModelPackage.FEATURE_TYPE__EMF_FEATURE_TYPE:
				setEmfFeatureType((EStructuralFeature)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.FEATURE_TYPE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case UntypedModelPackage.FEATURE_TYPE__OWNER:
				setOwner((ERecordType)null);
				return;
			case UntypedModelPackage.FEATURE_TYPE__EMF_TYPE:
				setEmfType((EClassifier)null);
				return;
			case UntypedModelPackage.FEATURE_TYPE__EMF_FEATURE_TYPE:
				setEmfFeatureType((EStructuralFeature)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case UntypedModelPackage.FEATURE_TYPE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case UntypedModelPackage.FEATURE_TYPE__OWNER:
				return getOwner() != null;
			case UntypedModelPackage.FEATURE_TYPE__EMF_TYPE:
				return emfType != null;
			case UntypedModelPackage.FEATURE_TYPE__EMF_FEATURE_TYPE:
				return emfFeatureType != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //FeatureTypeImpl
