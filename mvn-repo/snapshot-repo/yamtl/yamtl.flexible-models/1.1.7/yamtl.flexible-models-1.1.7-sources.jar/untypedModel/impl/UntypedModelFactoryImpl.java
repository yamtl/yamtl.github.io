/**
 */
package untypedModel.impl;

import java.util.Map;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import untypedModel.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class UntypedModelFactoryImpl extends EFactoryImpl implements UntypedModelFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static UntypedModelFactory init() {
		try {
			UntypedModelFactory theUntypedModelFactory = (UntypedModelFactory)EPackage.Registry.INSTANCE.getEFactory(UntypedModelPackage.eNS_URI);
			if (theUntypedModelFactory != null) {
				return theUntypedModelFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new UntypedModelFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UntypedModelFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case UntypedModelPackage.UNTYPED_MODEL: return createUntypedModel();
			case UntypedModelPackage.ERECORD: return createERecord();
			case UntypedModelPackage.ATTRIBUTE_VALUE: return (EObject)createAttributeValue();
			case UntypedModelPackage.REFERENCE_VALUE: return (EObject)createReferenceValue();
			case UntypedModelPackage.CONTAINMENT_VALUE: return (EObject)createContainmentValue();
			case UntypedModelPackage.ERECORD_TYPE: return createERecordType();
			case UntypedModelPackage.FEATURE_TYPE: return createFeatureType();
			case UntypedModelPackage.ERECORD_FIELD_TYPE: return (EObject)createERecordFieldType();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UntypedModel createUntypedModel() {
		UntypedModelImpl untypedModel = new UntypedModelImpl();
		return untypedModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERecord createERecord() {
		ERecordImpl eRecord = new ERecordImpl();
		return eRecord;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Map.Entry<String, Object> createAttributeValue() {
		AttributeValueImpl attributeValue = new AttributeValueImpl();
		return attributeValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Map.Entry<String, EList<ERecord>> createReferenceValue() {
		ReferenceValueImpl referenceValue = new ReferenceValueImpl();
		return referenceValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Map.Entry<String, EList<ERecord>> createContainmentValue() {
		ContainmentValueImpl containmentValue = new ContainmentValueImpl();
		return containmentValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERecordType createERecordType() {
		ERecordTypeImpl eRecordType = new ERecordTypeImpl();
		return eRecordType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureType createFeatureType() {
		FeatureTypeImpl featureType = new FeatureTypeImpl();
		return featureType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Map.Entry<String, FeatureType> createERecordFieldType() {
		ERecordFieldTypeImpl eRecordFieldType = new ERecordFieldTypeImpl();
		return eRecordFieldType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UntypedModelPackage getUntypedModelPackage() {
		return (UntypedModelPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static UntypedModelPackage getPackage() {
		return UntypedModelPackage.eINSTANCE;
	}

} //UntypedModelFactoryImpl
