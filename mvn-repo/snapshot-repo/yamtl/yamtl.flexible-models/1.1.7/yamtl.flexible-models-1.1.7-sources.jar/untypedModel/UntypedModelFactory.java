/**
 */
package untypedModel;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see untypedModel.UntypedModelPackage
 * @generated
 */
public interface UntypedModelFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UntypedModelFactory eINSTANCE = untypedModel.impl.UntypedModelFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Untyped Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Untyped Model</em>'.
	 * @generated
	 */
	UntypedModel createUntypedModel();

	/**
	 * Returns a new object of class '<em>ERecord</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>ERecord</em>'.
	 * @generated
	 */
	ERecord createERecord();

	/**
	 * Returns a new object of class '<em>ERecord Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>ERecord Type</em>'.
	 * @generated
	 */
	ERecordType createERecordType();

	/**
	 * Returns a new object of class '<em>Feature Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature Type</em>'.
	 * @generated
	 */
	FeatureType createFeatureType();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	UntypedModelPackage getUntypedModelPackage();

} //UntypedModelFactory
