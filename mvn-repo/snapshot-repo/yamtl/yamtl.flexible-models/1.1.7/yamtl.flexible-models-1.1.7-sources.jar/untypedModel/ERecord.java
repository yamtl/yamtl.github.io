/**
 */
package untypedModel;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.EMap;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ERecord</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link untypedModel.ERecord#get__type <em>type</em>}</li>
 *   <li>{@link untypedModel.ERecord#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link untypedModel.ERecord#getReferences <em>References</em>}</li>
 *   <li>{@link untypedModel.ERecord#getContainments <em>Containments</em>}</li>
 *   <li>{@link untypedModel.ERecord#get__parent <em>parent</em>}</li>
 *   <li>{@link untypedModel.ERecord#get__uuidFieldName <em>uuid Field Name</em>}</li>
 *   <li>{@link untypedModel.ERecord#get__uuid <em>uuid</em>}</li>
 * </ul>
 *
 * @see untypedModel.UntypedModelPackage#getERecord()
 * @model
 * @generated
 */
public interface ERecord extends ERecordContainer {
	/**
	 * Returns the value of the '<em><b>type</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link untypedModel.ERecordType#get__instances <em>instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>type</em>' reference.
	 * @see #set__type(ERecordType)
	 * @see untypedModel.UntypedModelPackage#getERecord___type()
	 * @see untypedModel.ERecordType#get__instances
	 * @model opposite="__instances" required="true"
	 * @generated
	 */
	ERecordType get__type();

	/**
	 * Sets the value of the '{@link untypedModel.ERecord#get__type <em>type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>type</em>' reference.
	 * @see #get__type()
	 * @generated
	 */
	void set__type(ERecordType value);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' map.
	 * The key is of type {@link java.lang.String},
	 * and the value is of type {@link java.lang.Object},
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' map.
	 * @see untypedModel.UntypedModelPackage#getERecord_Attributes()
	 * @model mapType="untypedModel.AttributeValue&lt;org.eclipse.emf.ecore.EString, org.eclipse.emf.ecore.EJavaObject&gt;"
	 * @generated
	 */
	EMap<String, Object> getAttributes();

	/**
	 * Returns the value of the '<em><b>References</b></em>' map.
	 * The key is of type {@link java.lang.String},
	 * and the value is of type list of {@link untypedModel.ERecord},
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>References</em>' map.
	 * @see untypedModel.UntypedModelPackage#getERecord_References()
	 * @model mapType="untypedModel.ReferenceValue&lt;org.eclipse.emf.ecore.EString, untypedModel.ERecord&gt;"
	 * @generated
	 */
	EMap<String, EList<ERecord>> getReferences();

	/**
	 * Returns the value of the '<em><b>Containments</b></em>' map.
	 * The key is of type {@link java.lang.String},
	 * and the value is of type list of {@link untypedModel.ERecord},
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Containments</em>' map.
	 * @see untypedModel.UntypedModelPackage#getERecord_Containments()
	 * @model mapType="untypedModel.ContainmentValue&lt;org.eclipse.emf.ecore.EString, untypedModel.ERecord&gt;"
	 * @generated
	 */
	EMap<String, EList<ERecord>> getContainments();

	/**
	 * Returns the value of the '<em><b>parent</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link untypedModel.ERecordContainer#get__children <em>children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>parent</em>' container reference.
	 * @see #set__parent(ERecordContainer)
	 * @see untypedModel.UntypedModelPackage#getERecord___parent()
	 * @see untypedModel.ERecordContainer#get__children
	 * @model opposite="__children" transient="false"
	 * @generated
	 */
	ERecordContainer get__parent();

	/**
	 * Sets the value of the '{@link untypedModel.ERecord#get__parent <em>parent</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>parent</em>' container reference.
	 * @see #get__parent()
	 * @generated
	 */
	void set__parent(ERecordContainer value);

	/**
	 * Returns the value of the '<em><b>uuid Field Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>uuid Field Name</em>' attribute.
	 * @see #set__uuidFieldName(String)
	 * @see untypedModel.UntypedModelPackage#getERecord___uuidFieldName()
	 * @model
	 * @generated
	 */
	String get__uuidFieldName();

	/**
	 * Sets the value of the '{@link untypedModel.ERecord#get__uuidFieldName <em>uuid Field Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>uuid Field Name</em>' attribute.
	 * @see #get__uuidFieldName()
	 * @generated
	 */
	void set__uuidFieldName(String value);

	/**
	 * Returns the value of the '<em><b>uuid</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>uuid</em>' attribute.
	 * @see #set__uuid(long)
	 * @see untypedModel.UntypedModelPackage#getERecord___uuid()
	 * @model id="true"
	 * @generated
	 */
	long get__uuid();

	/**
	 * Sets the value of the '{@link untypedModel.ERecord#get__uuid <em>uuid</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>uuid</em>' attribute.
	 * @see #get__uuid()
	 * @generated
	 */
	void set__uuid(long value);

} // ERecord
