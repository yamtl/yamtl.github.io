# How to run this example

- Download and install [Java 11](https://adoptium.net/)
- Download and install [Gradle](https://gradle.org)
- Run `gradle run` from the command line
