# LinkedList reversal M2M transformation with YAMTLGroovy

* Declaration of transformation is available in `src/main/groovy`
* An example of how to execute it can be found in `src/main/test`
* The configuration and dependencies needed are in `build.gradle`
* The software artifacts can be found in `./model`